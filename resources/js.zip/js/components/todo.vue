<template>

        <div class="secondGreyBorderDash h-100 p-3 p-md-4">
        <div class="row g-0">
            <div class="col-auto cornerSvgToDoList">
                    <svg width="151" height="146" viewBox="0 0 151 146" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g filter="url(#filter0_d_28_428)">
                            <path d="M37.0413 77.3271C39.8353 81.9774 47.7833 86.5471 52.0258 89.8453C56.2682 93.1435 50.751 102.5 55.796 103.944C60.8411 105.388 76.3496 98.8915 81.4291 98.2616C86.5087 97.6317 91.3573 95.9651 95.6981 93.3571C100.039 90.7491 103.787 87.2506 106.728 83.0615C109.669 78.8725 111.746 74.0747 112.84 68.9424C113.933 63.81 114.023 58.4434 113.103 53.1491C112.183 47.8547 111.333 38.8294 110.491 33.8527L80.9458 34.3263L63.3655 34.608C58.8416 34.6805 54.4021 35.8453 50.4253 38.0032L47.8184 39.4178C43.6749 41.6661 40.4607 45.3082 38.745 49.6991V49.6991C37.8801 51.9128 37.4173 54.2631 37.3786 56.6394L37.0413 77.3271Z" fill="#DCE4F9"/>
                            </g>
                            <path d="M71.7234 54.4419H86.9766L86.9766 77.3953H58.8604V54.5682C58.8604 54.5486 58.8649 54.5293 58.8737 54.5117C58.8951 54.4689 58.9389 54.4419 58.9867 54.4419H61.6895C62.2655 54.4419 62.7324 53.9749 62.7324 53.3989V53.3463C62.7324 52.0505 63.7829 51 65.0787 51H68.2815C69.5773 51 70.6278 52.0505 70.6278 53.3463C70.6278 53.9513 71.1183 54.4419 71.7234 54.4419Z" stroke="black" stroke-width="2"/>
                            <path d="M65.985 61.3253H89.8973C91.2509 61.3253 92.2135 62.6418 91.8031 63.9317L87.4672 77.5588C87.3352 77.9737 86.9498 78.2556 86.5143 78.2556H59.8554C59.1614 78.2556 58.6784 77.566 58.9156 76.9138L64.1054 62.6418C64.3928 61.8515 65.144 61.3253 65.985 61.3253Z" fill="#DCE4F9" stroke="black" stroke-width="2"/>
                            <path d="M77.264 65.0275C78.9544 65.0275 80.6187 65.806 80.6187 67.6682C80.6187 69.3855 78.6509 70.0459 78.2283 70.6664C77.911 71.128 78.017 71.7766 77.1452 71.7766C76.5774 71.7766 76.3 71.3147 76.3 70.892C76.3 69.3194 78.6107 68.9635 78.6107 67.6685C78.6107 66.9557 78.1363 66.5331 77.3435 66.5331C75.653 66.5331 76.3131 68.2759 75.0328 68.2759C74.5706 68.2759 74.1738 67.9986 74.1738 67.4706C74.1735 66.1753 75.6524 65.0275 77.264 65.0275ZM77.1982 72.6339C77.7916 72.6339 78.2812 73.122 78.2812 73.7173C78.2812 74.3126 77.7926 74.8006 77.1982 74.8006C76.6039 74.8006 76.1149 74.3132 76.1149 73.7173C76.1149 73.1223 76.6039 72.6339 77.1982 72.6339Z" fill="black"/>
                            <path d="M73.6869 70.4414H71.9804V68.7363C71.9804 68.4664 71.7626 68.2476 71.4927 68.2476C71.2228 68.2476 71.0051 68.4664 71.0051 68.7364V70.4426H69.2978C69.0279 70.4426 68.8085 70.6614 68.8086 70.9314C68.8085 71.0663 68.863 71.19 68.9513 71.2783C69.0397 71.3668 69.1617 71.4227 69.2965 71.4227H71.0051V73.1266C71.0051 73.2616 71.0587 73.3838 71.1471 73.472C71.2356 73.5604 71.3572 73.6152 71.4922 73.6152C71.762 73.6152 71.9804 73.3963 71.9804 73.1266V71.4226H73.6869C73.9568 71.4226 74.1756 71.2019 74.1755 70.932C74.1754 70.6622 73.9565 70.4414 73.6869 70.4414Z" fill="black"/>
                        <defs>
                            <filter id="filter0_d_28_428" x="0.0410156" y="0.852783" width="150.691" height="144.3" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                            <feFlood flood-opacity="0" result="BackgroundImageFix"/>
                            <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
                            <feOffset dy="4"/>
                            <feGaussianBlur stdDeviation="18.5"/>
                            <feComposite in2="hardAlpha" operator="out"/>
                            <feColorMatrix type="matrix" values="0 0 0 0 0.875 0 0 0 0 0.875 0 0 0 0 0.875 0 0 0 0.25 0"/>
                            <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_28_428"/>
                            <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_28_428" result="shape"/>
                            </filter>
                        </defs>
                </svg>

            </div>
            <div class="col titleMarginAuto">
            <div class="pb-3">
                <span class="secondGreyBorderDashSpan">Pendenz Erstellen</span>
            </div>
            </div>
        </div>


            <div id="alrt" class="col-12" style="margin-top: -1.5rem">
            </div>
            <div class="">
                <div class="row g-0">
                    <div class="col pe-0 pe-md-2 pb-3 pb-md-0" style="position: relative;">
                        <div class="row g-0">

                            <div class="col my-auto">
                                <div>
                                    <span class="fs-6">Berater</span>
                                </div>
                            </div>
                        </div>
                        <div class="thirdBorderDivDash py-2">
                            <div class="row g-0 justify-content-end">
                                <select style="box-shadow: none !important;" id="admin-input" name="admin" class="form-select selectDashBoardStyle py-0" @change="onChangeSelect($event)">
                                    <option v-for="admin in todos.admins" :value="admin.id">{{ admin.name }}</option>
                                </select>
                                <div class="col-auto me-2">

                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="col-12 col-md-6">
                        <div class="row g-0">

                            <div class="col my-auto">
                                <div>
                                    <span class="fs-6">Kunde</span>
                                </div>
                            </div>
                        </div>
                        <div class="thirdBorderDivDash py-1">
                            <div class="row g-0">
                                <div class="col ps-1 my-auto">
                                    <select id="enableSelectDrop" disabled name="costumer" @change="onChangeCostumer($event);loadMore()"
                                            class="form-select selectDashBoardStyle2 py-1 kundeSelectStyle">
                                        <option></option>
                                        <option v-for="costumer in todos.costumers" :value="costumer.id">{{costumer.first_name}}
                                            {{ costumer.last_name }}
                                        </option>
                                    </select>
                                </div>
                                <div class="col-auto my-auto pe-2 ps-1">
                                    <label class="switch5" @click="enableSelectDrop()">
                                        <input id="toggleSwitch" type="checkbox">
                                        <span class="slider round"></span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="py-3">
                        <div class="row g-0">

                            <div class="col my-auto">
                                <div>
                                    <span class="fs-6">Grund</span>
                                </div>
                            </div>
                            <div class="row g-0">
                                <input class="form-control py-2 inputStyleDash grundBesInputStyle" id="task" type="text">
                            </div>

                        </div>
                    </div>
                    <div>
                        <div class="row g-0">

                            <div class="col my-auto">
                                <div>
                                    <span class="fs-6">Beschreibung</span>
                                    <span class="fs-6"
                                          style="color: #5288F5;font-weight: 600;">erforderlich</span>
                                </div>
                            </div>
                        </div>
                        <div class="row g-0">
                                            <textarea class="form-control inputStyleDash grundBesInputStyle" type="text" id="desc"
                                                      rows="2">

                                             </textarea>
                        </div>
                    </div>
                </div>
                <div class="row g-0 justify-content-center">

                    <div class="text-center col-12 col-md-5 pt-3" @click="assignpendency">
                        <button  class="kontaktBtnDash w-100 py-1 fs-6">Pendenz erstellen</button>

                    </div>
                </div>
            </div>

        </div>


</template>
<script>
export default {
    mounted() {
        this.fetchnumbers();
        this.fetchtasks();

    },
    data() {
        return {
            todos: [],
            numbers: null,
            admin: null,
            costumer: null,
            readed: false,
            page: 1
        }
    },
    methods: {
        onChangeSelect(event) {
            this.admin = parseInt(event.target.value);
             axios.get('todos?admin_id=' + this.admin).then((response) => {
                 console.log(response.data);
                this.todos = response.data,
                this.admin = response.data.admins[0].id
            });

        },
        onChangeCostumer(event) {
            this.costumer = parseInt(event.target.value);
        },

        addnumber: function () {
            var val = document.getElementById('number')
            axios.get('addnumber?number=' + val.value).then(this.fetchnumbers
            );
            val.value = "";
        },

        assignpendency: function () {
            var task = document.getElementById('task');
            var desc = document.getElementById('desc');
            if (task.value.trim() != '' && desc.value.trim() !='') {
                axios.get('assignpendency?admin=' + this.admin + '&id=' + this.costumer + '&desc=' + document.getElementById('desc').value + '&task=' + document.getElementById('task').value);
                document.getElementById('alrt').innerHTML = "";
                document.getElementById('alrt').innerHTML += '<div style="background-color: #DEF2D5 !important;border-radius: 8px!important;color: #219653 !important;font-weight: 600 !important;border: none !important;padding-right: 0.75rem !important;padding-left: 0.75rem !important;padding-top: 0.6rem !important;padding-bottom: 0.6rem !important" class="alert alert-success alert-dismissible fade show" role="alert">\n' + 'Pendenz erfolgreich zugewiesen \n' + '                    <button style="padding: 0.85rem 1rem;" type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>\n' + '                </div>';
            }
            task.value = ''
            desc.value = ''
        },
        fetchnumbers() {
            axios.get('numbers').then((response) => {
                this.numbers = response.data;
            });
        },
        deletenumber: function (val) {
            axios.get('deletenumber?id=' + val).then(
                this.fetchnumbers
            );
        },
        fetchtasks: function () {
            axios.get('todos').then((response) => {
                this.todos = response.data,
                this.admin = response.data.admins[0].id
            });
        },
        fetchwithpagination:function (){
            this.page++;
            axios.get('todos?page=' + this.page).then((response) => {
                for (let i = 0; i < response.data.costumers.length; i++) {this.todos.costumers.push(response.data.costumers[i]);}
            });
        },
        kundenJaNein:function (){
            var x = document.getElementById('ja_or_nein');
            if (x.checked){
                document.getElementById('costumer-input').style.display = 'block';
            }else{
                document.getElementById('costumer-input').style.display = 'none';
            }
        },
        loadMore:function (){
            var x = document.getElementById('costumer-input').value;
            console.log(x);

            if(x == 0){
                this.fetchwithpagination();
            }

        },
        enableSelectDrop:function () {
            if (document.getElementById('toggleSwitch').checked) {
                document.getElementById("enableSelectDrop").disabled = false;
            }
            else {
                document.getElementById("enableSelectDrop").disabled = true;

            }
        }

    },



}

</script>




