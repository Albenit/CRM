@extends('template.navbar')
@section('content')
<div class="row justify-content-center">
    <div class="col-6" style="background: #ffebe5; border-radius: 25px; padding: 5%;">
        
    </div>
</div>
@endsection