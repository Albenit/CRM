<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PendingRejectedLead extends Model
{
    use HasFactory;
    public $table = 'pending_rejected_leads';


}
