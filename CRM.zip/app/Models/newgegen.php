<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class newgegen extends Model
{
    use HasFactory;
    public $table = "add_another_item_g";

    protected $guarded = [];
}
