<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RouteController extends Controller
{
public function testtt(Request $req){

}
public function testtt2(Request $req){
    
}
public function testtt3(Request $req){

}
public function niti(Request $req){

}
}