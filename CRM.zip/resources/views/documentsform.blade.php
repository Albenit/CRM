<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/8.4.6/css/intlTelInput.css" rel="stylesheet" />
    <link rel="stylesheet" href="assets/css/style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>Dokumentieren</title>
    <link rel="icon" type="image/png" href="{{config('app.url')}}crmFav.png">
</head>
<script src="{{ asset('js/app.js') }}" defer></script>

<body>

<style>
    /* Paste this css to your style sheet file or under head tag */
    /* This only works with JavaScript,
    if it's not present, don't show loader */
    .no-js #loader {
        display: none;
    }

    .js #loader {
        display: block;
        position: absolute;
        left: 100px;
        top: 0;
    }

    .se-pre-con {
        position: fixed;
        left: 0px;
        top: 0px;
        width: 100%;
        height: 100%;
        z-index: 99999;
        background: url(https://c.tenor.com/b8F9BMmvXlcAAAAi/loading-round.gif) center no-repeat #fff;
        background-size: 200px;
    }

    @media (max-width: 575.98px) {
        .se-pre-con {
            background-size: 100px;
        }
    }

    /*nav ARti*/
    @import url('https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;1,100;1,200;1,300;1,400;1,500;1,600;1,700&family=Poppins:wght@200;800;900&display=swap');

    body {
        font-family: 'Montserrat', sans-serif;
    }

    .nav-itemsss {
        height: 90vh !important;
        overflow-y: scroll !important;
        /* overflow-x: hidden !important; */
    }

    /* .nav-link {
        padding-right: 1.8rem !important;
        padding-left: 1.8rem !important;
    } */
    .nav-itemsss a:hover {
        background-color: #fff;
        color: #0C71C3;
    }

    .activeClassNav__,
    .activeClassNav__ span,
    .activeClassNav__ svg {
        background-color: #fff;
        color: #0C71C3 !important;
        fill: #0C71C3 !important;
    }

    .nav-itemsss a:hover span {
        color: #0C71C3;
    }

    .nav-itemsss a:hover svg {
        fill: #0C71C3;
    }

    .nav-itemsss a:focus,
    .nav-itemsss a:focus svg,
    .nav-itemsss a:focus span {
        background-color: #fff;
        color: #0C71C3;
        fill: #0C71C3;
    }

    @media (max-width: 999.98px) {
        .nav-texttt {
            display: none;
        }

        .navvv {
            width: fit-content !important;
            text-align: center !important;
            margin-left: auto !important;
            margin-right: auto !important;
        }

        /* .user-drop {
            position: fixed !important;
            bottom: 0;
            width: fit-content !important;
        } */
    }

    /* overflow 1 */
    .overflow-div1::-webkit-scrollbar {
        width: 0px;
    }

    .nav-texttt {
        font-family: 'Poppins';
        color: #fff;
    }

    @media (max-width: 978px) {
        #logo__311 {
            content: url('../img/Logo gjys.png');
            width: 20% !important;
        }
    }
</style>
<style>
    .sideBarStyle {
        position: fixed;
        left: 0px;
        top: 0px;
        height: 100%;
        background: #f7f7f7;
    }

    .bluePageIndicator {
        visibility: hidden;
    }

    .activePage {
        visibility: visible;

    }

    .passiveSvg {
        stroke: #A7A4A4 !important;
        fill: #A7A4A4 !important;
    }

    .activeSvgIndicator svg {
        stroke: #2F60DC !important;
        /* fill: #2F60DC !important; */

    }

    .activePageIndicator {
        font-size: 17px;
        color: #2F60DC;
        font-weight: 500;
    }

    .passivePageIndicator {
        font-size: 17px;
        color: #A7A4A4;
        cursor: pointer;
        font-weight: 400;

    }

    .navbarFirstHr {
        background-color: rgba(196, 196, 196, 0.9);
    }
    .removeTextOnMobile {
        display: block;
    }
    @media (max-width: 991.98px) {
        .removeTextOnMobile {
            display: none;
        }
    }
    @media (max-width: 767.98px) {
        .hideNavBarMobile {
            display: none;
        }

    }
</style>
<div class="row g-0" id="app">
    <div class="col-1 col-md-1 col-lg-2 h-100 hideNavBarMobile">
        <div class="sideBarStyle col-1 col-md-1 col-lg-2 px-1 px-lg-0">
            <div class="mx-4 mx-md-0">
                <div class="text-center mx-auto py-4 d-flex justify-content-center">
                    <svg style="min-width: 40px; max-width: 80px" class="img-fluid" viewBox="0 0 82 67" fill="none"
                         xmlns="http://www.w3.org/2000/svg">
                        <path d="M40.9994 23.0175L60.3103 55.386H21.6886L40.9994 23.0175Z" fill="#2F60DC" />
                        <path d="M62.5789 50.3509L45.7598 21.2193L79.3981 21.2193L62.5789 50.3509Z"
                              fill="#2F60DC" />
                        <path d="M19.4207 50.3509L2.60162 21.2193L36.2399 21.2193L19.4207 50.3509Z"
                              fill="#2F60DC" />
                        <circle cx="41.7195" cy="8.63158" r="8.63158" fill="#2F60DC" />
                        <circle cx="63.2985" cy="10.0702" r="7.19298" fill="#2F60DC" />
                        <circle cx="20.1402" cy="10.0702" r="7.19298" fill="#2F60DC" />
                    </svg>

                </div>

            </div>
            <div>
                <div class="row g-0">
                    <div class="col-auto pe-0 pe-lg-3">
                        <span class="bluePageIndicator {{request()->is('/') ? 'activePage' : 'passivePageIndicator' }}">
                        <svg style="min-width: 8px;" viewBox="0 0 10 49" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <path d="M0 0L10 24L0 49V0Z" fill="#2F60DC" />
                                </svg>

                        </span>
                    </div>

                    <div class="col col-lg-2 me-0 me-lg-2 my-auto" style="margin-left: -8px;">
                        <div class="mx-auto text-center">
                            @if(request()->is('/'))
                                <svg style="min-width: 20px; max-width: 25px" viewBox="0 0 25 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M9.91637 12.6H9.01637V13.5V19.75C9.01637 19.9128 8.8661 20.1 8.6247 20.1H4.7497C4.50829 20.1 4.35803 19.9128 4.35803 19.75V11V10.1H3.45803H1.99054L12.2234 1.18035C12.2237 1.18012 12.2239 1.17989 12.2242 1.17966C12.3767 1.0484 12.6227 1.0484 12.7752 1.17966C12.7755 1.17989 12.7757 1.18012 12.776 1.18035L23.0089 10.1H21.5414H20.6414V11V19.75C20.6414 19.9128 20.4911 20.1 20.2497 20.1H16.3747C16.1333 20.1 15.983 19.9128 15.983 19.75V13.5V12.6H15.083H9.91637Z" fill="#2F60DC" stroke="#2F60DC" stroke-width="1.8"/>
                                </svg>
                            @else
                                <a href="{{route('dashboard')}}" class="{{request()->is('/')  ? 'activePageIndicator' : 'passivePageIndicator' }} text-decoration-none">
                                    <svg style="min-width: 20px; max-width: 25px;"  class="img-fluid" viewBox="0 0 25 21"
                                 fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M9.91637 12.6H9.01637V13.5V19.75C9.01637 19.9128 8.8661 20.1 8.6247 20.1H4.7497C4.50829 20.1 4.35803 19.9128 4.35803 19.75V11V10.1H3.45803H1.99054L12.2234 1.18035C12.2237 1.18012 12.2239 1.17989 12.2242 1.17966C12.3767 1.0484 12.6227 1.0484 12.7752 1.17966C12.7755 1.17989 12.7757 1.18012 12.776 1.18035L23.0089 10.1H21.5414H20.6414V11V19.75C20.6414 19.9128 20.4911 20.1 20.2497 20.1H16.3747C16.1333 20.1 15.983 19.9128 15.983 19.75V13.5V12.6H15.083H9.91637Z"
                                    stroke="#A7A4A4" stroke-width="1.8" />
                            </svg>
                                </a>
                            @endif
                        </div>
                    </div>
                    <div class="col my-auto removeTextOnMobile">
                        <div>
                            <a href="{{route('dashboard')}}" class="{{request()->is('/')  ? 'activePageIndicator' : 'passivePageIndicator' }} text-decoration-none">Startseite</a>
                        </div>
                    </div>
                </div>
            </div>
            @if(Auth::user()->hasRole('backoffice') ||
                Auth::user()->hasRole('fs') || Auth::user()->hasRole('admin'))
            <div class="pt-3">
                <div class="row g-0">
                    <div class="col-auto pe-0 pe-lg-3">
                        <span class="bluePageIndicator {{request()->is('tasks') ? 'activePage' : '' }}">
                            <svg style="min-width: 8px;" viewBox="0 0 10 49" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <path d="M0 0L10 24L0 49V0Z" fill="#2F60DC" />
                            </svg>
                        </span>
                    </div>
                    <div class="col col-lg-2 me-0 me-lg-2 my-auto" style="margin-left: -8px;">
                        <div class="mx-auto text-center ">
                            @if(request()->is('tasks'))
                                <svg style="min-width: 15px; max-width: 25px;" viewBox="0 0 25 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <g clip-path="url(#clip0_197_3288)">
                                        <rect x="4" y="2" width="17" height="18" fill="#2F60DC"/>
                                        <path d="M19.2756 0.953899H15.3806L15.2222 0.356418C15.1679 0.148233 14.9476 0 14.6937 0H10.3063C10.0523 0 9.83295 0.148233 9.77772 0.356418L9.62016 0.953899H5.72439C4.29932 0.953899 3.14062 1.92756 3.14062 3.12462V18.8293C3.14062 20.0264 4.29932 21 5.72439 21H19.2756C20.7007 21 21.8602 20.0264 21.8602 18.8293V3.12462C21.8602 1.92756 20.7006 0.953899 19.2756 0.953899ZM20.1712 18.8293C20.1712 19.2439 19.7696 19.5813 19.2756 19.5813H5.72433C5.23115 19.5813 4.82952 19.2439 4.82952 18.8293V3.12462C4.82952 2.70998 5.23115 2.37266 5.72433 2.37266H9.24487L9.15501 2.71208C9.11869 2.8468 9.15831 2.98812 9.26059 3.09553C9.36361 3.20326 9.51952 3.26593 9.68357 3.26593H15.317C15.4812 3.26593 15.637 3.20326 15.7393 3.09553C15.8424 2.9878 15.882 2.84684 15.8457 2.71208L15.7558 2.37266H19.2756C19.7696 2.37266 20.1712 2.71003 20.1712 3.12462V18.8293Z" fill="#2F60DC"/>
                                        <path d="M9.07262 10.5013H11.3693L10.8235 10.1882C10.0531 9.74661 9.85528 8.86364 10.3814 8.21665C10.9068 7.57032 11.9582 7.40304 12.7285 7.84533L12.8184 7.89694V7.35558C12.8184 7.00469 12.4795 6.72 12.0621 6.72H9.07262C8.65537 6.72 8.31641 7.00473 8.31641 7.35558V9.86572C8.31641 10.2166 8.65537 10.5013 9.07262 10.5013Z" fill="#F7F7F7"/>
                                        <path d="M16.1054 7.01682L13.4581 9.12206L12.2524 8.43108C11.8689 8.20973 11.3427 8.29355 11.0788 8.61674C10.8157 8.94019 10.9147 9.3815 11.3007 9.60248L13.068 10.6163C13.2124 10.6994 13.3781 10.7399 13.5439 10.7399C13.7542 10.7399 13.9628 10.6742 14.1245 10.5456L17.2666 8.04696C17.6055 7.77784 17.6194 7.32859 17.2995 7.04421C16.9779 6.75984 16.4442 6.7477 16.1054 7.01682Z" fill="#F7F7F7"/>
                                        <path d="M11.7457 12.176H8.75621C8.33897 12.176 8 12.4607 8 12.8116V15.3217C8 15.6725 8.33897 15.9573 8.75621 15.9573H11.7457C12.163 15.9573 12.502 15.6725 12.502 15.3217V12.8116C12.502 12.4607 12.163 12.176 11.7457 12.176Z" fill="#F7F7F7"/>
                                    </g>
                                    <defs>
                                        <clipPath id="clip0_197_3288">
                                            <rect width="25" height="21" fill="white"/>
                                        </clipPath>
                                    </defs>
                                </svg>
                            @else
                                <a href="{{route('tasks')}}" class="text-decoration-none {{request()->is('tasks')  ? 'activePageIndicator' : 'passivePageIndicator' }}">
                                    <svg style="min-width: 20px; max-width: 25px;" viewBox="0 0 25 21" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <g clip-path="url(#clip0_171_588)">
                                    <path
                                        d="M19.2756 0.953899H15.3806L15.2222 0.356418C15.1679 0.148233 14.9476 0 14.6937 0H10.3063C10.0523 0 9.83295 0.148233 9.77772 0.356418L9.62016 0.953899H5.72439C4.29932 0.953899 3.14062 1.92756 3.14062 3.12462V18.8293C3.14062 20.0264 4.29932 21 5.72439 21H19.2756C20.7007 21 21.8602 20.0264 21.8602 18.8293V3.12462C21.8602 1.92756 20.7006 0.953899 19.2756 0.953899ZM20.1712 18.8293C20.1712 19.2439 19.7696 19.5813 19.2756 19.5813H5.72433C5.23115 19.5813 4.82952 19.2439 4.82952 18.8293V3.12462C4.82952 2.70998 5.23115 2.37266 5.72433 2.37266H9.24487L9.15501 2.71208C9.11869 2.8468 9.15831 2.98812 9.26059 3.09553C9.36361 3.20326 9.51953 3.26593 9.68357 3.26593H15.317C15.4812 3.26593 15.637 3.20326 15.7393 3.09553C15.8424 2.9878 15.882 2.84684 15.8457 2.71208L15.7558 2.37266H19.2756C19.7696 2.37266 20.1712 2.71003 20.1712 3.12462V18.8293Z"
                                        fill="#A7A4A4" />
                                    <path
                                        d="M9.07262 10.5013H11.3693L10.8235 10.1882C10.0531 9.74661 9.85528 8.86364 10.3814 8.21665C10.9068 7.57032 11.9582 7.40304 12.7285 7.84533L12.8184 7.89694V7.35558C12.8184 7.00469 12.4795 6.72 12.0621 6.72H9.07262C8.65537 6.72 8.31641 7.00473 8.31641 7.35558V9.86572C8.31641 10.2166 8.65537 10.5013 9.07262 10.5013Z"
                                        fill="#A7A4A4" />
                                    <path
                                        d="M16.1054 7.01682L13.4581 9.12206L12.2524 8.43108C11.8689 8.20973 11.3427 8.29355 11.0788 8.61674C10.8157 8.94019 10.9147 9.3815 11.3007 9.60248L13.068 10.6163C13.2124 10.6994 13.3781 10.7399 13.5439 10.7399C13.7542 10.7399 13.9628 10.6742 14.1245 10.5456L17.2666 8.04696C17.6055 7.77784 17.6194 7.32859 17.2995 7.04421C16.9779 6.75984 16.4442 6.7477 16.1054 7.01682Z"
                                        fill="#A7A4A4" />
                                    <path
                                        d="M11.7457 12.176H8.75621C8.33897 12.176 8 12.4607 8 12.8116V15.3217C8 15.6725 8.33897 15.9573 8.75621 15.9573H11.7457C12.163 15.9573 12.502 15.6725 12.502 15.3217V12.8116C12.502 12.4607 12.163 12.176 11.7457 12.176Z"
                                        fill="#A7A4A4" />
                                </g>
                                <defs>
                                    <clipPath id="clip0_171_588">
                                        <rect width="25" height="21" fill="white" />
                                    </clipPath>
                                </defs>
                            </svg>
                                </a>
                            @endif

                        </div>
                    </div>
                    <div class="col my-auto removeTextOnMobile">
                        <div>
                            <a href="{{route('tasks')}}" class="text-decoration-none {{request()->is('tasks')  ? 'activePageIndicator' : 'passivePageIndicator' }}">Pendenzen</a>
                        </div>
                    </div>
                </div>
            </div>
            @endif
            @if(Auth::user()->hasRole('admin') ||
                Auth::user()->hasRole('fs') ||
                Auth::user()->hasRole('salesmanager')
                ||Auth::user()->hasRole('menagment'))
                <div class="pt-3">
                    <div class="row g-0">
                        <div class="col-auto pe-0 pe-lg-3">
                        <span class="bluePageIndicator {{request()->is('leads')  ? 'activePage' : '' }}">
                            <svg style="min-width: 8px;" viewBox="0 0 10 49" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <path d="M0 0L10 24L0 49V0Z" fill="#2F60DC" />
                            </svg>
                        </span>
                        </div>
                        <div class="col col-lg-2 me-0 me-lg-2 my-auto" style="margin-left: -8px;">
                            <div class="mx-auto text-center ">
                                @if(request()->is('leads'))
                                    <a href="{{route('leads')}}" class="{{ request()->is('leads')  ? 'activePageIndicator' : 'passivePageIndicator' }} text-decoration-none">

                                    <svg xmlns="http://www.w3.org/2000/svg" style="min-width: 15px; max-width: 22px;" fill="currentColor" class="bi bi-hdd-stack" viewBox="0 0 16 16">
                                        <path d="M14 10a1 1 0 0 1 1 1v1a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1v-1a1 1 0 0 1 1-1h12zM2 9a2 2 0 0 0-2 2v1a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-1a2 2 0 0 0-2-2H2z"/>
                                        <path d="M5 11.5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0zm-2 0a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0zM14 3a1 1 0 0 1 1 1v1a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h12zM2 2a2 2 0 0 0-2 2v1a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H2z"/>
                                        <path d="M5 4.5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0zm-2 0a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0z"/>
                                    </svg>
                                    </a>

                                @else
                                    <a href="{{route('leads')}}" class="{{ request()->is('leads')  ? 'activePageIndicator' : 'passivePageIndicator' }} text-decoration-none">
                                        <svg xmlns="http://www.w3.org/2000/svg" style="min-width: 15px; max-width: 22px;" fill="currentColor" class="bi bi-hdd-stack" viewBox="0 0 16 16">
                                            <path d="M14 10a1 1 0 0 1 1 1v1a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1v-1a1 1 0 0 1 1-1h12zM2 9a2 2 0 0 0-2 2v1a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-1a2 2 0 0 0-2-2H2z"/>
                                            <path d="M5 11.5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0zm-2 0a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0zM14 3a1 1 0 0 1 1 1v1a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h12zM2 2a2 2 0 0 0-2 2v1a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H2z"/>
                                            <path d="M5 4.5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0zm-2 0a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0z"/>
                                        </svg>
                                    </a>
                                @endif
                            </div>
                        </div>
                        <div class="col my-auto removeTextOnMobile">
                            <div>
                                <a href="{{route('leads')}}" class="{{ request()->is('leads')  ? 'activePageIndicator' : 'passivePageIndicator' }} text-decoration-none">Leads</a>
                            </div>
                        </div>
                    </div>
                </div>
            @endif
            @if(Auth::check())
                @if(!auth()->user()->hasRole('callagent'))
            <div class="pt-3">
                <div class="row g-0">
                    <div class="col-auto pe-0 pe-lg-3">
                        <span class="bluePageIndicator {{request()->is('costumers')  ? 'activePage' : '' }}">
                            <svg style="min-width: 8px;" viewBox="0 0 10 49" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <path d="M0 0L10 24L0 49V0Z" fill="#2F60DC" />
                            </svg>
                        </span>
                    </div>
                    <div class="col col-lg-2 me-0 me-lg-2 my-auto" style="margin-left: -8px;">
                        <div class="mx-auto text-center ">
                            @if(request()->is('costumers'))
                                <svg style="min-width: 15px; max-width: 25px;" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M14.6364 16.3418C15.5814 15.3135 16.1605 13.9336 16.1605 12.4189C16.1605 9.24902 13.6252 6.6709 10.5079 6.6709C7.39069 6.6709 4.8554 9.24902 4.8554 12.4189C4.8554 13.9395 5.44025 15.3223 6.39098 16.3535C5.78597 16.7109 5.22417 17.1533 4.71424 17.6689C3.16425 19.2451 2.30859 21.3428 2.30859 23.5752C2.30859 24.9287 2.63703 25.8897 3.3083 26.5078C4.38868 27.501 5.99628 27.3311 7.85453 27.1377C8.70731 27.0498 9.5889 26.9561 10.5195 26.9561C11.45 26.9561 12.3316 27.0469 13.1844 27.1377C13.9104 27.2139 14.599 27.2842 15.2328 27.2842C16.221 27.2842 17.0738 27.1113 17.7306 26.5049C18.4048 25.8867 18.7303 24.9287 18.7303 23.5723C18.7303 21.3428 17.8747 19.2451 16.3247 17.666C15.8176 17.1445 15.2472 16.7021 14.6364 16.3418ZM10.5079 8.5459C12.6082 8.5459 14.3166 10.2832 14.3166 12.4189C14.3166 14.5547 12.6082 16.292 10.5079 16.292C8.40769 16.292 6.69925 14.5547 6.69925 12.4189C6.70213 10.2832 8.41057 8.5459 10.5079 8.5459ZM16.5004 25.1133C16.028 25.5469 14.7401 25.4121 13.3774 25.2715C12.5189 25.1836 11.548 25.0811 10.5252 25.0811C9.50247 25.0811 8.53157 25.1836 7.67303 25.2715C6.31031 25.4121 5.0225 25.5469 4.55002 25.1133C4.29073 24.8731 4.1582 24.3574 4.1582 23.5723C4.1582 20.8887 5.77445 18.5801 8.06773 17.5986C8.80815 17.9619 9.63788 18.1641 10.5137 18.1641C11.4673 18.1641 12.3662 17.9209 13.1556 17.4961C13.1239 17.54 13.0893 17.584 13.0519 17.625C15.3106 18.6211 16.8951 20.9121 16.8951 23.5693C16.8923 24.3545 16.7597 24.8731 16.5004 25.1133Z" fill="#2F60DC"/>
                                    <path d="M24.7417 13.6728C24.2289 13.1514 23.6585 12.709 23.0477 12.3457C24.0071 11.3027 24.5891 9.89648 24.5718 8.35546C24.5631 7.68163 24.4421 7.0371 24.2232 6.43652C24.2232 6.43359 24.2203 6.43066 24.2203 6.4248C24.2116 6.40429 24.2059 6.38378 24.1972 6.36328C23.3906 4.21581 21.3508 2.6748 18.9653 2.65429C16.9861 2.63671 15.2373 3.65624 14.2117 5.21484C13.8026 5.83886 14.2405 6.67382 14.978 6.67382C15.2863 6.67382 15.5715 6.51855 15.7444 6.25781C15.8913 6.03515 16.0613 5.82714 16.2485 5.63964C16.2975 5.61035 16.3465 5.57519 16.3926 5.53417C17.084 4.91015 17.9973 4.53515 18.997 4.55566C20.6306 4.58789 22.0192 5.67773 22.5263 7.17773C22.6645 7.59374 22.7337 8.04199 22.7222 8.50488C22.6732 10.4853 21.1405 12.126 19.1958 12.2666C19.1036 12.2725 19.0114 12.2754 18.9221 12.2783C18.8616 12.2783 18.8011 12.2842 18.7435 12.2959C18.3142 12.2959 17.9397 12.6035 17.8533 13.0342C17.8533 13.04 17.8504 13.0459 17.8504 13.0518C17.7351 13.6113 18.1414 14.1445 18.7032 14.168C18.7752 14.1709 18.8472 14.1709 18.9221 14.1709C19.8066 14.1709 20.6421 13.9629 21.3883 13.5937C23.647 14.5898 25.3064 16.9189 25.3064 19.5762C25.3064 20.3584 25.1739 20.8769 24.9146 21.1172C24.4421 21.5508 23.1543 21.416 21.7916 21.2754C21.5323 21.249 20.9676 21.1963 20.9561 21.2021C20.4548 21.2109 20.0515 21.6269 20.0515 22.1367C20.0515 22.6465 20.4519 23.0596 20.9475 23.0713C20.9503 23.0742 21.3911 23.1182 21.6015 23.1416C22.3275 23.2178 23.016 23.2881 23.6498 23.2881C24.638 23.2881 25.4908 23.1152 26.1477 22.5088C26.8218 21.8906 27.1474 20.9326 27.1474 19.5762C27.1474 17.3467 26.2917 15.249 24.7417 13.6728Z" fill="#2F60DC"/>
                                    <path d="M15 12.5C15 14.9853 12.4853 25.5 10 25.5C7.51472 25.5 6 14.9853 6 12.5C6 10.0147 8.01472 8 10.5 8C12.9853 8 15 10.0147 15 12.5Z" fill="#2F60DC"/>
                                    <path d="M6.35862 17.6272C8.21545 17.3161 15 16 16.8975 20.9312C20.5 28.5 7.85473 26.1888 5.99791 26.4999C4.14108 26.811 4.15078 25.0798 3.74011 22.6286C3.32945 20.1775 4.5018 17.9383 6.35862 17.6272Z" fill="#2F60DC"/>
                                </svg>
                            @else
                                <a href="{{route('costumers')}}" class="text-decoration-none {{request()->is('costumers')  ? 'activePageIndicator' : 'passivePageIndicator' }}">
                                    <svg style="min-width: 15px; max-width: 25px;" viewBox="0 0 30 30" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M14.6364 16.3418C15.5814 15.3135 16.1605 13.9336 16.1605 12.4189C16.1605 9.24902 13.6252 6.6709 10.5079 6.6709C7.39069 6.6709 4.8554 9.24902 4.8554 12.4189C4.8554 13.9395 5.44025 15.3223 6.39098 16.3535C5.78597 16.7109 5.22417 17.1533 4.71424 17.6689C3.16425 19.2451 2.30859 21.3428 2.30859 23.5752C2.30859 24.9287 2.63703 25.8897 3.3083 26.5078C4.38868 27.501 5.99628 27.3311 7.85453 27.1377C8.70731 27.0498 9.5889 26.9561 10.5195 26.9561C11.45 26.9561 12.3316 27.0469 13.1844 27.1377C13.9104 27.2139 14.599 27.2842 15.2328 27.2842C16.221 27.2842 17.0738 27.1113 17.7306 26.5049C18.4048 25.8867 18.7303 24.9287 18.7303 23.5723C18.7303 21.3428 17.8747 19.2451 16.3247 17.666C15.8176 17.1445 15.2472 16.7021 14.6364 16.3418ZM10.5079 8.5459C12.6082 8.5459 14.3166 10.2832 14.3166 12.4189C14.3166 14.5547 12.6082 16.292 10.5079 16.292C8.40769 16.292 6.69925 14.5547 6.69925 12.4189C6.70213 10.2832 8.41057 8.5459 10.5079 8.5459ZM16.5004 25.1133C16.028 25.5469 14.7401 25.4121 13.3774 25.2715C12.5189 25.1836 11.548 25.0811 10.5252 25.0811C9.50247 25.0811 8.53157 25.1836 7.67303 25.2715C6.31031 25.4121 5.0225 25.5469 4.55002 25.1133C4.29073 24.8731 4.1582 24.3574 4.1582 23.5723C4.1582 20.8887 5.77445 18.5801 8.06773 17.5986C8.80815 17.9619 9.63788 18.1641 10.5137 18.1641C11.4673 18.1641 12.3662 17.9209 13.1556 17.4961C13.1239 17.54 13.0893 17.584 13.0519 17.625C15.3106 18.6211 16.8951 20.9121 16.8951 23.5693C16.8923 24.3545 16.7597 24.8731 16.5004 25.1133Z"
                                    fill="#A7A4A4" />
                                <path
                                    d="M24.7417 13.6729C24.2289 13.1514 23.6585 12.709 23.0477 12.3457C24.0071 11.3027 24.5891 9.89649 24.5718 8.35548C24.5631 7.68165 24.4421 7.03712 24.2232 6.43653C24.2232 6.4336 24.2203 6.43067 24.2203 6.42481C24.2116 6.40431 24.2059 6.3838 24.1972 6.36329C23.3906 4.21583 21.3508 2.67481 18.9653 2.65431C16.9861 2.63673 15.2373 3.65626 14.2117 5.21485C13.8026 5.83888 14.2405 6.67384 14.978 6.67384C15.2863 6.67384 15.5715 6.51856 15.7444 6.25782C15.8913 6.03517 16.0613 5.82716 16.2485 5.63966C16.2975 5.61036 16.3465 5.5752 16.3926 5.53419C17.084 4.91017 17.9973 4.53517 18.997 4.55567C20.6306 4.5879 22.0192 5.67774 22.5263 7.17774C22.6645 7.59376 22.7337 8.042 22.7222 8.50489C22.6732 10.4854 21.1405 12.126 19.1958 12.2666C19.1036 12.2725 19.0114 12.2754 18.9221 12.2783C18.8616 12.2783 18.8011 12.2842 18.7435 12.2959C18.3142 12.2959 17.9397 12.6035 17.8533 13.0342C17.8533 13.04 17.8504 13.0459 17.8504 13.0518C17.7351 13.6113 18.1414 14.1445 18.7032 14.168C18.7752 14.1709 18.8472 14.1709 18.9221 14.1709C19.8066 14.1709 20.6421 13.9629 21.3883 13.5938C23.647 14.5899 25.3064 16.919 25.3064 19.5762C25.3064 20.3584 25.1739 20.877 24.9146 21.1172C24.4421 21.5508 23.1543 21.416 21.7916 21.2754C21.5323 21.249 20.9676 21.1963 20.9561 21.2022C20.4548 21.2109 20.0515 21.627 20.0515 22.1367C20.0515 22.6465 20.4519 23.0596 20.9475 23.0713C20.9503 23.0742 21.3911 23.1182 21.6015 23.1416C22.3275 23.2178 23.016 23.2881 23.6498 23.2881C24.638 23.2881 25.4908 23.1152 26.1477 22.5088C26.8218 21.8906 27.1474 20.9326 27.1474 19.5762C27.1474 17.3467 26.2917 15.249 24.7417 13.6729Z"
                                    fill="#A7A4A4" />
                            </svg>
                                </a>
                            @endif
                        </div>
                    </div>

                    <div class="col my-auto removeTextOnMobile">
                        <div>
                            <a href="{{route('costumers')}}" class="text-decoration-none {{request()->is('costumers')  ? 'activePageIndicator' : 'passivePageIndicator' }}">Kunden</a>
                        </div>
                    </div>

                </div>
            </div>
            @endif
            @endif
            @if(Auth::user()->hasRole('fs') ||
                Auth::user()->hasRole('salesmanager') ||
                Auth::user()->hasRole('menagment') ||
                Auth::user()->hasRole('admin'))
            <div class="pt-3">
                <div class="row g-0">
                    <div class="col-auto pe-0 pe-lg-3">
                        <span class="bluePageIndicator {{request()->is('Appointments')  ? 'activePage' : '' }}">
                            <svg style="min-width: 8px;" viewBox="0 0 10 49" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <path d="M0 0L10 24L0 49V0Z" fill="#2F60DC" />
                            </svg>
                        </span>
                    </div>
                    <div class="col col-lg-2 me-0 me-lg-2 my-auto" style="margin-left: -8px;">
                        <div class="mx-auto text-center ">
                            @if(request()->is('Appointments'))
                            <svg width="21" viewBox="0 0 18 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect x="1.33594" y="5.63005" width="14.5325" height="12.3154" fill="#2F60DC"/>
                                <path d="M15.4942 6.33333V17.4167H1.54942V6.33333H15.4942ZM15.4942 4.75H1.54942C0.694141 4.75 0 5.45775 0 6.33333V17.4167C0 18.2923 0.694141 19 1.54942 19H15.4942C16.351 19 17.0436 18.2923 17.0436 17.4167V6.33333C17.0436 5.45775 16.351 4.75 15.4942 4.75ZM16.2689 1.58333H13.9448V0.791667C13.9448 0.354667 13.5977 0 13.1701 0C12.7424 0 12.3954 0.354667 12.3954 0.791667V1.58333H4.64827V0.791667C4.64827 0.354667 4.3012 0 3.87355 0C3.44591 0 3.09884 0.354667 3.09884 0.791667V1.58333H0.774711C0.347071 1.58333 0 1.938 0 2.375C0 2.812 0.347071 3.16667 0.774711 3.16667H16.2689C16.6966 3.16667 17.0436 2.812 17.0436 2.375C17.0436 1.938 16.6966 1.58333 16.2689 1.58333ZM4.64827 7.91667H3.09884V9.5H4.64827V7.91667ZM7.74711 7.91667H6.19769V9.5H7.74711V7.91667ZM10.846 7.91667H9.29653V9.5H10.846V7.91667ZM13.9448 7.91667H12.3954V9.5H13.9448V7.91667ZM4.64827 11.0833H3.09884V12.6667H4.64827V11.0833ZM7.74711 11.0833H6.19769V12.6667H7.74711V11.0833ZM10.846 11.0833H9.29653V12.6667H10.846V11.0833ZM13.9448 11.0833H12.3954V12.6667H13.9448V11.0833ZM4.64827 14.25H3.09884V15.8333H4.64827V14.25ZM7.74711 14.25H6.19769V15.8333H7.74711V14.25ZM10.846 14.25H9.29653V15.8333H10.846V14.25ZM13.9448 14.25H12.3954V15.8333H13.9448V14.25Z" fill="#2F60DC"/>
                                <rect x="2.63867" y="8.26906" width="1.75934" height="1.75934" fill="#F7F7F7"/>
                                <rect x="2.63867" y="10.9081" width="1.75934" height="1.75934" fill="#F7F7F7"/>
                                <rect x="2.63867" y="13.5471" width="1.75934" height="1.75934" fill="#F7F7F7"/>
                                <rect x="6.1582" y="8.26906" width="1.75934" height="1.75934" fill="#F7F7F7"/>
                                <rect x="6.1582" y="10.9081" width="1.75934" height="1.75934" fill="#F7F7F7"/>
                                <rect x="6.1582" y="13.5471" width="1.75934" height="1.75934" fill="#F7F7F7"/>
                                <rect x="9.67773" y="8.26906" width="1.75934" height="1.75934" fill="#F7F7F7"/>
                                <rect x="9.67773" y="10.9081" width="1.75934" height="1.75934" fill="#F7F7F7"/>
                                <rect x="9.67773" y="13.5471" width="1.75934" height="1.75934" fill="#F7F7F7"/>
                                <rect x="13.1953" y="8.26906" width="1.75934" height="1.75934" fill="#F7F7F7"/>
                                <rect x="13.1953" y="10.9081" width="1.75934" height="1.75934" fill="#F7F7F7"/>
                                <rect x="13.1953" y="13.5471" width="1.75934" height="1.75934" fill="#F7F7F7"/>
                                </svg>

                            @else
                            <a href="{{route('Appointments')}}" class="{{ request()->is('Appointments')  ? 'activePageIndicator' : 'passivePageIndicator' }} text-decoration-none">
                            <svg width="21" viewBox="0 0 18 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M15.4942 6.33333V17.4167H1.54942V6.33333H15.4942ZM15.4942 4.75H1.54942C0.694141 4.75 0 5.45775 0 6.33333V17.4167C0 18.2923 0.694141 19 1.54942 19H15.4942C16.351 19 17.0436 18.2923 17.0436 17.4167V6.33333C17.0436 5.45775 16.351 4.75 15.4942 4.75ZM16.2689 1.58333H13.9448V0.791667C13.9448 0.354667 13.5977 0 13.1701 0C12.7424 0 12.3954 0.354667 12.3954 0.791667V1.58333H4.64827V0.791667C4.64827 0.354667 4.3012 0 3.87355 0C3.44591 0 3.09884 0.354667 3.09884 0.791667V1.58333H0.774711C0.347071 1.58333 0 1.938 0 2.375C0 2.812 0.347071 3.16667 0.774711 3.16667H16.2689C16.6966 3.16667 17.0436 2.812 17.0436 2.375C17.0436 1.938 16.6966 1.58333 16.2689 1.58333ZM4.64827 7.91667H3.09884V9.5H4.64827V7.91667ZM7.74711 7.91667H6.19769V9.5H7.74711V7.91667ZM10.846 7.91667H9.29653V9.5H10.846V7.91667ZM13.9448 7.91667H12.3954V9.5H13.9448V7.91667ZM4.64827 11.0833H3.09884V12.6667H4.64827V11.0833ZM7.74711 11.0833H6.19769V12.6667H7.74711V11.0833ZM10.846 11.0833H9.29653V12.6667H10.846V11.0833ZM13.9448 11.0833H12.3954V12.6667H13.9448V11.0833ZM4.64827 14.25H3.09884V15.8333H4.64827V14.25ZM7.74711 14.25H6.19769V15.8333H7.74711V14.25ZM10.846 14.25H9.29653V15.8333H10.846V14.25ZM13.9448 14.25H12.3954V15.8333H13.9448V14.25Z" fill="#A7A4A4"/>
                            </svg>

                            </a>
                            @endif
                        </div>
                    </div>
                    <div class="col my-auto removeTextOnMobile">
                        <div>
                            <a href="{{route('Appointments')}}" class="{{ request()->is('Appointments')  ? 'activePageIndicator' : 'passivePageIndicator' }} text-decoration-none">Kalender</a>
                        </div>
                    </div>
                </div>
            </div>
            @endif
            @if(Auth::check() && !auth()->user()->hasRole('callagent'))
            <div class="pt-3">
                <div class="row g-0">
                    <div class="col-auto pe-0 pe-lg-3">
                        <span class="bluePageIndicator {{request()->is('hr_view') ? 'activePage' : 'passivePageIndicator' }}">
                            <svg style="min-width: 8px;" viewBox="0 0 10 49" fill="none"
                                         xmlns="http://www.w3.org/2000/svg">
                                        <path d="M0 0L10 24L0 49V0Z" fill="#2F60DC" />
                                    </svg>
                            </span>
                    </div>
                    <div class="col col-lg-2 me-0 me-lg-2 my-auto" style="margin-left: -8px;">
                        <div class="mx-auto text-center ">
                            @if(request()->is('hr_view'))
                            
                                <svg width="21" viewBox="0 0 21 23" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M17.8852 6H16.9154C15.6615 6 14.6441 6.81297 14.6441 7.81565V7.94884L17.5114 6.32089C17.514 6.3194 17.5173 6.31914 17.5201 6.31766C17.5173 6.3194 17.5147 6.3198 17.5123 6.3215L13.7258 9.10456L9.84322 10.4264C9.26974 10.6212 9.00269 11.1511 9.24654 11.6094C9.42991 11.9525 9.84688 12.1583 10.2857 12.1583C10.4331 12.1583 10.5829 12.135 10.7264 12.0857L14.7879 10.7034C14.9069 10.6632 15.0152 10.6071 15.1097 10.5374L19.0388 7.64895C19.0421 7.64655 19.0431 7.64292 19.0465 7.64052C19.0432 7.64332 19.0422 7.64681 19.0394 7.64964L15.5679 10.9358C15.4674 11.0309 15.3451 11.1018 15.2109 11.1479L15.0531 11.2015L14.6441 11.3406L14.6458 21.9177C14.6458 22.5155 15.2524 23 15.9997 23C16.3083 23 16.5903 22.914 16.8174 22.7745C16.6438 22.5187 16.5355 22.2299 16.5355 21.9177V15.4684H17.4382V21.9177C17.4382 22.5155 18.0446 23 18.7921 23C19.5393 23 20.1455 22.5155 20.1455 21.9177C20.1455 21.9177 20.1562 12.8188 20.1562 7.81561C20.1563 6.81297 19.1393 6 17.8852 6Z" fill="#2F60DC"/>
                                    <path d="M17.5802 5.46087C19.0893 5.46087 20.311 4.23884 20.311 2.73069C20.311 1.22203 19.0894 0 17.5802 0C16.0723 0 14.8496 1.22203 14.8496 2.73069C14.8496 4.23884 16.0724 5.46087 17.5802 5.46087Z" fill="#2F60DC"/>
                                    <path d="M2.73063 5.46087C4.23861 5.46087 5.46138 4.23884 5.46138 2.73069C5.46138 1.22203 4.23861 0 2.73063 0C1.2217 0 0 1.22203 0 2.73069C0 4.23884 1.2217 5.46087 2.73063 5.46087Z" fill="#2F60DC"/>
                                    <path d="M6.36673 8.96265L3.28682 6.64107L5.7952 8.15382V7.81565C5.7952 6.81297 4.75445 6 3.47172 6H2.47973C1.19655 6 0.15625 6.81297 0.15625 7.81565C0.15625 12.9789 0.167196 21.9177 0.167196 21.9177C0.167196 22.5155 0.787479 23 1.55179 23C2.31649 23 2.93677 22.5155 2.93677 21.9177V15.4684H3.86025V21.9177C3.86025 22.2298 3.74911 22.5187 3.57152 22.7745C3.80434 22.9139 4.09268 23 4.40849 23C5.1728 23 5.79347 22.5155 5.79347 21.9177L5.7952 11.3279L4.87352 10.8157L4.57893 10.6522C4.56179 10.6424 4.54531 10.6304 4.53196 10.618L1.68353 7.93955L4.87173 10.3425C4.94405 10.3964 5.02436 10.4433 5.11181 10.4811L8.91661 12.1374C8.82089 12.0416 8.7355 11.9384 8.67139 11.8215C8.35117 11.2335 8.57405 10.5776 9.15625 10.1774L6.36673 8.96265Z" fill="#2F60DC"/>
                                    </svg>
                            @else
                                <a href="{{route('hr_view')}}" class="{{ request()->is('hr_view')  ? 'activePageIndicator' : 'passivePageIndicator' }} text-decoration-none">
                                
                                <svg width="21" viewBox="0 0 21 23" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M19.4575 7.92442C19.456 7.92668 19.4542 7.92927 19.4523 7.93207C19.4424 7.94637 19.425 7.97011 19.3997 7.99633L19.3916 8.00474L19.3832 8.01276L15.9116 11.299L15.9116 11.299C15.7539 11.4482 15.5678 11.554 15.3734 11.6208L15.3717 11.6213L15.2141 11.6749L15.2139 11.6749L15.1442 11.6986L15.1458 21.9176V21.9177C15.1458 22.1406 15.4182 22.5 15.9997 22.5C16.0429 22.5 16.0852 22.4976 16.1264 22.493C16.0687 22.3128 16.0355 22.1205 16.0355 21.9177V15.4684V14.9684H16.5355H17.4382H17.9382V15.4684V21.9177C17.9382 22.1406 18.2104 22.5 18.7921 22.5C19.3734 22.5 19.6455 22.1407 19.6455 21.9177V21.9171L20.1455 21.9177C19.6455 21.9171 19.6455 21.9171 19.6455 21.917V21.9167L19.6456 21.9154L19.6456 21.9105L19.6456 21.8908L19.6457 21.8137L19.646 21.5164L19.6472 20.4173C19.6482 19.4861 19.6496 18.1924 19.6509 16.7424C19.6536 13.8423 19.6562 10.317 19.6562 7.81561V7.81558C19.6563 7.18777 18.9734 6.5 17.8852 6.5H17.6484L17.6683 6.5337L17.8084 6.72438L17.8058 6.72629M19.4575 7.92442C19.4597 7.92105 19.4614 7.91843 19.4624 7.91699L19.4624 7.91687C19.4615 7.9184 19.4598 7.92098 19.4575 7.92442ZM19.4575 7.92442C19.4521 7.93245 19.4431 7.9452 19.4305 7.96041C19.4343 7.95573 19.4373 7.95174 19.4397 7.9487L19.4447 7.94192L19.4404 7.9476C19.4363 7.95296 19.4296 7.96156 19.4207 7.97175C19.4145 7.97878 19.4072 7.98675 19.3986 7.99529C19.3946 7.99932 19.3903 8.00348 19.3857 8.00773C19.3845 8.00893 19.3831 8.01013 19.3818 8.01134C19.3774 8.01539 19.3727 8.01948 19.3678 8.02359L19.2547 7.87707L19.1939 7.79828L18.7573 7.23267C18.741 7.24421 18.7264 7.256 18.7134 7.26759L14.8136 10.1345L14.8128 10.1351C14.7622 10.1724 14.7006 10.2051 14.6279 10.2297L14.6268 10.23L10.5653 11.6124L10.564 11.6128C10.4755 11.6432 10.3809 11.6583 10.2857 11.6583C9.9812 11.6583 9.7629 11.5143 9.68774 11.3742C9.64528 11.2941 9.6472 11.2189 9.68483 11.1442C9.72603 11.0625 9.824 10.961 10.004 10.8999L10.0044 10.8997L13.8869 9.57788L13.9598 9.55306L14.0219 9.50745L17.7841 6.74224C17.7859 6.74115 17.7877 6.74003 17.7895 6.73888L17.7892 6.7385L17.8058 6.72629M17.8058 6.72629L17.6775 6.54938L17.7889 6.738C17.7944 6.73436 17.8001 6.73047 17.8058 6.72629ZM19.0388 7.64895L18.6957 7.28653L18.6758 7.30537M19.0388 7.64895L18.6728 7.3082M19.0388 7.64895L19.0387 7.64897L19.0388 7.64895ZM18.6758 7.30537C18.689 7.29131 18.7057 7.27516 18.7263 7.25867L18.726 7.25833L18.714 7.26715C18.6983 7.28115 18.6845 7.29514 18.6728 7.3082M18.6758 7.30537C18.671 7.31047 18.6667 7.3153 18.6628 7.31976C18.6609 7.32201 18.6591 7.32417 18.6573 7.32623C18.662 7.3205 18.6672 7.31446 18.6728 7.3082M18.6758 7.30537L18.6728 7.3082M19.4638 7.91473C19.464 7.91444 19.4635 7.91516 19.463 7.91606L19.4634 7.91541L19.4638 7.91473Z" fill="#A7A4A4" stroke="#A7A4A4"/>
                                <path d="M19.811 2.73067V2.73069C19.811 3.96267 18.8132 4.96087 17.5802 4.96087C16.3484 4.96087 15.3496 3.96255 15.3496 2.73069C15.3496 1.49825 16.3484 0.5 17.5802 0.5C18.8132 0.5 19.811 1.49815 19.811 2.73067Z" fill="#A7A4A4" stroke="#A7A4A4"/>
                                <path d="M4.96138 2.73069C4.96138 3.96254 3.96262 4.96087 2.73063 4.96087C1.49783 4.96087 0.5 3.96268 0.5 2.73069C0.5 1.49813 1.49789 0.5 2.73063 0.5C3.96256 0.5 4.96138 1.49827 4.96138 2.73069Z" fill="#A7A4A4" stroke="#A7A4A4"/>
                                <path d="M6.06577 9.36192L6.11294 9.39748L6.16711 9.42107L8.30056 10.3501C8.13494 10.6081 8.0359 10.8998 8.02418 11.2036L5.31139 10.0226L5.31016 10.0221C5.25915 10 5.21278 9.97295 5.17136 9.94223L1.98448 7.54026L1.34101 8.3038L4.18945 10.9823L4.18944 10.9823L4.19238 10.985C4.23508 11.0245 4.28269 11.0588 4.33127 11.0865L4.33126 11.0866L4.33622 11.0893L4.63064 11.2528L4.63081 11.2529L5.29516 11.6221L5.29347 21.9176V21.9177C5.29347 22.1314 5.01866 22.5 4.40849 22.5C4.36046 22.5 4.3136 22.4972 4.26809 22.4919C4.32652 22.3123 4.36025 22.1203 4.36025 21.9177V15.4684V14.9684H3.86025H2.93677H2.43677V15.4684V21.9177C2.43677 22.1315 2.16225 22.5 1.55179 22.5C0.941821 22.5 0.667196 22.1316 0.667196 21.9177L0.667195 21.9171L0.167196 21.9177C0.667195 21.9171 0.667195 21.9171 0.667195 21.917L0.667195 21.9167L0.667193 21.9155L0.667188 21.9106L0.667164 21.8913L0.667073 21.8155L0.666725 21.523L0.665485 20.4398C0.664459 19.5211 0.663091 18.2424 0.661723 16.8024C0.658986 13.9223 0.65625 10.397 0.65625 7.81565C0.65625 7.1969 1.35087 6.5 2.47973 6.5H3.35102L2.98585 7.04035L6.06577 9.36192ZM4.19998 6.60789C4.51856 6.70891 4.77604 6.8731 4.96111 7.06691L4.19998 6.60789Z" fill="#A7A4A4" stroke="#A7A4A4"/>
                                </svg>
                                </a>
                            @endif
                        </div>
                    </div>

                    <div class="col my-auto removeTextOnMobile">
                        <div>
                            <a href="{{route('hr_view')}}" class="{{ request()->is('hr_view')  ? 'activePageIndicator' : 'passivePageIndicator' }} text-decoration-none">HR</a>
                        </div>
                    </div>
                </div>
            </div>
            @endif
            @if(Auth::check() && !auth()->user()->hasRole('callagent') && !auth()->user()->hasRole('fs'))
                <div class="pt-3">
                    <div class="row g-0">
                        <div class="col-auto pe-0 pe-lg-3">
                            <span class="bluePageIndicator {{request()->is('finance') ? 'activePage' : 'passivePageIndicator' }}">
                                <svg style="min-width: 8px;" viewBox="0 0 10 49" fill="none"
                                             xmlns="http://www.w3.org/2000/svg">
                                            <path d="M0 0L10 24L0 49V0Z" fill="#2F60DC" />
                                        </svg>
                                </span>
                        </div>
                        <div class="col col-lg-2 me-0 me-lg-2 my-auto" style="margin-left: -8px;"> 
                            <div class="mx-auto text-center ">
                                @if(request()->is('finance'))
                                    <svg width="23" height="15" viewBox="0 0 23 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <rect x="1" y="4" width="18" height="9" fill="#2F60DC"/>
                                        <path d="M20.2927 0H5.14407C3.71769 0 2.55754 1.06117 2.55754 2.36567V2.57302C1.14468 2.58773 0 3.64193 0 4.93727V12.2971C0 13.6016 1.16038 14.6628 2.58654 14.6628H17.7352C19.1614 14.6628 20.3217 13.6016 20.3217 12.2971V12.0898C21.7343 12.0754 22.8793 11.0212 22.8793 9.72551V2.36578C22.8796 1.06128 21.7189 0 20.2927 0ZM18.6632 12.2971C18.6632 12.6803 18.2384 13.0038 17.7355 13.0038H2.58686C2.08397 13.0038 1.65924 12.6803 1.65924 12.2971V4.93738C1.65924 4.5544 2.08419 4.23073 2.58686 4.23073H17.7355C18.2384 4.23073 18.6632 4.55451 18.6632 4.93738V12.2971ZM20.3221 10.4299V4.93727C20.3221 3.63277 19.1617 2.5716 17.7355 2.5716H4.21645V2.36567C4.21645 1.98269 4.6414 1.65902 5.14407 1.65902H20.2927C20.7956 1.65902 21.2204 1.9828 21.2204 2.36567V9.72551H21.2207C21.2206 10.101 20.8118 10.4174 20.3221 10.4299Z" fill="#2F60DC"/>
                                        <path d="M10.1907 7.99572C9.49256 7.91254 9.13814 7.81301 9.13814 7.49883C9.13814 7.01217 9.84261 6.95963 10.1457 6.95963C10.5917 6.95963 11.0849 7.17526 11.2455 7.44039L11.3094 7.54625L12.3283 7.07486L12.2661 6.94796C11.9075 6.21559 11.2718 5.99439 10.781 5.90445V5.25635H9.58926V5.90107C8.53975 6.06449 7.91737 6.65558 7.91737 7.49861C7.91737 8.88574 9.21849 9.03117 10.0786 9.12765C10.8605 9.21998 11.2249 9.40771 11.2249 9.71819C11.2249 10.3188 10.3767 10.3654 10.1165 10.3654C9.53311 10.3654 8.97124 10.0765 8.80978 9.69301L8.75582 9.56557L7.65039 10.0339L7.7049 10.1613C8.01592 10.8896 8.68256 11.3489 9.58893 11.4633V12.162H10.7806V11.4284C11.6504 11.3212 12.4885 10.7649 12.4885 9.71786C12.4888 8.27917 11.1061 8.10877 10.1907 7.99572Z" fill="#F7F7F7"/>
                                    </svg>
                                @else
                                    <a href="{{route('finance')}}" class="{{ request()->is('finance')  ? 'activePageIndicator' : 'passivePageIndicator' }} text-decoration-none">

                                        <svg width="23" height="15" viewBox="0 0 23 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M20.2927 0H5.14407C3.71769 0 2.55754 1.06117 2.55754 2.36567V2.57302C1.14468 2.58773 0 3.64193 0 4.93727V12.2971C0 13.6016 1.16038 14.6628 2.58654 14.6628H17.7352C19.1614 14.6628 20.3217 13.6016 20.3217 12.2971V12.0898C21.7343 12.0754 22.8793 11.0212 22.8793 9.72551V2.36578C22.8796 1.06128 21.7189 0 20.2927 0ZM18.6632 12.2971C18.6632 12.6803 18.2384 13.0038 17.7355 13.0038H2.58686C2.08397 13.0038 1.65924 12.6803 1.65924 12.2971V4.93738C1.65924 4.5544 2.08419 4.23073 2.58686 4.23073H17.7355C18.2384 4.23073 18.6632 4.55451 18.6632 4.93738V12.2971ZM20.3221 10.4299V4.93727C20.3221 3.63277 19.1617 2.5716 17.7355 2.5716H4.21645V2.36567C4.21645 1.98269 4.6414 1.65902 5.14407 1.65902H20.2927C20.7956 1.65902 21.2204 1.9828 21.2204 2.36567V9.72551H21.2207C21.2206 10.101 20.8118 10.4174 20.3221 10.4299Z" fill="#A7A4A4"/>
                                            <path d="M10.1907 7.99572C9.49256 7.91254 9.13814 7.81301 9.13814 7.49883C9.13814 7.01217 9.84261 6.95963 10.1457 6.95963C10.5917 6.95963 11.0849 7.17526 11.2455 7.44039L11.3094 7.54625L12.3283 7.07486L12.2661 6.94796C11.9075 6.21559 11.2718 5.99439 10.781 5.90445V5.25635H9.58926V5.90107C8.53975 6.06449 7.91737 6.65558 7.91737 7.49861C7.91737 8.88574 9.21849 9.03117 10.0786 9.12765C10.8605 9.21998 11.2249 9.40771 11.2249 9.71819C11.2249 10.3188 10.3767 10.3654 10.1165 10.3654C9.53311 10.3654 8.97124 10.0765 8.80978 9.69301L8.75582 9.56557L7.65039 10.0339L7.7049 10.1613C8.01592 10.8896 8.68256 11.3489 9.58893 11.4633V12.162H10.7806V11.4284C11.6504 11.3212 12.4885 10.7649 12.4885 9.71786C12.4888 8.27917 11.1061 8.10877 10.1907 7.99572Z" fill="#A7A4A4"/>
                                        </svg>
                                    </a>
                                @endif
                            </div>
                        </div>

                        <div class="col my-auto removeTextOnMobile">
                            <div>
                                <a href="{{route('finance')}}" class="{{ request()->is('finance')  ? 'activePageIndicator' : 'passivePageIndicator' }} text-decoration-none">Finance</a>
                            </div>
                        </div>
                    </div>
                </div>
            @endif
            @if(Auth::check() && !auth()->user()->hasRole('callagent'))
                <div class="pt-3">
                    <div class="row g-0">
                        <div class="col-auto pe-0 pe-lg-3">
                            <span class="bluePageIndicator {{request()->is('statistics') ? 'activePage' : 'passivePageIndicator' }}">
                                <svg style="min-width: 8px;" viewBox="0 0 10 49" fill="none"
                                             xmlns="http://www.w3.org/2000/svg">
                                            <path d="M0 0L10 24L0 49V0Z" fill="#2F60DC" />
                                        </svg>
                                </span>
                        </div>
                        <div class="col col-lg-2 me-0 me-lg-2 my-auto" style="margin-left: -8px;">
                            <div class="mx-auto text-center ">
                                @if(request()->is('statistics'))
                                    <svg style="min-width: 8px; max-width: 20px;" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M19.3571 18.7143H15.8401V11.3353C15.8401 10.9802 15.5524 10.6924 15.1973 10.6924H13.007C12.6519 10.6924 12.3641 10.9802 12.3641 11.3353V18.7143H11.0855V8.23843C11.0855 7.88336 10.7977 7.59557 10.4426 7.59557H8.25236C7.89729 7.59557 7.6095 7.88336 7.6095 8.23843V18.7143H6.33093V5.11093C6.33093 4.75586 6.04314 4.46807 5.68807 4.46807H3.49779C3.14271 4.46807 2.85493 4.75586 2.85493 5.11093V18.7143H1.28571V0.642857C1.28571 0.287786 0.997929 0 0.642857 0C0.287786 0 0 0.287786 0 0.642857V19.3571C0 19.7122 0.287786 20 0.642857 20H19.3571C19.7122 20 20 19.7122 20 19.3571C20 19.0021 19.7122 18.7143 19.3571 18.7143ZM13.6499 11.9781H14.5544V18.7143H13.6499V11.9781ZM8.89529 8.88129H9.79986V18.7143H8.89529V8.88129ZM4.14064 5.75379H5.04521V18.7143H4.14064V5.75379Z" fill="#2F60DC"/>
                                        <rect x="3.63672" y="5.45453" width="1.81818" height="13.6364" fill="#2F60DC"/>
                                        <rect x="8.18359" y="8.18182" width="1.81818" height="10.9091" fill="#2F60DC"/>
                                        <rect x="13.6367" y="11.8182" width="1.81818" height="7.27273" fill="#2F60DC"/>
                                    </svg>
                                @else
                                    <a href="{{route('statistics')}}" class="{{ request()->is('statistics')  ? 'activePageIndicator' : 'passivePageIndicator' }} text-decoration-none">
                                        <svg style="min-width: 8px; max-width: 20px;" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M19.3571 18.7143H15.8401V11.3353C15.8401 10.9802 15.5524 10.6924 15.1973 10.6924H13.007C12.6519 10.6924 12.3641 10.9802 12.3641 11.3353V18.7143H11.0855V8.23843C11.0855 7.88336 10.7977 7.59557 10.4426 7.59557H8.25236C7.89729 7.59557 7.6095 7.88336 7.6095 8.23843V18.7143H6.33093V5.11093C6.33093 4.75586 6.04314 4.46807 5.68807 4.46807H3.49779C3.14271 4.46807 2.85493 4.75586 2.85493 5.11093V18.7143H1.28571V0.642857C1.28571 0.287786 0.997929 0 0.642857 0C0.287786 0 0 0.287786 0 0.642857V19.3571C0 19.7122 0.287786 20 0.642857 20H19.3571C19.7122 20 20 19.7122 20 19.3571C20 19.0021 19.7122 18.7143 19.3571 18.7143ZM13.6499 11.9781H14.5544V18.7143H13.6499V11.9781ZM8.89529 8.88129H9.79986V18.7143H8.89529V8.88129ZM4.14064 5.75379H5.04521V18.7143H4.14064V5.75379Z" fill="#A7A4A4"/>
                                        </svg>
                                    </a>
                                @endif
                            </div>
                        </div>
                        <div class="col my-auto removeTextOnMobile">
                            <div>
                                <a href="{{route('statistics')}}" class="{{ request()->is('statistics')  ? 'activePageIndicator' : 'passivePageIndicator' }} text-decoration-none">Statistics</a>
                            </div>
                        </div>
                    </div>
                </div>
            @endif
            <div>
                <hr class="navbarFirstHr my-3">
            </div>
            <div>
                @if(Auth::user()->hasRole('admin'))
                <div class="">
                    <div class="row g-0">
                        <div class="col-auto pe-0 pe-lg-3">
                            <span class="bluePageIndicator {{request()->is('addnewuser') ? 'activePage' : '' }}">
                                <svg style="min-width: 8px;" viewBox="0 0 10 49" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <path d="M0 0L10 24L0 49V0Z" fill="#2F60DC" />
                                </svg>
                            </span>
                        </div>
                        <div class="col col-lg-2 me-0 me-lg-2 my-auto" style="margin-left: -8px;">
                            <div class="mx-auto text-center">
                                @if(request()->is('addnewuser'))
                                    <svg style="min-width: 15px; max-width: 21px;" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <circle cx="10.5" cy="10.5" r="9.5" fill="#2F60DC" stroke="#2F60DC" stroke-width="2"/>
                                        <path d="M14.9987 9.49654H11.5009V6.00171C11.5009 5.44852 11.0546 5 10.5014 5C9.94821 5 9.50211 5.44852 9.50211 6.00195V9.49896H6.00268C5.44948 9.49896 4.99976 9.94748 5 10.5009C4.99976 10.7774 5.11146 11.0308 5.29247 11.2119C5.47372 11.3933 5.72378 11.508 6.00001 11.508H9.50211V15.0001C9.50211 15.2768 9.61188 15.5274 9.79313 15.7081C9.97438 15.8894 10.2237 16.0016 10.5004 16.0016C11.0534 16.0016 11.5009 15.5531 11.5009 15.0001V11.5077H14.9987C15.5519 11.5077 16.0004 11.0553 16.0001 10.5021C15.9999 9.94917 15.5514 9.49654 14.9987 9.49654Z" fill="#F7F7F7"/>
                                    </svg>
                                @else
                                    <a href="{{route('addnewuser')}}" class="{{request()->is('addnewuser') ? 'activePageIndicator' : 'passivePageIndicator' }} text-decoration-none">
                                        <svg style="max-width: 21px; min-width: 15px;" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <circle cx="10.5" cy="10.5" r="9.5" stroke="#A7A4A4" stroke-width="2"/>
                                            <path d="M14.9987 9.49654H11.5009V6.00171C11.5009 5.44852 11.0546 5 10.5014 5C9.94821 5 9.50211 5.44852 9.50211 6.00195V9.49896H6.00268C5.44948 9.49896 4.99976 9.94748 5 10.5009C4.99976 10.7774 5.11146 11.0308 5.29247 11.2119C5.47372 11.3933 5.72378 11.508 6.00001 11.508H9.50211V15.0001C9.50211 15.2768 9.61188 15.5274 9.79313 15.7081C9.97438 15.8894 10.2237 16.0016 10.5004 16.0016C11.0534 16.0016 11.5009 15.5531 11.5009 15.0001V11.5077H14.9987C15.5519 11.5077 16.0004 11.0553 16.0001 10.5021C15.9999 9.94917 15.5514 9.49654 14.9987 9.49654Z" fill="#A7A4A4"/>
                                        </svg>
                                    </a>
                                @endif
                            </div>
                        </div>
                        <div class="col my-auto removeTextOnMobile">
                            <div>
                                <a href="{{route('addnewuser')}}" class="{{request()->is('addnewuser') ? 'activePageIndicator' : 'passivePageIndicator' }} text-decoration-none">Registrieren</a>
                            </div>
                        </div>
                    </div>
                </div>
                @endif
                    @if(auth()->user()->admin_id != null)
                    <div class="pt-3">
                        <div class="row g-0">
                            <div class="col-auto pe-0 pe-lg-3">
                            <span class="bluePageIndicator">
                                <svg style="min-width: 8px;" viewBox="0 0 10 49" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <path d="M0 0L10 24L0 49V0Z" fill="#2F60DC" />
                                </svg>
                            </span>
                            </div>
                            <div class="col col-lg-2 me-0 me-lg-2 my-auto" style="margin-left: -8px;">
                                <div class="mx-auto text-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" fill="currentColor" class="bi bi-person-check" viewBox="0 0 16 16">
                                        <path d="M6 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H1s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C9.516 10.68 8.289 10 6 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z"/>
                                        <path fill-rule="evenodd" d="M15.854 5.146a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 0 1 .708-.708L12.5 7.793l2.646-2.647a.5.5 0 0 1 .708 0z"/>
                                    </svg>
                                </div>
                            </div>
                            <div class="col my-auto removeTextOnMobile">
                                <div>
                                    <a href="{{action('App\Http\Controllers\UserController@changerole')}}">Rolle wechseln</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endif
                <div class="pt-3">
                    <div class="row g-0">
                        <div class="col-auto pe-0 pe-lg-3">
                            <span class="bluePageIndicator">
                                <svg style="min-width: 8px;" viewBox="0 0 10 49" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <path d="M0 0L10 24L0 49V0Z" fill="#2F60DC" />
                                </svg>
                            </span>
                        </div>
                        <div class="col col-lg-2 me-0 me-lg-2 my-auto" style="margin-left: -8px;">
                            <div class="mx-auto text-center">

                                <svg style="min-width: 15px; max-width: 21px;" viewBox="0 0 18 16" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M5.80469 15.3333H2.13802C1.1255 15.3333 0.304688 14.5125 0.304688 13.5V2.49999C0.304688 1.48747 1.1255 0.666656 2.13802 0.666656H5.80469V2.49999H2.13802V13.5H5.80469V15.3333Z"
                                        fill="#A7A4A4" />
                                    <path
                                        d="M10.6877 12.9363L11.9896 11.6454L8.39698 8.02219H16.778C17.2842 8.02219 17.6946 7.6118 17.6946 7.10552C17.6946 6.59925 17.2842 6.18885 16.778 6.18885H8.37938L12.0281 2.57095L10.7372 1.2691L4.87891 7.07793L10.6877 12.9363Z"
                                        fill="#A7A4A4" />
                                </svg>

                            </div>
                        </div>
                        <div class="col my-auto removeTextOnMobile">
                            <div>
                                <a href="{{route('logout')}}" class=" passivePageIndicator text-decoration-none">Abmelden</a>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <div style="display: none" class="col" id="pdf">

    </div>
    <div class="col" id="old-content">
        @php
            $leadid = $lead->lead->id * 1244;
            $leadleadid = \Illuminate\Support\Facades\Crypt::encrypt($leadid);
            $person = $lead->id * 1244;
            $personId = \Illuminate\Support\Facades\Crypt::encrypt($person);
        @endphp
        <div class="pageBackgroundColor mt-0 mt-md-4 mx-0 mx-md-4">
            <div class="px-4 py-4">
                <div class="pb-5">
                    <div class="row g-0">
                        <div class="col-8 pb-4">
                            <span class="documentFormTitle">Personeninformationen</span>
                        </div>
                        <div class="modal fade" id="consultmodal1" tabindex="-1"
                             aria-labelledby="exampleModalLabel" style="top: 7% !important;"
                             aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content p-3"
                                     style="border-radius: 43px !important;">
                                    <div class="modal-header"
                                         style="border-bottom: 0 !important;">
                                        <h5 class="modal-title mx-2"
                                            style="font-family: 'Montserrat' !important;"
                                            id="exampleModalLabel"><b>Beratung Hinzufügen</b>
                                        </h5>
                                        <button type="button" style="opacity: 1 !important;"
                                                class="btn-close"
                                                data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                     
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal fade" id="consultmodal" tabindex="-1"
                             aria-labelledby="exampleModalLabel" style="top: 7% !important;"
                             aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content p-3"
                                     style="border-radius: 43px !important;">
                                    <div class="modal-header"
                                         style="border-bottom: 0 !important;">
                                        <h5 class="modal-title mx-2"
                                            style="font-family: 'Montserrat' !important;"
                                            id="exampleModalLabel"><b>Beratung Hinzufügen</b>
                                        </h5>
                                        <button type="button" style="opacity: 1 !important;"
                                                class="btn-close"
                                                data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form id="forma"
                                              action="{{route('updateperson',['id'=> $lead->id])}}"
                                              method="get">
                                            @csrf
                                            <div class="px-2">
                                                <div id="banka">
                                                    <label
                                                        style="font-family: 'Montserrat' !important;">Vorname</label>
                                                    <input type="text"
                                                           style="border-radius: 8px; background-color: #EFEFEF !important; border: 1px solid #EFEFEF !important;"
                                                           id="bank" value="{{$lead->first_name}}"
                                                           name="first_name" class="form-control mb-3"
                                                    >
                                                </div>
                                                <div id="ibani">
                                                    <label
                                                        style="font-family: 'Montserrat' !important;">Nachname</label>
                                                    <input type="text"
                                                           style="border-radius: 8px; background-color: #EFEFEF !important; border: 1px solid #EFEFEF !important; font-family: 'Montserrat';" value="{{$lead->last_name}}"
                                                           name="last_name" class="form-control mb-3"

                                                    >
                                                </div>
                                                <div id="cc">
                                                    <label
                                                        style="font-family: 'Montserrat' !important;">Geburstag</label>
                                                    <input type="date" value="{{$lead->birthdate}}"
                                                           style="border-radius: 8px; background-color: #EFEFEF !important; border: 1px solid #EFEFEF !important; font-family: 'Montserrat';"
                                                           name="birthdate" class="form-control mb-3"
                                                    >
                                                </div>
                                            </div>

                                            <div class="modal-footer text-center px-1"
                                                 style="border-top: 0 !important; justify-content: flex-start !important;">
                                                <div class="row" style="width: 100%;">
                                                    <div class="col-md-4 col-5 p-0">
                                                        <div style="padding: 2%;">
                                                            <button type="button"
                                                                    class="btn py-2"
                                                                    style="font-family: 'Montserrat' !important; width: 100%; font-weight: 600 !important; border: 1px solid #6C757D; font-size: 18px !important; background-color: #6C757D; color: #fff; border-radius: 8px;"
                                                                    data-bs-dismiss="modal">
                                                                Schliessen
                                                            </button>

                                                        </div>
                                                    </div>
                                                    <div class="col-md-4 col-5 p-0">
                                                        <div style="padding: 2%;">
                                                            <input type="submit"
                                                                   style="font-family: 'Montserrat' !important; width: 100%; border: 1px solid #4EC590; font-weight: 600 !important; font-size: 18px !important; background-color: #4EC590; color: #fff; border-radius: 8px;"
                                                                   class="btn py-2"
                                                                   value="Sparen">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="documentFormGreyBGDiv col-4 pe">
                            <div class="p-4">
                                <div class="pb-4">
                                    <svg viewBox="0 0 29 29" fill="none" xmlns="http://www.w3.org/2000/svg" style="min-width: 20px; width: 25px;"><path fill-rule="evenodd" clip-rule="evenodd" d="M0.625 22.9176V27.6043C0.625 28.036 0.964167 28.3751 1.39583 28.3751H6.0825C6.28292 28.3751 6.48333 28.2981 6.62208 28.1439L23.4571 11.3243L17.6758 5.54306L0.85625 22.3626C0.702083 22.5168 0.625 22.7018 0.625 22.9176ZM27.9279 6.85347C28.5292 6.25222 28.5292 5.28097 27.9279 4.67972L24.3204 1.07222C23.7192 0.470972 22.7479 0.470972 22.1467 1.07222L19.3254 3.89347L25.1067 9.67472L27.9279 6.85347Z" fill="#202020"></path></svg>
                                    <div class="row g-0">
                                        <div class="col-7">
                                            <span class="documentFormLeftSpan">Quelle</span>
                                        </div>
                                        <div class="col">
                                            <span class="documentFormRightSpan">Lead</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="pb-2">
                                    <div class="row g-0">
                                        <div class="col-7">
                                            <span class="documentFormLeftSpan">Kampagne</span>
                                        </div>
                                        <div class="col">
                                            @if($lead->lead->campaign_id == 1)
                                                <span class="documentFormRightSpan">Instagram</span>
                                            @elseif($lead->lead->campaign_id == 2)
                                                <span class="documentFormRightSpan">Facebook</span>
                                            @elseif($lead->lead->campaign_id == 3)
                                                <span class="documentFormRightSpan">Sanascout</span>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row g-0 mt-3">
                        <div class="col-12 col-md-6 col-xl-4 mb-4 pe-0 pe-md-0 pe-xl-5 ">
                            <div class="documentFormGreyBGDiv">
                                <div class="p-4">
                                    <div class="pb-3">
                                        <span class="documentFormGreyBGTitle">Persönliche Informationen</span>
                                    </div>
                                    <div class="pb-4">
                                        <div class="row g-0">
                                            <div class="col-7">
                                                <span class="documentFormLeftSpan">VORNAME</span>
                                            </div>
                                            <div class="col">
                                                <span class="documentFormRightSpan">{{$lead->first_name}}</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="pb-4">
                                        <div class="row g-0 justify-content-between">
                                            <div class="col-7">
                                                <span class="documentFormLeftSpan">NACHNAME</span>
                                            </div>
                                            <div class="col">
                                                <span class="documentFormRightSpan">{{$lead->last_name}}</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="">
                                        <div class="row g-0">
                                            <div class="col-7">
                                                <span class="documentFormLeftSpan">GEBURSTAG</span>
                                            </div>
                                            <div class="col">
                                                <span class="documentFormRightSpan">{{$lead->birthdate}}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-6 col-xl-4 mb-4 pe-0 pe-md-0 pe-xl-5 ps-0 ps-md-4 ps-xl-0">
                            <div class="documentFormGreyBGDiv h-100">
                                <div class="p-4">
                                    <div class="pb-3">
                                        <span class="documentFormGreyBGTitle">Wohnort</span>
                                    </div>
                                    <div class="pb-4">
                                        <div class="row g-0">
                                            <div class="col-7">
                                                <span class="documentFormLeftSpan">ADDRESE</span>
                                            </div>
                                            <div class="col">
                                                <span class="documentFormRightSpan">{{$lead->lead->address}} {{$lead->lead->nr}}</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="pb-4">
                                        <div class="row g-0">
                                            <div class="col-7">
                                                <span class="documentFormLeftSpan">POSTLEITZAHL, ORT</span>
                                            </div>
                                            <div class="col">
                                                <span class="documentFormRightSpan">{{$lead->lead->postal_code}} {{$lead->lead->city}}</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="">
                                        <div class="row g-0">
                                            <div class="col-7">
                                                <span class="documentFormLeftSpan">KANTON</span>
                                            </div>
                                            <div class="col">
                                                <span class="documentFormRightSpan">Kanton</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-6 col-xl-4 pe-0 mb-0 mb-lg-4">
                            <div class="documentFormGreyBGDiv h-100">
                                <div class="p-4">
                                    <div class="text-end">
                                        <svg data-bs-toggle="modal" data-bs-target="#consultmodal" viewBox="0 0 29 29" fill="none" xmlns="http://www.w3.org/2000/svg" style="min-width: 20px; width: 25px;"><path fill-rule="evenodd" clip-rule="evenodd" d="M0.625 22.9176V27.6043C0.625 28.036 0.964167 28.3751 1.39583 28.3751H6.0825C6.28292 28.3751 6.48333 28.2981 6.62208 28.1439L23.4571 11.3243L17.6758 5.54306L0.85625 22.3626C0.702083 22.5168 0.625 22.7018 0.625 22.9176ZM27.9279 6.85347C28.5292 6.25222 28.5292 5.28097 27.9279 4.67972L24.3204 1.07222C23.7192 0.470972 22.7479 0.470972 22.1467 1.07222L19.3254 3.89347L25.1067 9.67472L27.9279 6.85347Z" fill="#202020"></path></svg>
                                    </div>
                                    <div class="pb-3">
                                        <span class="documentFormGreyBGTitle">Zugehörige Personen</span>
                                    </div>
                                    <div class="pb-4">
                                        <div class="row g-0">
                                            <div class="col-7">
                                                <span class="documentFormLeftSpan">Mitglieder</span>
                                            </div>
                                            <div class="col">
                                                @foreach($lead->lead->family as $kid)
                                                    <div class="pb-4">
                                                        <span class="documentFormRightSpan">{{$kid->first_name}} {{$kid->last_name}}</span>
                                                    </div>
                                                @endforeach
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <form id="formaa" action="{{route('createLeadDataKK',['leadIdd'=> $leadleadid ,'personIdd' => $personId])}}" method="post" enctype="multipart/form-data" class="my-0">
                    @csrf
                    <input type="hidden" name="newgcount" id="newgcount" value="0">
                    <input type="hidden" name="newncount" id="newncount" value="0">
                    <div>
                        <div class="row g-0 justify-content-center">
                            <div class="col-12 col-md-6 col-lg-6 col-xl-5">
                                <div class="mb-5">
                                    <div class="row g-0 justify-content-center">
                                        <div class="col-6 my-auto">
                                            <div class="text-center">
                                                <span class="kundingurungDurch">Kündigung durch?</span>
                                            </div>
                                        </div>
                                        <div class="col-6 my-auto">
                                            <div class="row g-0">
                                                <div class="col text-end">
                                                    <button type="button" id="yesBtnKundingurung" onclick="yesBtnKundingurungClicked()" class="documentFormBtn px-0">DLF</button>
                                                </div>
                                                <div class="col text-center">
                                                    <button type="button" id="noBtnKundingurung" onclick="noBtnKundingurungClicked()" class="documentFormBtn px-0">Kunde</button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="text-center" style="display: none;" id="yesBtnKundingurungForm">
                                            <label for="kundingurungDurchFile" class="text-center w-100">
                                                <div class="inputFileBG mt-5 mx-auto" id="inputFileBG1">
                                                    <div class="p-5">
                                                        <div id="beforeUploadTextK">
                                                            <div class="mb-2">
                                                                <svg class="uploadSvgStyle" viewBox="0 0 23 23" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M21 14.6667V18.8889C21 19.4488 20.7776 19.9858 20.3817 20.3817C19.9858 20.7776 19.4488 21 18.8889 21H4.11111C3.55121 21 3.01424 20.7776 2.61833 20.3817C2.22242 19.9858 2 19.4488 2 18.8889V14.6667" stroke="#658BEB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                                                    <path d="M16.7777 7.27778L11.4999 2L6.22217 7.27778" stroke="#658BEB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                                                    <path d="M11.5 2V14.6667" stroke="#658BEB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                                                </svg>
                                                            </div>
                                                            <div>
                                                                <span class="fileInputSecondTitle">Durchsuche</span>
                                                            </div>
                                                            <div>
                                                                <span class="fileInputFirstTitle">Laden Sie hier Ihre Dateien hoch</span>
                                                            </div>
                                                        </div>
                                                        <div class="aferUploadText" id="aferUploadTextK">
                                                            <svg class="afterUploadSvg" viewBox="0 0 90 90" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <path d="M90 45C90 69.8226 69.8226 90 45 90C20.1774 90 0 69.8226 0 45C0 20.1774 20.1774 0 45 0C69.8226 0 90 20.1774 90 45Z" fill="#2F60DC" fill-opacity="0.81" />
                                                                <path d="M45 0C69.8226 0 90 20.1774 90 45C90 69.8226 69.8226 90 45 90" fill="#002A96" fill-opacity="0.58" />
                                                                <path d="M13 13.2156C30.6208 -4.4052 59.1636 -4.4052 76.7844 13.2156C94.4052 30.8364 94.4052 59.3792 76.7844 77" fill="#2F60DC" />
                                                                <path d="M44.1241 61C43.5507 61 43.1206 60.8509 42.6906 60.4036L29.6451 46.8355C28.785 45.9409 28.785 44.599 29.6451 43.7044C30.5052 42.8098 31.7955 42.8098 32.6556 43.7044L44.2675 55.7815L66.3444 32.671C67.2045 31.7763 68.4948 31.7763 69.3549 32.671C70.215 33.5656 70.215 34.9075 69.3549 35.8021L45.5577 60.4036C45.1276 60.8509 44.5542 61 44.1241 61Z" fill="#EEFFFF" />
                                                            </svg>
                                                        </div>
                                                        <input type="file" id="kundingurungDurchFile"
                                                               name="kundingurung_durch_file_dlf" hidden
                                                               class="svg-div w-100 border-0  g-0"
                                                               onchange="upload(this);">
                                                        <input type="text"
                                                               class="form-control text-center"
                                                               id="kundingurungDurchFilec" disabled
                                                               style="background:transparent; border:none;">
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                        <div class="text-center" style="display: none;" id="yesBtnKundingurungForm1">
                                            <label for="kundingurungDurchFile1" class="text-center w-100">
                                                <div class="inputFileBG mt-5 mx-auto" id="inputFileBG1">
                                                    <div class="p-5">
                                                        <div id="beforeUploadTextK">
                                                            <div class="mb-2">
                                                                <svg class="uploadSvgStyle" viewBox="0 0 23 23" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M21 14.6667V18.8889C21 19.4488 20.7776 19.9858 20.3817 20.3817C19.9858 20.7776 19.4488 21 18.8889 21H4.11111C3.55121 21 3.01424 20.7776 2.61833 20.3817C2.22242 19.9858 2 19.4488 2 18.8889V14.6667" stroke="#658BEB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                                                    <path d="M16.7777 7.27778L11.4999 2L6.22217 7.27778" stroke="#658BEB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                                                    <path d="M11.5 2V14.6667" stroke="#658BEB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                                                </svg>
                                                            </div>
                                                            <div>
                                                                <span class="fileInputSecondTitle">Durchsuche</span>
                                                            </div>
                                                            <div>
                                                                <span class="fileInputFirstTitle">Laden Sie hier Ihre Dateien hoch</span>
                                                            </div>
                                                        </div>
                                                        <div class="aferUploadText" id="aferUploadTextK1">
                                                            <svg class="afterUploadSvg" viewBox="0 0 90 90" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <path d="M90 45C90 69.8226 69.8226 90 45 90C20.1774 90 0 69.8226 0 45C0 20.1774 20.1774 0 45 0C69.8226 0 90 20.1774 90 45Z" fill="#2F60DC" fill-opacity="0.81" />
                                                                <path d="M45 0C69.8226 0 90 20.1774 90 45C90 69.8226 69.8226 90 45 90" fill="#002A96" fill-opacity="0.58" />
                                                                <path d="M13 13.2156C30.6208 -4.4052 59.1636 -4.4052 76.7844 13.2156C94.4052 30.8364 94.4052 59.3792 76.7844 77" fill="#2F60DC" />
                                                                <path d="M44.1241 61C43.5507 61 43.1206 60.8509 42.6906 60.4036L29.6451 46.8355C28.785 45.9409 28.785 44.599 29.6451 43.7044C30.5052 42.8098 31.7955 42.8098 32.6556 43.7044L44.2675 55.7815L66.3444 32.671C67.2045 31.7763 68.4948 31.7763 69.3549 32.671C70.215 33.5656 70.215 34.9075 69.3549 35.8021L45.5577 60.4036C45.1276 60.8509 44.5542 61 44.1241 61Z" fill="#EEFFFF" />
                                                            </svg>
                                                        </div>
                                                        <input type="file" id="kundingurungDurchFile1"
                                                               name="kundingurung_durch_file_kunde" hidden
                                                               class="svg-div w-100 border-0  g-0"
                                                               onchange="upload(this);">
                                                        <input type="text"
                                                               class="form-control text-center"
                                                               id="kundingurungDurchFile1c" disabled
                                                               style="background:transparent; border:none;">
                                                    </div>
                                                </div>
                                            </label>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-md-6 col-lg-6 col-xl-5">
                                <div class="mb-5">
                                    <div class="row g-0">
                                        <div class="col-6 my-auto">
                                            <div class="text-center">
                                                <span class="kundingurungDurch">Mandatiert?</span>
                                            </div>
                                        </div>
                                        <div class="col-6 my-auto">
                                            <div class="row g-0">
                                                <div class="col text-end">
                                                    <button type="button" onclick="yesBtnMandatiertClicked()" id="yesBtnMandatiert" class="documentFormBtn px-0">Yes</button>
                                                </div>
                                                <div class="col text-center">
                                                    <button type="button" onclick="noBtnMandatiertClicked()" id="noBtnMandatiert" class="documentFormBtn px-0">No</button>
                                                </div>
                                            </div>

                                        </div>
                                        <div style="display: none;" class="text-end mx-auto" id="yesBtnMandatiertForm">
                                            <label for="mandatiertFile" class="text-center mx-auto w-100">
                                                <div class="inputFileBG mt-5 ms-auto me-auto me-md-0 " id="inputFileBG2">
                                                    <div class="p-5">
                                                        <div id="beforeUploadTextM">
                                                            <div class="mb-2">
                                                                <svg class="uploadSvgStyle" viewBox="0 0 23 23" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M21 14.6667V18.8889C21 19.4488 20.7776 19.9858 20.3817 20.3817C19.9858 20.7776 19.4488 21 18.8889 21H4.11111C3.55121 21 3.01424 20.7776 2.61833 20.3817C2.22242 19.9858 2 19.4488 2 18.8889V14.6667" stroke="#658BEB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                                                    <path d="M16.7777 7.27778L11.4999 2L6.22217 7.27778" stroke="#658BEB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                                                    <path d="M11.5 2V14.6667" stroke="#658BEB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                                                </svg>
                                                            </div>
                                                            <div>
                                                                <span class="fileInputSecondTitle">Durchsuche</span>
                                                            </div>
                                                            <div>
                                                                <span class="fileInputFirstTitle">Laden Sie hier Ihre Dateien hoch</span>
                                                            </div>
                                                        </div>
                                                        <div class="aferUploadText" id="aferUploadTextM">
                                                            <svg class="afterUploadSvg" viewBox="0 0 90 90" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <path d="M90 45C90 69.8226 69.8226 90 45 90C20.1774 90 0 69.8226 0 45C0 20.1774 20.1774 0 45 0C69.8226 0 90 20.1774 90 45Z" fill="#2F60DC" fill-opacity="0.81" />
                                                                <path d="M45 0C69.8226 0 90 20.1774 90 45C90 69.8226 69.8226 90 45 90" fill="#002A96" fill-opacity="0.58" />
                                                                <path d="M13 13.2156C30.6208 -4.4052 59.1636 -4.4052 76.7844 13.2156C94.4052 30.8364 94.4052 59.3792 76.7844 77" fill="#2F60DC" />
                                                                <path d="M44.1241 61C43.5507 61 43.1206 60.8509 42.6906 60.4036L29.6451 46.8355C28.785 45.9409 28.785 44.599 29.6451 43.7044C30.5052 42.8098 31.7955 42.8098 32.6556 43.7044L44.2675 55.7815L66.3444 32.671C67.2045 31.7763 68.4948 31.7763 69.3549 32.671C70.215 33.5656 70.215 34.9075 69.3549 35.8021L45.5577 60.4036C45.1276 60.8509 44.5542 61 44.1241 61Z" fill="#EEFFFF" />
                                                            </svg>
                                                        </div>
                                                        <input type="file" id="mandatiertFile"
                                                               name="mandatiert_file" hidden
                                                               class="svg-div w-100 border-0  g-0"
                                                               onchange="upload(this);">
                                                        <input type="text"
                                                               class="form-control text-center"
                                                               id="mandatiertFilec" disabled
                                                               style="background:transparent; border:none;">
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div id="krankenkasseModal" class="documentsFormModals px-4">
                            <div class="" style="position: relative;">
                                <div class="cornerSvgDiv">
                                    <svg class="cornerSvg" viewBox="0 0 242 215" fill="none"
                                         xmlns="http://www.w3.org/2000/svg">
                                        <g filter="url(#filter0_d_94_997)">
                                            <path
                                                d="M37 56C37 43.2975 47.2975 33 60 33H169.039C179.447 33 189.295 37.7152 195.821 45.8235V45.8235C199.859 50.8402 202.407 56.89 203.174 63.284L203.951 69.7564C204.646 75.5512 204.449 81.4184 203.367 87.1537L202.697 90.7036C200.914 100.158 197.45 109.217 192.472 117.45L191.552 118.972C188.524 123.979 185.018 128.68 181.083 133.009L177 137.5L169.892 142.647C164.982 146.203 159.661 149.153 154.045 151.435L151.315 152.544C148.114 153.844 144.783 154.796 141.378 155.383V155.383C135.186 156.451 129.263 158.721 123.943 162.064L114.5 168L109.001 171.093C107.347 172.024 105.54 172.652 103.666 172.948L103.115 173.034C99.2059 173.652 95.2134 172.66 92.0473 170.286V170.286C90.049 168.787 88.4674 166.802 87.4529 164.519L85 159L82.9184 153.647C81.9802 151.235 80.6235 149.007 78.9108 147.066L77.8112 145.819C75.3125 142.988 72.1269 140.847 68.561 139.603L56.7818 135.494C53.9415 134.503 51.255 133.116 48.8018 131.375L40.37 125.392C38.256 123.891 37 121.46 37 118.868V56Z"
                                                fill="#EDF0F8" />
                                            <path
                                                d="M136.201 118H94.7991C92.9907 117.992 91.2593 117.268 89.9847 115.985C88.71 114.702 87.9963 112.966 88 111.158V75.5639C87.9963 73.7556 88.71 72.0196 89.9847 70.7368C91.2593 69.4541 92.9907 68.7293 94.7991 68.7216H98.173V72.9098H94.7991C94.0976 72.9128 93.4259 73.1939 92.9314 73.6914C92.4369 74.189 92.16 74.8624 92.1614 75.5639V111.158C92.16 111.859 92.437 112.533 92.9315 113.03C93.4259 113.528 94.0976 113.809 94.7991 113.812H136.201C136.903 113.809 137.574 113.528 138.069 113.03C138.563 112.533 138.84 111.859 138.839 111.158V75.5639C138.84 74.8625 138.563 74.1891 138.069 73.6915C137.574 73.194 136.903 72.9129 136.201 72.9098H132.331V68.7223H136.201C138.009 68.7301 139.741 69.4548 141.015 70.7374C142.29 72.02 143.004 73.7557 143 75.5639V111.158C143.004 112.966 142.29 114.702 141.015 115.985C139.741 117.267 138.01 117.992 136.201 118ZM122.07 77.5897H108.541C106.615 77.5768 104.772 76.8026 103.414 75.4359C102.057 74.0693 101.295 72.2212 101.295 70.2949C101.295 68.3686 102.057 66.5205 103.414 65.1538C104.772 63.7872 106.615 63.0129 108.541 63H122.07C123.996 63.0129 125.839 63.7872 127.197 65.1538C128.554 66.5205 129.316 68.3686 129.316 70.2949C129.316 72.2212 128.554 74.0693 127.197 75.4359C125.839 76.8026 123.996 77.5768 122.07 77.5897V77.5897ZM108.541 67.1875C107.723 67.1959 106.94 67.527 106.365 68.1088C105.789 68.6907 105.466 69.4762 105.466 70.2949C105.466 71.1135 105.789 71.8991 106.365 72.4809C106.94 73.0627 107.723 73.3938 108.541 73.4022H122.07C122.889 73.3938 123.671 73.0627 124.247 72.4809C124.823 71.8991 125.146 71.1135 125.146 70.2949C125.146 69.4762 124.823 68.6907 124.247 68.1088C123.671 67.527 122.889 67.1959 122.07 67.1875H108.541Z"
                                                fill="#5288F5" />
                                            <path
                                                d="M125.714 93.9346H117.634V86.5715H113.367V93.9346H105.286V98.0653H113.367V105.429H117.634V98.0663H125.714V93.9356V93.9346Z"
                                                fill="#F79C42" />
                                        </g>
                                        <defs>
                                            <filter id="filter0_d_94_997" x="0" y="0" width="241.358" height="214.214"
                                                    filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                                                <feFlood flood-opacity="0" result="BackgroundImageFix" />
                                                <feColorMatrix in="SourceAlpha" type="matrix"
                                                               values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                                                <feOffset dy="4" />
                                                <feGaussianBlur stdDeviation="18.5" />
                                                <feComposite in2="hardAlpha" operator="out" />
                                                <feColorMatrix type="matrix"
                                                               values="0 0 0 0 0.87451 0 0 0 0 0.87451 0 0 0 0 0.87451 0 0 0 0.24 0" />
                                                <feBlend mode="normal" in2="BackgroundImageFix"
                                                         result="effect1_dropShadow_94_997" />
                                                <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_94_997"
                                                         result="shape" />
                                            </filter>
                                        </defs>
                                    </svg>
                                </div>
                                <div class="row g-0 justify-content-center pt-4">
                                    <div class="col-4 col-md-2">
                                        <div>
                                            <div class="text-center">
                                                <span id="step1Krankenkasse" class="activeStepTitle">Step 1</span>
                                            </div>
                                            <div class="mx-auto">
                                                <div id="step1LineKranken" class="blueLine mx-auto"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-4 col-4 col-md-2">
                                        <div>
                                            <div class="text-center">
                                                <span id="step2Krankenkasse" class="passiveStepTitle">Step 2</span>
                                            </div>
                                            <div>
                                                <div id="step2LineKranken" class="greyLine mx-auto"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="step1Kranken" class="pt-4">
                                <div class="row g-0 justify-content-center pt-0 pt-md-0">
                                    <div class="col-12 col-md-5 col-lg-5 ">
                                        <div class="pt-3 px-2">
                                            <div class="pb-2">
                                                <span class="modalTitle">Datei</span>
                                            </div>
                                            <div class="pb-2">
                                                <label id="IDCheckBoxLabel" class="container2 uncheckedCheckbox">ID
                                                    <input class="isChecked" type="checkbox" id="IDCheckBox" value="Ja" name="id_notwending_select">
                                                    <span class="checkmark2"></span>
                                                </label>
                                            </div>
                                            <div class="pb-2">
                                                <label id="KundingungCheckBoxLabel" class="container2 uncheckedCheckbox">Kundingung
                                                    durch
                                                    <input type="checkbox" id="KundingungCheckBox" value="Ja" name="kundigung_step_two">
                                                    <span class="checkmark2"></span>
                                                </label>
                                            </div>
                                            <div class="pb-2">
                                                <label id="VorversichererCheckBoxLabel" class="container2 uncheckedCheckbox">Vorversicherer
                                                    <input type="checkbox" id="VorversichererCheckBox" value="Ja" name="vorversicherer_select">
                                                    <span class="checkmark2"></span>
                                                </label>
                                            </div>
                                            <div>
                                                <label id="vollmachtCheckBoxLabel" for="vollmachtCheckBox" class="container2 uncheckedCheckbox">Vollmacht
                                                    <input type="checkbox" id="vollmachtCheckBox" value="Ja" name="vollmacht_select">
                                                    <span class="checkmark2"></span>
                                                </label>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-12 col-md-5 col-lg-4 my-auto">
                                        <div class="pt-4 pt-md-0">
                                            <div class="text-center" id="krankenkasseUploadFile">
                                                <label for="krankenkasseUpload" class="text-center w-100 px-2 px-md-0">
                                                    <div class="inputFileBG w-100" id="inputFileBG3">
                                                        <div class="px-5 py-3">
                                                            <div id="beforeUploadTextKranken">
                                                                <div class="mb-2">
                                                                    <svg class="uploadSvgStyle" viewBox="0 0 23 23" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path d="M21 14.6667V18.8889C21 19.4488 20.7776 19.9858 20.3817 20.3817C19.9858 20.7776 19.4488 21 18.8889 21H4.11111C3.55121 21 3.01424 20.7776 2.61833 20.3817C2.22242 19.9858 2 19.4488 2 18.8889V14.6667" stroke="#658BEB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                                                        <path d="M16.7777 7.27778L11.4999 2L6.22217 7.27778" stroke="#658BEB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                                                        <path d="M11.5 2V14.6667" stroke="#658BEB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                                                    </svg>
                                                                </div>
                                                                <div>
                                                                    <span class="fileInputSecondTitle">Durchsuche</span>
                                                                </div>
                                                                <div>
                                                                    <span class="fileInputFirstTitle">Laden Sie hier Ihre Dateien hoch</span>
                                                                </div>
                                                            </div>
                                                            <div class="aferUploadText" id="aferUploadTextKranken">
                                                                <svg class="afterUploadSvg" viewBox="0 0 90 90" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M90 45C90 69.8226 69.8226 90 45 90C20.1774 90 0 69.8226 0 45C0 20.1774 20.1774 0 45 0C69.8226 0 90 20.1774 90 45Z" fill="#2F60DC" fill-opacity="0.81" />
                                                                    <path d="M45 0C69.8226 0 90 20.1774 90 45C90 69.8226 69.8226 90 45 90" fill="#002A96" fill-opacity="0.58" />
                                                                    <path d="M13 13.2156C30.6208 -4.4052 59.1636 -4.4052 76.7844 13.2156C94.4052 30.8364 94.4052 59.3792 76.7844 77" fill="#2F60DC" />
                                                                    <path d="M44.1241 61C43.5507 61 43.1206 60.8509 42.6906 60.4036L29.6451 46.8355C28.785 45.9409 28.785 44.599 29.6451 43.7044C30.5052 42.8098 31.7955 42.8098 32.6556 43.7044L44.2675 55.7815L66.3444 32.671C67.2045 31.7763 68.4948 31.7763 69.3549 32.671C70.215 33.5656 70.215 34.9075 69.3549 35.8021L45.5577 60.4036C45.1276 60.8509 44.5542 61 44.1241 61Z" fill="#EEFFFF" />
                                                                </svg>
                                                            </div>
                                                            <input type="file" id="krankenkasseUpload"
                                                                   name="kranken_file" hidden
                                                                   class="svg-div w-100 border-0  g-0"
                                                                   onchange="upload(this);">
                                                            <input type="text"
                                                                   class="form-control text-center"
                                                                   id="krankenkasseUploadc" disabled
                                                                   style="background:transparent; border:none;">
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="pt-4">
                                    <div class="row g-0 justify-content-center">
                                        <div class="col-12 col-md-8 col-lg-7">
                                            <krank fam_id="{{$lead->id}}" url="{{config('app.url')}}" lead_id="{{$lead->lead->id}}"></krank>
                                        </div>
                                    </div>
                                </div>
                                <div class="py-4 py-md-4">

                                    <div class="pt-4 pt-md-0">
                                        <div class="row g-0 changeBtnAlign">
                                            <div class="col-4 col-md-3 col-lg-2 me-2">
                                                <button type="button" onclick="cancelBtnClickKranken()" class="cancelBtnKranken py-0 py-md-1 w-100">Abbrechen</button>
                                            </div>
                                            <div class="col-4 col-md-3 col-lg-2">
                                                <button type="button" onclick="continueToStep2()" class="continueBtn py-0 py-md-1 w-100">Weiter</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="step2Kranken" class="" style="display: none;">
                                <div class="">
                                    <div class="row g-0 justify-content-center">
                                        <div class="col-12 col-md-6 col-lg-5 col-xl-4  pe-0 pe-md-2">
                                            <div class="list-choice-title list-choice-title-step2 p-2 mt-4" onclick="openKrankenDropdownStep2()">
                                                <div class="row g-0">
                                                    <div class="col my-auto">
                                                        <span>Grundversicherung</span>
                                                    </div>
                                                    <div class="col-auto">
                                                        <svg width="31" height="31" viewBox="0 0 31 31" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <circle cx="15.2314" cy="15.1093" r="15" fill="#2F60DC" />
                                                            <path d="M8.90704 13.1784C8.90681 13.0023 8.96701 12.8254 9.09028 12.6813C9.3644 12.3601 9.84662 12.322 10.1674 12.5968L15.0229 16.746L19.8676 12.5818C20.1876 12.306 20.67 12.3425 20.9449 12.6629C21.2187 12.9825 21.1832 13.4652 20.8635 13.7395L15.5222 18.3312C15.2364 18.5771 14.8142 18.5777 14.5278 18.3327L9.17449 13.7576C8.99823 13.6072 8.90732 13.3932 8.90704 13.1784Z" fill="white" />
                                                        </svg>
                                                    </div>
                                                </div>
                                            </div>
                                            <div id="Grundversicherung" class="Grundversicherung mt-4">
                                                <div class="p-4">
                                                    <div class="pb-2">
                                                        <div>
                                                            <span class="GrundversicherungSpans">Abschlussdatum</span>
                                                        </div>
                                                        <div>
                                                            <input class="GrundversicherungInput form-control" type="date" name="graduation_date_PG1">
                                                        </div>
                                                    </div>
                                                    <div class="pb-2">
                                                        <div>
                                                            <span class="GrundversicherungSpans">Gesellschaft</span>
                                                        </div>
                                                        <div>
                                                            <select class="GrundversicherungInput form-control" name="society_PG1">
                                                                <option value=""></option>
                                                                <option value="Sympany">Sympany</option>
                                                                <option value="Helsana">Helsana</option>
                                                                <option value="Swica">Swica</option>
                                                                <option value="GM">GM</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="pb-2">
                                                        <div>
                                                            <span class="GrundversicherungSpans">Produkt</span>
                                                        </div>
                                                        <div>
                                                            <input class="GrundversicherungInput form-control" type="text" name="product_PG1">
                                                        </div>
                                                    </div>
                                                    <div class="pb-2">
                                                        <div>
                                                            <span class="GrundversicherungSpans">Status</span>
                                                        </div>
                                                        <div>
                                                            <select class="GrundversicherungInput form-control" name="status_PG1">
                                                                <option selected value="Nicht Ausgewählt">
                                                                    Nicht Ausgewählt
                                                                </option>
                                                                <option value="Aufgenomen">
                                                                    Aufgenomen
                                                                </option>
                                                                <option value="Offen">Offen</option>
                                                                <option value="Abgelehnt">
                                                                    Abgelehnt
                                                                </option>
                                                                <option value="Zuruckgezogen">
                                                                    Zuruckgezogen
                                                                </option>
                                                                <option value="Provisionert">
                                                                    Provisionert
                                                                </option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="pb-2">
                                                        <div>
                                                            <span class="GrundversicherungSpans">Letze Anpassung</span>
                                                        </div>
                                                        <div>
                                                            <input class="GrundversicherungInput form-control" type="date"
{{--                                                                   name="last_adjustment_PG1"--}}
                                                                   min="1900-01-01" max="9999-12-31" readonly>
                                                        </div>
                                                    </div>
                                                    <div class="pb-2">
                                                        <div>
                                                            <span class="GrundversicherungSpans">Gesamtprovision</span>
                                                        </div>
                                                        <div>
                                                            <input class="GrundversicherungInput form-control" type="number" name="total_commisions_PG1">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="col-12 col-md-6 col-lg-5 col-xl-4 ps-0 ps-md-2">
                                            <div class="list-choice-title list-choice-title-step2 p-2 mt-4" onclick="openKrankenDropdownStep22()">
                                                <div class="row g-0">
                                                    <div class="col my-auto">
                                                        <span>Zusatzversicherung</span>
                                                    </div>
                                                    <div class="col-auto">
                                                        <svg width="31" height="31" viewBox="0 0 31 31" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <circle cx="15.2314" cy="15.1093" r="15" fill="#2F60DC" />
                                                            <path d="M8.90704 13.1784C8.90681 13.0023 8.96701 12.8254 9.09028 12.6813C9.3644 12.3601 9.84662 12.322 10.1674 12.5968L15.0229 16.746L19.8676 12.5818C20.1876 12.306 20.67 12.3425 20.9449 12.6629C21.2187 12.9825 21.1832 13.4652 20.8635 13.7395L15.5222 18.3312C15.2364 18.5771 14.8142 18.5777 14.5278 18.3327L9.17449 13.7576C8.99823 13.6072 8.90732 13.3932 8.90704 13.1784Z" fill="white" />
                                                        </svg>
                                                    </div>
                                                </div>

                                            </div>
                                            <div class="Zusatzversicherung mt-4" id="Zusatzversicherung">
                                                <div class="p-4">
                                                    <div class="pb-2">
                                                        <div>
                                                            <span class="GrundversicherungSpans">Abschlussdatum</span>
                                                        </div>
                                                        <div>
                                                            <input class="GrundversicherungInput form-control" type="date" name="graduation_date_PZ1" min="1900-01-01" max="9999-12-31">
                                                        </div>
                                                    </div>
                                                    <div class="pb-2">
                                                        <div>
                                                            <span class="GrundversicherungSpans">Gesellschaft</span>
                                                        </div>
                                                        <div>
                                                            <select class="GrundversicherungInput form-control" name="society_PZ1">
                                                                <option value=""></option>
                                                                <option value="Sympany">Sympany
                                                                </option>
                                                                <option value="Helsana">Helsana
                                                                </option>
                                                                <option value="Swica">Swica</option>
                                                                <option value="GM">GM</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="pb-2">
                                                        <div>
                                                            <span class="GrundversicherungSpans">Produkt</span>
                                                        </div>
                                                        <div>
                                                            <input class="GrundversicherungInput form-control" type="text" name="produkt_PZ1">
                                                        </div>
                                                    </div>
                                                    <div class="pb-3">
                                                        <div>
                                                            <span class="GrundversicherungSpans">VVG Pramie</span>
                                                        </div>
                                                        <div>
                                                            <input class="GrundversicherungInput form-control" type="text" name="vvg_premium_PZ1">
                                                        </div>
                                                    </div>
                                                    <div class="pb-2">
                                                        <div>
                                                            <span class="ZusatzversicherungTitle">Laufzeit</span>
                                                        </div>
                                                        <div>
                                                            <span class="GrundversicherungSpans">From</span>
                                                        </div>
                                                        <div>
                                                            <input class="GrundversicherungInput form-control" type="date" name="duration_from_PZ1" min="1900-01-01" max="9999-12-31">
                                                        </div>
                                                    </div>
                                                    <div class="pb-2">
                                                        <div>
                                                            <span class="GrundversicherungSpans">To</span>
                                                        </div>
                                                        <div>
                                                            <input class="GrundversicherungInput form-control" type="date" name="duration_to_PZ1" min="1900-01-01" max="9999-12-31">
                                                        </div>
                                                    </div>
                                                    <div class="pb-2">
                                                        <div>
                                                            <span class="GrundversicherungSpans">Status</span>
                                                        </div>
                                                        <div>
                                                            <select class="GrundversicherungInput form-control" name="status_PZ1">
                                                                <option selected value="Nicht Ausgewählt">
                                                                    Nicht Ausgewählt
                                                                </option>
                                                                <option value="Aufgenomen">
                                                                    Aufgenomen
                                                                </option>
                                                                <option value="Offen">Offen</option>
                                                                <option value="Abgelehnt">
                                                                    Abgelehnt
                                                                </option>
                                                                <option value="Zuruckgezogen">
                                                                    Zuruckgezogen
                                                                </option>
                                                                <option value="Provisionert">
                                                                    Provisionert
                                                                </option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="pb-2">
                                                        <div>
                                                            <span class="GrundversicherungSpans">Letze Anpassung</span>
                                                        </div>
                                                        <div>
                                                            <input class="GrundversicherungInput form-control" type="date"
{{--                                                                   name="last_adjustment_PZ1"--}}
                                                                   min="1900-01-01" max="9999-12-31" readonly>
                                                        </div>
                                                    </div>
                                                    <div class="pb-2">
                                                        <div>
                                                            <span class="GrundversicherungSpans">Provision</span>
                                                        </div>
                                                        <div>
                                                            <input class="GrundversicherungInput form-control" type="text" name="provision_PZ1">
                                                        </div>
                                                    </div>
                                                    <div class="pb-2">
                                                        <div>
                                                            <span class="GrundversicherungSpans">Gesamtprovision</span>
                                                        </div>
                                                        <div>
                                                            <input class="GrundversicherungInput form-control" type="number" name="total_commisions_PZ1">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="py-4" id="step2BtnDiv">
                                        <div class="row g-0 changeBtnAlign">
                                            <div class="col-4 col-md-3 col-lg-2 me-2">
                                                <button type="button" onclick="backBtnKranken()" class="cancelBtnKranken py-0 py-md-1 w-100">Zurück</button>
                                            </div>
                                            <div class="col-4 col-md-3 col-lg-2 col-lg-1">
                                                <button type="button" onclick="toNextModal1();" class="continueBtn py-0 py-md-1 w-100">Weiter</button>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div id="autoModal" class="documentsFormModals px-4">
                            <div class="" style="position: relative;">
                                <div class="cornerSvgDiv">
                                    <svg class="cornerSvg" viewBox="0 0 243 217" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g filter="url(#filter0_d_28_428)">
                                            <path d="M37.3623 125.778C42.7729 134.784 66.3703 137.598 74.8984 143.797C83.4265 149.996 87.4712 172.365 97.8185 174.815C108.166 177.264 124.613 159.747 135.204 158.073C145.796 156.4 155.994 152.687 165.216 147.146C174.439 141.605 182.506 134.344 188.956 125.778C195.406 117.213 200.113 107.51 202.809 97.224C205.505 86.938 206.136 76.2703 204.666 65.8299C203.197 55.3896 194.367 43.4368 188.956 34.4315L68.6647 34.4315C67.4261 34.4315 66.1893 34.3352 64.9657 34.1435V34.1435C50.4656 31.8724 37.3623 43.0831 37.3623 57.76L37.3623 65.83L37.3623 125.778Z" fill="#EDF0F8"/>
                                        </g>
                                        <path d="M97.5 98C94.4677 98 92 95.7567 92 93C92 90.2433 94.4677 88 97.5 88C100.532 88 103 90.2433 103 93C103 95.7567 100.532 98 97.5 98ZM97.5 91.3333C96.488 91.3333 95.6667 92.08 95.6667 93C95.6667 93.92 96.488 94.6667 97.5 94.6667C98.512 94.6667 99.3333 93.92 99.3333 93C99.3333 92.08 98.512 91.3333 97.5 91.3333Z" fill="#F79C42"/>
                                        <path d="M131 98C127.692 98 125 95.7567 125 93C125 90.2433 127.692 88 131 88C134.308 88 137 90.2433 137 93C137 95.7567 134.308 98 131 98ZM131 91.3333C129.896 91.3333 129 92.08 129 93C129 93.92 129.896 94.6667 131 94.6667C132.104 94.6667 133 93.92 133 93C133 92.08 132.104 91.3333 131 91.3333Z" fill="#F79C42"/>
                                        <path d="M140.093 83.5184C139.605 80.6332 138.019 71.8102 136.301 68.4697C135.158 66.2476 132.221 64.5464 127.579 63.4207C123.806 62.5064 118.984 62 114 62C109.016 62 104.194 62.5027 100.421 63.4207C95.7788 64.55 92.8425 66.2476 91.6988 68.4697C89.9813 71.8066 88.395 80.6332 87.9075 83.5184C85.2862 85.2633 84 87.7878 84 91.1429V100.25C84 102.625 85.5675 104.651 87.75 105.401V109.357C87.75 111.364 89.4338 113 91.5 113H95.25C97.3163 113 99 111.364 99 109.357V105.714H129V109.357C129 111.364 130.684 113 132.75 113H136.5C138.566 113 140.25 111.364 140.25 109.357V105.401C142.433 104.651 144 102.625 144 100.25V91.1429C144 87.7878 142.714 85.2633 140.093 83.5184V83.5184ZM95.0513 70.1017C96.165 67.9415 103.181 65.6429 114 65.6429C124.819 65.6429 131.835 67.9379 132.949 70.1017C134.025 72.1964 135.221 77.7371 135.96 81.6969C135.593 81.5913 135.214 81.4929 134.824 81.4055C133.823 81.176 132.743 80.9902 131.588 80.8372L120.716 73.271C119.876 72.6845 118.703 72.8739 118.099 73.6899C117.495 74.5059 117.69 75.6461 118.53 76.2326L124.403 80.3199C121.215 80.2179 117.72 80.2179 113.996 80.2179C113.558 80.2179 113.123 80.2179 112.688 80.2179L101.91 73.2382C101.048 72.6809 99.885 72.9067 99.3113 73.7446C98.7375 74.5824 98.97 75.7117 99.8325 76.2691L105.998 80.2616C100.969 80.3491 96.5963 80.615 93.1725 81.4055C92.7825 81.4966 92.4038 81.5949 92.0363 81.6969C92.7788 77.7371 93.9713 72.1964 95.0513 70.1017V70.1017ZM95.25 109.357H91.5V105.714H95.25V109.357ZM132.75 109.357V105.714H136.5V109.357H132.75ZM140.25 100.25C140.25 101.255 139.41 102.071 138.375 102.071H89.625C88.59 102.071 87.75 101.255 87.75 100.25V91.1429C87.75 87.7769 89.5725 85.9809 94.0425 84.9464C98.7488 83.8571 105.818 83.8571 114 83.8571C122.183 83.8571 129.248 83.8571 133.958 84.9464C138.428 85.9809 140.25 87.7769 140.25 91.1429V100.25Z" fill="#F79C42"/>
                                        <defs>
                                            <filter id="filter0_d_28_428" x="0.361328" y="0.850342" width="242.078" height="215.199" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                                                <feFlood flood-opacity="0" result="BackgroundImageFix"/>
                                                <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
                                                <feOffset dy="4"/>
                                                <feGaussianBlur stdDeviation="18.5"/>
                                                <feComposite in2="hardAlpha" operator="out"/>
                                                <feColorMatrix type="matrix" values="0 0 0 0 0.875 0 0 0 0 0.875 0 0 0 0 0.875 0 0 0 0.25 0"/>
                                                <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_28_428"/>
                                                <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_28_428" result="shape"/>
                                            </filter>
                                        </defs>
                                    </svg>
                                </div>
                                <div class="row g-0 justify-content-center pt-4">
                                    <div class="col-4 col-md-2">
                                        <div>
                                            <div class="text-center">
                                                <span id="step1Autoo" class="activeStepTitle">Step 1</span>
                                            </div>
                                            <div class="mx-auto">
                                                <div id="step1LineAuto" class="blueLine mx-auto"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-4 col-4 col-md-2">
                                        <div>
                                            <div class="text-center">
                                                <span id="step2Autoo" class="passiveStepTitle">Step 2</span>
                                            </div>
                                            <div>
                                                <div id="step2LineAuto" class="greyLine mx-auto"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="step1Auto">
                                <div class="row g-0 justify-content-center pt-0 pt-md-0">
                                    <div class="col-12 col-md-6 col-lg-4 pe-0 pe-md-2">
                                        <div class="list-choice-title list-choice-title-step2 p-2 mt-4" onclick="openAutoDropdownStep2()">
                                            <div class="row g-0">
                                                <div class="col my-auto">
                                                    <span>Gegenofferte</span>
                                                </div>
                                                <div class="col-auto">
                                                    <svg width="31" height="31" viewBox="0 0 31 31" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <circle cx="15.2314" cy="15.1093" r="15" fill="#2F60DC" />
                                                        <path d="M8.90704 13.1784C8.90681 13.0023 8.96701 12.8254 9.09028 12.6813C9.3644 12.3601 9.84662 12.322 10.1674 12.5968L15.0229 16.746L19.8676 12.5818C20.1876 12.306 20.67 12.3425 20.9449 12.6629C21.2187 12.9825 21.1832 13.4652 20.8635 13.7395L15.5222 18.3312C15.2364 18.5771 14.8142 18.5777 14.5278 18.3327L9.17449 13.7576C8.99823 13.6072 8.90732 13.3932 8.90704 13.1784Z" fill="white" />
                                                    </svg>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="Gegenofferte" class="Grundversicherung mt-4">
                                            <div class="p-3 p-md-4" id="shtogegen">
                                                <div class="">
                                                    <div class="">
                                                            <span class="GrundversicherungSpans">
                                                                Police Hochladen:
                                                            </span>
                                                    </div>
                                                    <div class="">
                                                        <div class="inputFileBG w-100 mt-2">
                                                            <div class="my-2 p-4 text-center">
                                                                <label for="AutoUpload">
                                                                    <div class="mb-2">
                                                                        <svg class="uploadSvgStyle" viewBox="0 0 23 23" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                            <path d="M21 14.6667V18.8889C21 19.4488 20.7776 19.9858 20.3817 20.3817C19.9858 20.7776 19.4488 21 18.8889 21H4.11111C3.55121 21 3.01424 20.7776 2.61833 20.3817C2.22242 19.9858 2 19.4488 2 18.8889V14.6667" stroke="#658BEB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                                                            <path d="M16.7777 7.27778L11.4999 2L6.22217 7.27778" stroke="#658BEB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                                                            <path d="M11.5 2V14.6667" stroke="#658BEB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                                                        </svg>
                                                                    </div>
                                                                    <div>
                                                                        <span class="fileInputSecondTitle">Durchsuche</span>
                                                                    </div>
                                                                    <div>
                                                                        <span class="fileInputFirstTitle">Laden Sie hier Ihre Dateien hoch</span>
                                                                    </div>
                                                                </label>
                                                                <input type="file" id="AutoUpload"
                                                                       name="upload_policeFahrzeug" hidden
                                                                       class="svg-div w-100 border-0  g-0"
                                                                       onchange="upload(this);">
                                                                <input type="text"
                                                                       class="form-control text-center"
                                                                       id="AutoUploadc" disabled
                                                                       style="background:transparent; border:none;">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="mt-3">
                                                        <div class="row g-0 ms-1">
                                                            <div class="col-6 d-flex g-0 my-auto">
                                                                <div class="text-nowrap">
                                                                        <span class="GrundversicherungSpans">
                                                                            Vergleichsart:
                                                                        </span>
                                                                </div>
                                                            </div>
                                                            <div class="col g-0 d-flex justify-content-end">
                                                                <div class="text-end">
                                                                    <select name="vergleichsart_select" class="form-control GrundversicherungInput" id="">
                                                                        <option selected>Auswählen</option>
                                                                        <option value="1:0 Aktualisierung">1:0
                                                                            Aktualisierung
                                                                        </option>
                                                                        <option value="0:1 Downgraden">0:1
                                                                            Downgraden
                                                                        </option>
                                                                        <option value="1:1 Das Gleiche">1:1 Das
                                                                            Gleiche
                                                                        </option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="">
                                                        <div class="mb-3 mt-3">
                                                            <label for="exampleFormControlTextarea1" class="form-label GrundversicherungSpans">Kommentar</label>
                                                            <textarea name="commentFahrenzug" class="form-control GrundversicherungInput showpdf" id="exampleFormControlTextarea1" rows="3"></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row g-0">
                                                    @if(!Auth::user()->hasRole('fs'))
                                                        <div class="col-12">
                                                            <div class="GrundversicherungSpans">
                                                                Neue Offer:
                                                            </div>
                                                            <div class="text-start">
                                                                <div class="inputFileBG w-100 mt-2 mb-3 p-4">
                                                                    <div class="mx-1 my-2 text-center">
                                                                        <label for="AutoUploadNewOffer">
                                                                            <div class="mb-2">
                                                                                <svg class="uploadSvgStyle" viewBox="0 0 23 23" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M21 14.6667V18.8889C21 19.4488 20.7776 19.9858 20.3817 20.3817C19.9858 20.7776 19.4488 21 18.8889 21H4.11111C3.55121 21 3.01424 20.7776 2.61833 20.3817C2.22242 19.9858 2 19.4488 2 18.8889V14.6667" stroke="#658BEB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                                                                    <path d="M16.7777 7.27778L11.4999 2L6.22217 7.27778" stroke="#658BEB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                                                                    <path d="M11.5 2V14.6667" stroke="#658BEB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                                                                </svg>
                                                                            </div>
                                                                            <div>
                                                                                <span class="fileInputSecondTitle">Durchsuche</span>
                                                                            </div>
                                                                            <div>
                                                                                <span class="fileInputFirstTitle">Laden Sie hier Ihre Dateien hoch</span>
                                                                            </div>
                                                                        </label>
                                                                        <input type="file" id="AutoUploadNewOffer"
                                                                               name="offer" hidden
                                                                               class="svg-div w-100 border-0  g-0"
                                                                               onchange="upload(this);">
                                                                        <input type="text"
                                                                               class="form-control text-center"
                                                                               id="AutoUploadNewOfferc" disabled
                                                                               style="background:transparent; border:none;">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    @endif
                                                    <div class="row g-0 justify-content-center">
                                                        <div class="col-auto my-auto">
                                                            <div class="d-inline text-center mt-3" id="add_g" onclick="addanother_item_g()">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="48.694" viewBox="0 0 37.694 37.694" style="cursor:pointer;">
                                                                    <g id="Group_621" data-name="Group 621" transform="translate(-663.236 -976.679)">
                                                                        <g id="Group_550" data-name="Group 550" transform="translate(663.236 976.679)">
                                                                            <rect id="Rectangle_9" data-name="Rectangle 9" width="37.694" height="37.694" rx="18.847" fill="#2F60DC" />
                                                                            <g id="Group_42" data-name="Group 42" transform="translate(12.724 12.724)">
                                                                                <line id="Line_11" data-name="Line 11" y2="11.972" transform="translate(5.986 0)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="2" />
                                                                                <line id="Line_12" data-name="Line 12" x1="11.972" transform="translate(0 5.634)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="2" />
                                                                            </g>
                                                                        </g>
                                                                    </g>
                                                                </svg>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 col-md-6 col-lg-8 ps-0 ps-md-2">
                                        <div class="list-choice-title list-choice-title-step2 p-2 mt-4" onclick="openAutoDropdownStep22()">
                                            <div class="row g-0">
                                                <div class="col my-auto">
                                                    <span>Neues Fahrzeug</span>
                                                </div>
                                                <div class="col-auto">
                                                    <svg width="31" height="31" viewBox="0 0 31 31" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <circle cx="15.2314" cy="15.1093" r="15" fill="#2F60DC" />
                                                        <path d="M8.90704 13.1784C8.90681 13.0023 8.96701 12.8254 9.09028 12.6813C9.3644 12.3601 9.84662 12.322 10.1674 12.5968L15.0229 16.746L19.8676 12.5818C20.1876 12.306 20.67 12.3425 20.9449 12.6629C21.2187 12.9825 21.1832 13.4652 20.8635 13.7395L15.5222 18.3312C15.2364 18.5771 14.8142 18.5777 14.5278 18.3327L9.17449 13.7576C8.99823 13.6072 8.90732 13.3932 8.90704 13.1784Z" fill="white" />
                                                    </svg>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="Zusatzversicherung mt-4" id="NeuesFahrzeug">
                                            <div class="p-4" id="shtonew">
                                                <div class="">
                                                    <div class="row">
                                                        <div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6">
                                                            <div class="mb-3">
                                                                <div class="">
                                                                    <div class="">
                                                                            <span class="GrundversicherungSpans">
                                                                                Fahrzeugausweis hochladen
                                                                            </span>
                                                                    </div>
                                                                    <div class="inputFileBG w-100 mt-2">
                                                                        <div class="mx-1 my-2 p-4 text-center">
                                                                            <label for="AutoUploadNewFahrenzug">
                                                                                <div class="mb-2">
                                                                                    <svg class="uploadSvgStyle" viewBox="0 0 23 23" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                                        <path d="M21 14.6667V18.8889C21 19.4488 20.7776 19.9858 20.3817 20.3817C19.9858 20.7776 19.4488 21 18.8889 21H4.11111C3.55121 21 3.01424 20.7776 2.61833 20.3817C2.22242 19.9858 2 19.4488 2 18.8889V14.6667" stroke="#658BEB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                                                                        <path d="M16.7777 7.27778L11.4999 2L6.22217 7.27778" stroke="#658BEB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                                                                        <path d="M11.5 2V14.6667" stroke="#658BEB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                                                                    </svg>
                                                                                </div>
                                                                                <div>
                                                                                    <span class="fileInputSecondTitle">Durchsuche</span>
                                                                                </div>
                                                                                <div>
                                                                                    <span class="fileInputFirstTitle">Laden Sie hier Ihre Dateien hoch</span>
                                                                                </div>
                                                                            </label>
                                                                            <input type="file" id="AutoUploadNewFahrenzug"
                                                                                   name="vehicle_id" hidden
                                                                                   class="svg-div w-100 border-0  g-0"
                                                                                   onchange="upload(this);">
                                                                            <input type="text"
                                                                                   class="form-control text-center"
                                                                                   id="AutoUploadNewFahrenzugc"
                                                                                   name="vehicle_id" disabled
                                                                                   style="background:transparent; border:none;">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col">
                                                            <div class="">
                                                                <div class="row g-0">
                                                                    <div class="col my-auto">
                                                                        <div class="">
                                                                                <span class="GrundversicherungSpans ">
                                                                                    Leasing:
                                                                                </span>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-auto">
                                                                        <div class="btn-group w-100" role="group" aria-label="Basic radio toggle button group">
                                                                            <input type="radio" class="btn-check showpdf" value="Ja" name="leasing" id="btnradio1" autocomplete="off" checked>
                                                                            <label onclick="yesBtnLeasingClickedd();" id="yesBtnLeasing" class="inFormYesNoBtn documentFormBtn px-0 me-1" value="Ja" for="btnradio1" onclick="showel(this)">Ja</label>
                                                                            <input type="radio" class="btn-check" name="leasing" value="Nein" id="btnradio2" autocomplete="off">
                                                                            <label onclick="noBtnLeasingClickedd();" id="noBtnLeasing" class="inFormYesNoBtn documentFormBtn px-0" for="btnradio2">Nein</label>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row g-0 pt-3">
                                                                        <div class="col-12">
                                                                            <select name="leasing_name" class="w-100 form-control GrundversicherungInput" id="">
                                                                                <option value="Gesellschaft">
                                                                                    Gesellschaft
                                                                                </option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="my-3">
                                                        <div class="row">
                                                            <div class="col">
                                                                <div class="">
                                                                    <div class="">
                                                                            <span class="ZusatzversicherungTitle">
                                                                                Fahrzeuginformationen
                                                                            </span>
                                                                    </div>
                                                                    <div class="input-select-div mb-2">
                                                                        <div class="text-nowrap">
                                                                                <span class="GrundversicherungSpans">
                                                                                    Kaufjahr
                                                                                </span>
                                                                        </div>
                                                                        <select name="year_of_purchase" class="GrundversicherungInput form-control showpdf" aria-label="Default select example" id="">
                                                                            <option selected></option>
                                                                            @for($i = \Carbon\Carbon::now()->format('Y'); $i >= 1950 ;$i--)
                                                                                <option value="{{$i}}">{{$i}}</option>
                                                                            @endfor
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="date-input-div mb-2">
                                                                    <div class="">
                                                                            <span class="GrundversicherungSpans">
                                                                                Este inverkehrssetzung:
                                                                            </span>
                                                                    </div>

                                                                    <input name="first_intro" type="date" class="GrundversicherungInput form-control showpdf">

                                                                </div>
                                                                <div class="date-input-div mb-2">
                                                                    <div class="">
                                                                            <span class="GrundversicherungSpans">
                                                                                Beginn Versicherung:
                                                                            </span>
                                                                    </div>

                                                                    <input name="insurance_date" type="date" class="GrundversicherungInput form-control showpdf">

                                                                </div>
                                                                <div class="mb-2">
                                                                    <div class="">
                                                                            <span class="GrundversicherungSpans">
                                                                                Eingelöster Kanton:
                                                                            </span>
                                                                    </div>
                                                                    <select name="redeemed" class="GrundversicherungInput form-control showpdf" aria-label="Default select example">
                                                                        <option selected></option>
                                                                        <option value="Zürich">Zürich</option>
                                                                        <option value="Bern">Bern</option>
                                                                        <option value="Luzern">Luzern</option>
                                                                        <option value="Uri">Uri</option>
                                                                        <option value="Schwyz">Schwyz</option>
                                                                        <option value="Obwalden">Obwalden</option>
                                                                        <option value="Nidwalden">Nidwalden</option>
                                                                        <option value="Glarus">Glarus</option>
                                                                        <option value="Zug">Zug</option>
                                                                        <option value="Freiburg">Freiburg</option>
                                                                        <option value="Solothurn">Solothurn</option>
                                                                        <option value="Basel-Stadt">Basel-Stadt
                                                                        </option>
                                                                        <option value="Basel-Landschaft">
                                                                            Basel-Landschaft
                                                                        </option>
                                                                        <option value="Schaffhausen">Schaffhausen
                                                                        </option>
                                                                        <option value="Appenzell A.Rh.">Appenzell
                                                                            A.Rh.
                                                                        </option>
                                                                        <option value="Appenzell I.Rh.">Appenzell
                                                                            I.Rh.
                                                                        </option>
                                                                        <option value="Sankt Gallen">Sankt Gallen
                                                                        </option>
                                                                        <option value="Graubünden">Graubünden
                                                                        </option>
                                                                        <option value="Aargau">Aargau</option>
                                                                        <option value="Thurgau">Thurgau</option>
                                                                        <option value="Tessin">Tessin</option>
                                                                        <option value="Waadt">Waadt</option>
                                                                        <option value="Wallis">Wallis</option>
                                                                        <option value="Neuenburg">Neuenburg</option>
                                                                        <option value="Genf">Genf</option>
                                                                        <option value="Jura">Jura</option>
                                                                    </select>
                                                                </div>
                                                                <div class="mb-2">
                                                                    <div class="">
                                                                            <span class="GrundversicherungSpans">
                                                                                KM - Stand:
                                                                            </span>
                                                                    </div>

                                                                    <input name="km_stood" class="GrundversicherungInput form-control showpdf" type="number" id="">

                                                                </div>
                                                            </div>
                                                            <div class="col">
                                                                <div class="">
                                                                    <div class="">
                                                                            <span class="ZusatzversicherungTitle">
                                                                                Lenkerinformation
                                                                            </span>
                                                                    </div>
                                                                </div>
                                                                <div class="date-input-div mb-2">
                                                                    <div class="">
                                                                            <span class="GrundversicherungSpans">
                                                                                Ausstelldatum Fuhrerausweis:
                                                                            </span>
                                                                    </div>

                                                                    <input name="placing_on_the_market" type="date" class="GrundversicherungInput form-control showpdf">

                                                                </div>
                                                                <div class=" mb-2">
                                                                    <div class="">
                                                                            <span class="GrundversicherungSpans">
                                                                                Nationalität:
                                                                            </span>
                                                                    </div>
                                                                    <select class="GrundversicherungInput form-control showpdf" name="nationality">
                                                                        <option value="Swiss">Swiss</option>
                                                                        <option value="Deutschland">Deutschland
                                                                        </option>
                                                                        <option value="Italien">Italien</option>
                                                                        <option value="French">French</option>
                                                                        <optgroup label="A">
                                                                            <option value="Afghanistan">
                                                                                Afghanistan
                                                                            </option>
                                                                            <option value="Ägypten">Ägypten</option>
                                                                            <option value="Åland">Åland</option>
                                                                            <option value="Albanien">Albanien
                                                                            </option>
                                                                            <option value="Algerien">Algerien
                                                                            </option>
                                                                            <option value="Amerikanisch-Samoa">
                                                                                Amerikanisch-Samoa
                                                                            </option>
                                                                            <option value="Amerikanische Jungferninseln">
                                                                                Amerikanische Jungferninseln
                                                                            </option>
                                                                            <option value="Andorra">Andorra</option>
                                                                            <option value="Angola">Angola</option>
                                                                            <option value="Anguilla">Anguilla
                                                                            </option>
                                                                            <option value="Antarktis">Antarktis
                                                                            </option>
                                                                            <option value="Antigua und Barbuda">
                                                                                Antigua und Barbuda
                                                                            </option>
                                                                            <option value="Äquatorialguinea">
                                                                                Äquatorialguinea
                                                                            </option>
                                                                            <option value="Argentinien">
                                                                                Argentinien
                                                                            </option>
                                                                            <option value="Armenien">Armenien
                                                                            </option>
                                                                            <option value="Aruba">Aruba</option>
                                                                            <option value="Ascension">Ascension
                                                                            </option>
                                                                            <option value="Aserbaidschan">
                                                                                Aserbaidschan
                                                                            </option>
                                                                            <option value="Äthiopien">Äthiopien
                                                                            </option>
                                                                            <option value="Australien">Australien
                                                                            </option>
                                                                        </optgroup>
                                                                        <optgroup label="B">
                                                                            <option value="Bahamas">Bahamas</option>
                                                                            <option value="Bahrain">Bahrain</option>
                                                                            <option value="Bangladesch">
                                                                                Bangladesch
                                                                            </option>
                                                                            <option value="Barbados">Barbados
                                                                            </option>
                                                                            <option value="Belarus">Belarus</option>
                                                                            <option value="Belgien">Belgien</option>
                                                                            <option value="Belize">Belize</option>
                                                                            <option value="Benin">Benin</option>
                                                                            <option value="Bermuda">Bermuda</option>
                                                                            <option value="Bhutan">Bhutan</option>
                                                                            <option value="Bolivien">Bolivien
                                                                            </option>
                                                                            <option value="Bosnien und Herzegowina">
                                                                                Bosnien und Herzegowina
                                                                            </option>
                                                                            <option value="Botswana">Botswana
                                                                            </option>
                                                                            <option value="Bouvetinsel">
                                                                                Bouvetinsel
                                                                            </option>
                                                                            <option value="Brasilien">Brasilien
                                                                            </option>
                                                                            <option value="Britische Jungferninseln">
                                                                                Britische Jungferninseln
                                                                            </option>
                                                                            <option value="Britisches Territorium im Indischen Ozean">
                                                                                Britisches Territorium im Indischen
                                                                                Ozean
                                                                            </option>
                                                                            <option value="Brunei Darussalam">Brunei
                                                                                Darussalam
                                                                            </option>
                                                                            <option value="Bulgarien">Bulgarien
                                                                            </option>
                                                                            <option value="Burkina Faso">Burkina
                                                                                Faso
                                                                            </option>
                                                                            <option value="Burundi">Burundi</option>
                                                                        </optgroup>
                                                                        <optgroup label="C">
                                                                            <option value="Ceuta, Melilla">Ceuta,
                                                                                Melilla
                                                                            </option>
                                                                            <option value="Chile">Chile</option>
                                                                            <option value="Volksrepublik China">
                                                                                Volksrepublik China
                                                                            </option>
                                                                            <option value="Clipperton">Clipperton
                                                                            </option>
                                                                            <option value="Cookinseln">Cookinseln
                                                                            </option>
                                                                            <option value="Costa Rica">Costa Rica
                                                                            </option>
                                                                            <option value="Côte d'Ivoire">Côte
                                                                                d'Ivoire
                                                                            </option>
                                                                        </optgroup>
                                                                        <optgroup label="D">
                                                                            <option value="Dänemark">Dänemark
                                                                            </option>
                                                                            <option value="Deutschland">
                                                                                Deutschland
                                                                            </option>
                                                                            <option value="Diego Garcia">Diego
                                                                                Garcia
                                                                            </option>
                                                                            <option value="Dominica">Dominica
                                                                            </option>
                                                                            <option value="Dominikanische Republik">
                                                                                Dominikanische Republik
                                                                            </option>
                                                                            <option value="Dschibuti">Dschibuti
                                                                            </option>
                                                                        </optgroup>
                                                                        <optgroup label="E">
                                                                            <option value="Ecuador">Ecuador</option>
                                                                            <option value="El Salvador">El
                                                                                Salvador
                                                                            </option>
                                                                            <option value="Eritrea">Eritrea</option>
                                                                            <option value="Estland">Estland</option>
                                                                        </optgroup>
                                                                        <optgroup label="F">
                                                                            <option value="Falklandinseln">
                                                                                Falklandinseln
                                                                            </option>
                                                                            <option value="Färöer">Färöer</option>
                                                                            <option value="Fidschi">Fidschi</option>
                                                                            <option value="Finnland">Finnland
                                                                            </option>
                                                                            <option value="Frankreich">Frankreich
                                                                            </option>
                                                                            <option value="Französisch-Guayana">
                                                                                Französisch-Guayana
                                                                            </option>
                                                                            <option value="Französisch-Polynesien">
                                                                                Französisch-Polynesien
                                                                            </option>
                                                                        </optgroup>
                                                                        <optgroup label="G">
                                                                            <option value="Gabun">Gabun</option>
                                                                            <option value="Gambia">Gambia</option>
                                                                            <option value="Georgien">Georgien
                                                                            </option>
                                                                            <option value="Ghana">Ghana</option>
                                                                            <option value="Gibraltar">Gibraltar
                                                                            </option>
                                                                            <option value="Grenada">Grenada</option>
                                                                            <option value="Griechenland">
                                                                                Griechenland
                                                                            </option>
                                                                            <option value="Grönland">Grönland
                                                                            </option>
                                                                            <option value="Großbritannien">
                                                                                Großbritannien
                                                                            </option>
                                                                            <option value="Guadeloupe">Guadeloupe
                                                                            </option>
                                                                            <option value="Guam">Guam</option>
                                                                            <option value="Guatemala">Guatemala
                                                                            </option>
                                                                            <option value="Guernsey (Kanalinsel)">
                                                                                Guernsey (Kanalinsel)
                                                                            </option>
                                                                            <option value="Guinea">Guinea</option>
                                                                            <option value="Guinea-Bissau">
                                                                                Guinea-Bissau
                                                                            </option>
                                                                            <option value="Guyana">Guyana</option>
                                                                        </optgroup>
                                                                        <optgroup label="H">
                                                                            <option value="Haiti">Haiti</option>
                                                                            <option value="Heard- und McDonald-Inseln">
                                                                                Heard- und McDonald-Inseln
                                                                            </option>
                                                                            <option value="Honduras">Honduras
                                                                            </option>
                                                                            <option value="Hongkong">Hongkong
                                                                            </option>
                                                                        </optgroup>
                                                                        <optgroup label="I">
                                                                            <option value="Indien">Indien</option>
                                                                            <option value="Indonesien">Indonesien
                                                                            </option>
                                                                            <option value="Insel Man">Insel Man
                                                                            </option>
                                                                            <option value="Irak">Irak</option>
                                                                            <option value="Iran">Iran</option>
                                                                            <option value="Irland">Irland</option>
                                                                            <option value="Island">Island</option>
                                                                            <option value="Israel">Israel</option>
                                                                            <option value="Italien">Italien</option>
                                                                        </optgroup>
                                                                        <optgroup label="J">
                                                                            <option value="Jamaika">Jamaika</option>
                                                                            <option value="Japan">Japan</option>
                                                                            <option value="Jemen">Jemen</option>
                                                                            <option value="Jersey (Kanalinsel)">
                                                                                Jersey (Kanalinsel)
                                                                            </option>
                                                                            <option value="Jordanien">Jordanien
                                                                            </option>
                                                                        </optgroup>
                                                                        <optgroup label="K">
                                                                            <option value="Kaimaninseln">
                                                                                Kaimaninseln
                                                                            </option>
                                                                            <option value="Kambodscha">Kambodscha
                                                                            </option>
                                                                            <option value="Kamerun">Kamerun</option>
                                                                            <option value="Kanada">Kanada</option>
                                                                            <option value="Kanarische Inseln">
                                                                                Kanarische Inseln
                                                                            </option>
                                                                            <option value="Kap Verde">Kap Verde
                                                                            </option>
                                                                            <option value="Kasachstan">Kasachstan
                                                                            </option>
                                                                            <option value="Katar">Katar</option>
                                                                            <option value="Kenia">Kenia</option>
                                                                            <option value="Kirgisistan">
                                                                                Kirgisistan
                                                                            </option>
                                                                            <option value="Kiribati">Kiribati
                                                                            </option>
                                                                            <option value="Kokosinseln">
                                                                                Kokosinseln
                                                                            </option>
                                                                            <option value="Kolumbien">Kolumbien
                                                                            </option>
                                                                            <option value="Komoren">Komoren</option>
                                                                            <option value="Demokratische Republik Kongo">
                                                                                Demokratische Republik Kongo
                                                                            </option>
                                                                            <option value="Demokratische Volksrepublik Korea (Nordkorea)">
                                                                                Demokratische Volksrepublik Korea
                                                                                (Nordkorea)
                                                                            </option>
                                                                            <option value="Republik Korea (Südkorea)">
                                                                                Republik Korea (Südkorea)
                                                                            </option>
                                                                            <option value="Kosovo">Kosovo</option>
                                                                            <option value="Kroatien">Kroatien
                                                                            </option>
                                                                            <option value="Kuba">Kuba</option>
                                                                            <option value="Kuwait">Kuwait</option>
                                                                        </optgroup>
                                                                        <optgroup label="L">
                                                                            <option value="Laos">Laos</option>
                                                                            <option value="Lesotho">Lesotho</option>
                                                                            <option value="Lettland">Lettland
                                                                            </option>
                                                                            <option value="Libanon">Libanon</option>
                                                                            <option value="Liberia">Liberia</option>
                                                                            <option value="Libyen">Libyen</option>
                                                                            <option value="Liechtenstein">
                                                                                Liechtenstein
                                                                            </option>
                                                                            <option value="Litauen">Litauen</option>
                                                                            <option value="Luxemburg">Luxemburg
                                                                            </option>
                                                                        </optgroup>
                                                                        <optgroup label="M">
                                                                            <option value="Macao">Macao</option>
                                                                            <option value="Madagaskar">Madagaskar
                                                                            </option>
                                                                            <option value="Malawi">Malawi</option>
                                                                            <option value="Malaysia">Malaysia
                                                                            </option>
                                                                            <option value="Malediven">Malediven
                                                                            </option>
                                                                            <option value="Mali">Mali</option>
                                                                            <option value="Malta">Malta</option>
                                                                            <option value="Marokko">Marokko</option>
                                                                            <option value="Marshallinseln">
                                                                                Marshallinseln
                                                                            </option>
                                                                            <option value="Martinique">Martinique
                                                                            </option>
                                                                            <option value="Mauretanien">
                                                                                Mauretanien
                                                                            </option>
                                                                            <option value="Mauritius">Mauritius
                                                                            </option>
                                                                            <option value="Mayotte">Mayotte</option>
                                                                            <option value="Mazedonien">Mazedonien
                                                                            </option>
                                                                            <option value="Mexiko">Mexiko</option>
                                                                            <option value="Mikronesien">
                                                                                Mikronesien
                                                                            </option>
                                                                            <option value="Moldawien (Republik Moldau)">
                                                                                Moldawien (Republik Moldau)
                                                                            </option>
                                                                            <option value="Monaco">Monaco</option>
                                                                            <option value="Mongolei">Mongolei
                                                                            </option>
                                                                            <option value="Montenegro">Montenegro
                                                                            </option>
                                                                            <option value="Montserrat">Montserrat
                                                                            </option>
                                                                            <option value="Mosambik">Mosambik
                                                                            </option>
                                                                            <option value="Myanmar">Myanmar
                                                                                (Burma)
                                                                            </option>
                                                                        </optgroup>
                                                                        <optgroup label="N">
                                                                            <option value="Namibia">Namibia</option>
                                                                            <option value="Nauru">Nauru</option>
                                                                            <option value="Nepal">Nepal</option>
                                                                            <option value="Neukaledonien">
                                                                                Neukaledonien
                                                                            </option>
                                                                            <option value="Neuseeland">Neuseeland
                                                                            </option>
                                                                            <option value="Nicaragua">Nicaragua
                                                                            </option>
                                                                            <option value="Niederlande">
                                                                                Niederlande
                                                                            </option>
                                                                            <option value="Niederländische Antillen">
                                                                                Niederländische Antillen
                                                                            </option>
                                                                            <option value="Niger">Niger</option>
                                                                            <option value="Nigeria">Nigeria</option>
                                                                            <option value="Niue">Niue</option>
                                                                            <option value="Nördliche Marianen">
                                                                                Nördliche Marianen
                                                                            </option>
                                                                            <option value="Norfolkinsel">
                                                                                Norfolkinsel
                                                                            </option>
                                                                            <option value="Norwegen">Norwegen
                                                                            </option>
                                                                        </optgroup>
                                                                        <optgroup label="O">
                                                                            <option value="Oman">Oman</option>
                                                                            <option value="Orbit">Orbit</option>
                                                                            <option value="Österreich">Österreich
                                                                            </option>
                                                                            <option value="Osttimor (Timor-Leste)">
                                                                                Osttimor (Timor-Leste)
                                                                            </option>
                                                                        </optgroup>
                                                                        <optgroup label="P">
                                                                            <option value="Pakistan">Pakistan
                                                                            </option>
                                                                            <option value="Palästinensische Autonomiegebiete">
                                                                                Palästinensische Autonomiegebiete
                                                                            </option>
                                                                            <option value="Palau">Palau</option>
                                                                            <option value="Panama">Panama</option>
                                                                            <option value="Papua-Neuguinea">
                                                                                Papua-Neuguinea
                                                                            </option>
                                                                            <option value="Paraguay">Paraguay
                                                                            </option>
                                                                            <option value="Peru">Peru</option>
                                                                            <option value="Philippinen">
                                                                                Philippinen
                                                                            </option>
                                                                            <option value="Pitcairninseln">
                                                                                Pitcairninseln
                                                                            </option>
                                                                            <option value="Polen">Polen</option>
                                                                            <option value="Portugal">Portugal
                                                                            </option>
                                                                            <option value="Puerto Rico">Puerto
                                                                                Rico
                                                                            </option>
                                                                        </optgroup>
                                                                        <optgroup label="R">
                                                                            <option value="Republik China (Taiwan)">
                                                                                Republik China (Taiwan)
                                                                            </option>
                                                                            <option value="Republik Kongo">Republik
                                                                                Kongo
                                                                            </option>
                                                                            <option value="Réunion">Réunion</option>
                                                                            <option value="Ruanda">Ruanda</option>
                                                                            <option value="Rumänien">Rumänien
                                                                            </option>
                                                                            <option value="Russische Föderation">
                                                                                Russische Föderation
                                                                            </option>
                                                                        </optgroup>
                                                                        <optgroup label="S">
                                                                            <option value="Saint-Barthélemy">
                                                                                Saint-Barthélemy
                                                                            </option>
                                                                            <option value="Saint-Martin">
                                                                                Saint-Martin
                                                                            </option>
                                                                            <option value="Salomonen">Salomonen
                                                                            </option>
                                                                            <option value="Sambia">Sambia</option>
                                                                            <option value="Samoa">Samoa</option>
                                                                            <option value="San Marino">San Marino
                                                                            </option>
                                                                            <option value="São Tomé und Príncipe">
                                                                                São Tomé und Príncipe
                                                                            </option>
                                                                            <option value="Saudi-Arabien">
                                                                                Saudi-Arabien
                                                                            </option>
                                                                            <option value="Schweden">Schweden
                                                                            </option>
                                                                            <option value="Schweiz">Schweiz</option>
                                                                            <option value="Senegal">Senegal</option>
                                                                            <option value="Serbien">Serbien</option>
                                                                            <option value="Seychellen">Seychellen
                                                                            </option>
                                                                            <option value="Sierra Leone">Sierra
                                                                                Leone
                                                                            </option>
                                                                            <option value="Simbabwe">Simbabwe
                                                                            </option>
                                                                            <option value="Singapur">Singapur
                                                                            </option>
                                                                            <option value="Slowakei">Slowakei
                                                                            </option>
                                                                            <option value="Slowenien">Slowenien
                                                                            </option>
                                                                            <option value="Somalia">Somalia</option>
                                                                            <option value="Spanien">Spanien</option>
                                                                            <option value="Sri Lanka">Sri Lanka
                                                                            </option>
                                                                            <option value="St. Helena">St. Helena
                                                                            </option>
                                                                            <option value="St. Kitts und Nevis">St.
                                                                                Kitts und Nevis
                                                                            </option>
                                                                            <option value="St. Lucia">St. Lucia
                                                                            </option>
                                                                            <option value="Saint-Pierre und Miquelon">
                                                                                Saint-Pierre und Miquelon
                                                                            </option>
                                                                            <option value="St. Vincent und die Grenadinen">
                                                                                St. Vincent und die Grenadinen
                                                                            </option>
                                                                            <option value="Südafrika">Südafrika
                                                                            </option>
                                                                            <option value="Sudan">Sudan</option>
                                                                            <option value="Südgeorgien und die Südlichen Sandwichinseln">
                                                                                Südgeorgien und die Südlichen
                                                                                Sandwichinseln
                                                                            </option>
                                                                            <option value="Suriname">Suriname
                                                                            </option>
                                                                            <option value="Svalbard und Jan Mayen">
                                                                                Svalbard und Jan Mayen
                                                                            </option>
                                                                            <option value="Swasiland">Swasiland
                                                                            </option>
                                                                            <option value="Syrien">Syrien</option>
                                                                        </optgroup>
                                                                        <optgroup label="T">
                                                                            <option value="Tadschikistan">
                                                                                Tadschikistan
                                                                            </option>
                                                                            <option value="Tansania">Tansania
                                                                            </option>
                                                                            <option value="Thailand">Thailand
                                                                            </option>
                                                                            <option value="Togo">Togo</option>
                                                                            <option value="Tokelau">Tokelau</option>
                                                                            <option value="Tonga">Tonga</option>
                                                                            <option value="Trinidad und Tobago">
                                                                                Trinidad und Tobago
                                                                            </option>
                                                                            <option value="Tristan da Cunha">Tristan
                                                                                da Cunha
                                                                            </option>
                                                                            <option value="Tschad">Tschad</option>
                                                                            <option value="Tschechische Republik">
                                                                                Tschechische Republik
                                                                            </option>
                                                                            <option value="Tunesien">Tunesien
                                                                            </option>
                                                                            <option value="Türkei">Türkei</option>
                                                                            <option value="Turkmenistan">
                                                                                Turkmenistan
                                                                            </option>
                                                                            <option value="Turks- und Caicosinseln">
                                                                                Turks- und Caicosinseln
                                                                            </option>
                                                                            <option value="Tuvalu">Tuvalu</option>
                                                                        </optgroup>
                                                                        <optgroup label="U">
                                                                            <option value="Uganda">Uganda</option>
                                                                            <option value="Ukraine">Ukraine</option>
                                                                            <option value="Ungarn">Ungarn</option>
                                                                            <option value="Uruguay">Uruguay</option>
                                                                            <option value="Usbekistan">Usbekistan
                                                                            </option>
                                                                        </optgroup>
                                                                        <optgroup label="V">
                                                                            <option value="Vanuatu">Vanuatu</option>
                                                                            <option value="Vatikanstadt">
                                                                                Vatikanstadt
                                                                            </option>
                                                                            <option value="Venezuela">Venezuela
                                                                            </option>
                                                                            <option value="Vereinigte Arabische Emirate">
                                                                                Vereinigte Arabische Emirate
                                                                            </option>
                                                                            <option value="Vereinigte Staaten von Amerika (USA)">
                                                                                Vereinigte Staaten von Amerika (USA)
                                                                            </option>
                                                                            <option value="Vereinigtes Königreich Großbritannien und Nordirland">
                                                                                Vereinigtes Königreich
                                                                                Großbritannien und Nordirland
                                                                            </option>
                                                                            <option value="Vietnam">Vietnam</option>
                                                                        </optgroup>
                                                                        <optgroup label="W">
                                                                            <option value="Wallis und Futuna">Wallis
                                                                                und Futuna
                                                                            </option>
                                                                            <option value="Weihnachtsinsel">
                                                                                Weihnachtsinsel
                                                                            </option>
                                                                            <option value="Westsahara">Westsahara
                                                                            </option>
                                                                        </optgroup>
                                                                        <optgroup label="Z">
                                                                            <option value="Zentralafrikanische Republik">
                                                                                Zentralafrikanische Republik
                                                                            </option>
                                                                            <option value="Zypern">Zypern</option>
                                                                        </optgroup>
                                                                    </select>
                                                                </div>
                                                                <div class="mb-2">
                                                                    <div class="">
                                                                            <span class="GrundversicherungSpans">
                                                                                Häufigster Lenker?
                                                                            </span>
                                                                    </div>
                                                                    <select name="most_common" class="GrundversicherungInput form-control showpdf" aria-label="Default select example">
                                                                        <option selected></option>
                                                                        <option value="Ja">Ja</option>
                                                                        <option value="Nein">Nein</option>

                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="my-3">
                                                        <div class="row">
                                                            <div class="col">
                                                                <div class="">
                                                                        <span class="ZusatzversicherungTitle">
                                                                            Gewünschte Deckung
                                                                        </span>
                                                                </div>
                                                                <div class=" mb-2">
                                                                    <div class="">
                                                                            <span class="GrundversicherungSpans">
                                                                                Versischerung:
                                                                            </span>
                                                                    </div>
                                                                    <select name="insurance" class="GrundversicherungInput form-control showpdf" aria-label="Default select example">
                                                                        <option selected></option>
                                                                        <option value="Haftpflicht">Haftpflicht
                                                                        </option>
                                                                        <option value="Teilkasko">Teilkasko</option>
                                                                        <option value="Vollkasko">Vollkasko</option>
                                                                    </select>

                                                                </div>
                                                                <div class=" mb-2">
                                                                    <div class="">
                                                                            <span class="GrundversicherungSpans">
                                                                                Selbstbehalt Teilkasko:
                                                                            </span>
                                                                    </div>
                                                                    <select name="deductible" class="GrundversicherungInput form-control showpdf" aria-label="Default select example">

                                                                        <option selected></option>
                                                                        <option value="500">500</option>
                                                                        <option value="1000">1000</option>
                                                                        <option value="1500">1500</option>
                                                                        <option value="2000">2000</option>
                                                                    </select>
                                                                </div>
                                                                <div class="mb-2">
                                                                    <div class="">
                                                                            <span class="GrundversicherungSpans">
                                                                                Mitgeführte Sachen:
                                                                            </span>
                                                                    </div>
                                                                    <select name="carried" class="GrundversicherungInput form-control showpdf" aria-label="Default select example">

                                                                        <option selected></option>
                                                                        @for($i=1000;$i<=20000;$i+=1000) <option value="{{$i}}">{{$i}}</option>
                                                                        @endfor

                                                                    </select>
                                                                </div>
                                                                <div class="">
                                                                        <span class="GrundversicherungSpans">
                                                                            Reparaturwerkstatt:
                                                                        </span>
                                                                    <!-- <div class="input-group mb-2">
                                                                  <input name="noname" type="text" placeholder="Partnergarage" class="form-control" aria-label=""
                                                                    aria-describedby="basic-addon1">
                                                                  <input name="noname" type="text" placeholder="Freie Wahl" class="form-control" aria-label=""
                                                                    aria-describedby="basic-addon1">
                                                                </div> -->
                                                                    <div class="row g-0 justify-content-start" role="group" aria-label="Basic radio toggle button group">
                                                                        <div class="col-6 pe-1">
                                                                            <input type="radio" class="btn-check showpdf " name="repair_shop" id="btnradio1_" value="Specific garage" checked>
                                                                            <label onclick="yesBtnGarageClickedd();" id="yesBtnGarage" class="inFormYesNoBtn documentFormBtn w-100 fs-6" for="btnradio1_">Specific
                                                                                garage</label>
                                                                        </div>
                                                                        <div class="col-6 my-auto">
                                                                            <input type="radio" class="btn-check " name="repair_shop" value="Freie Wahl" id="btnradio2_">
                                                                            <label onclick="noBtnGarageClickedd();" id="noBtnGarage" class="inFormYesNoBtn documentFormBtn w-100 fs-6" for="btnradio2_">Freie Wahl</label>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <script>

                                                                </script>

                                                                <div class="input-div1 mb-2">
                                                                    <div class="">
                                                                            <span class="GrundversicherungSpans">
                                                                                + Unfalldeckung:
                                                                            </span>
                                                                    </div>
                                                                    <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                                                                        <input type="radio" class="btn-check showpdf" name="accident_coverage" value="Ja" id="btnradio3abcdef" autocomplete="off" checked>
                                                                        <label onclick="yesBtnUnfalldeckungClickedd()" id="yesBtnUnfalldeckung" class="inFormYesNoBtn me-1 documentFormBtn" for="btnradio3abcdef">Ja</label>

                                                                        <input onclick="noBtnUnfalldeckungClickedd()" type="radio" class="btn-check " name="accident_coverage" value="Nein" id="btnradio4abcdef" autocomplete="off">
                                                                        <label id="noBtnUnfalldeckung" class="inFormYesNoBtn documentFormBtn" for="btnradio4abcdef">Nein</label>
                                                                    </div>
                                                                </div>

                                                            </div>
                                                            <div class="col">
                                                                <div class="input-div1 mb-2">
                                                                    <div class="">
                                                                            <span class="GrundversicherungSpans">
                                                                                + Verkehrsrechtsschutz:
                                                                            </span>
                                                                    </div>
                                                                    <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                                                                        <input type="radio" class="btn-check showpdf" name="traffic_legal_protection" value="Ja" id="btnradio3a" autocomplete="off" checked>
                                                                        <label id="yesBtnVerkehrsrechtsschutz" onclick="yesBtnVerkehrsrechtsschutzClickedd()" class="inFormYesNoBtn documentFormBtn me-1" for="btnradio3a">Ja</label>

                                                                        <input type="radio" class="btn-check" name="traffic_legal_protection" value="Nein" id="btnradio4a" autocomplete="off">
                                                                        <label id="noBtnVerkehrsrechtsschutz" onclick="noBtnVerkehrsrechtsschutzClickedd()" class="inFormYesNoBtn documentFormBtn " for="btnradio4a">Nein</label>
                                                                    </div>
                                                                </div>

                                                                <div class="input-div1 mb-2">
                                                                    <div class="">
                                                                            <span class="GrundversicherungSpans">
                                                                                + Grobfahrlässigkeitschutz:
                                                                            </span>
                                                                    </div>
                                                                    <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                                                                        <input type="radio" class="btn-check showpdf" name="grossly" value="Ja" id="btnradio3ab" autocomplete="off" checked>
                                                                        <label onclick="yesBtnGrobfahrlässigkeitschutzClickedd()" id="yesBtnGrobfahrlässigkeitschutz" class="inFormYesNoBtn documentFormBtn me-1" for="btnradio3ab">Ja</label>

                                                                        <input type="radio" class="btn-check" name="grossly" value="Nein" id="btnradio4ab" autocomplete="off">
                                                                        <label onclick="noBtnGrobfahrlässigkeitschutzClickedd()" id="noBtnGrobfahrlässigkeitschutz" class="inFormYesNoBtn documentFormBtn " for="btnradio4ab">Nein</label>
                                                                    </div>
                                                                </div>

                                                                <div class="input-div1 mb-2">
                                                                    <div class="">
                                                                            <span class="GrundversicherungSpans">
                                                                                + Glasschutz:
                                                                            </span>
                                                                    </div>
                                                                    <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                                                                        <input type="radio" class="btn-check showpdf" name="glass_protection" value="Ja" id="btnradio3abc" autocomplete="off" checked>
                                                                        <label onclick="yesBtnGlasschutzClickedd()" id="yesBtnGlasschutz" class="inFormYesNoBtn documentFormBtn me-1" for="btnradio3abc">Ja</label>

                                                                        <input type="radio" class="btn-check" name="glass_protection" value="Nein" id="btnradio4abc" autocomplete="off">
                                                                        <label onclick="noBtnGlasschutzClickedd()" id="noBtnGlasschutz" class="inFormYesNoBtn documentFormBtn " for="btnradio4abc">Nein</label>
                                                                    </div>
                                                                </div>

                                                                <div class="input-div1 mb-2">
                                                                    <div class="">
                                                                            <span class="GrundversicherungSpans">
                                                                                + Parkschaden:
                                                                            </span>
                                                                    </div>

                                                                    <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                                                                        <input type="radio" class="btn-check showpdf" name="parking_damage" value="Ja" id="btnradio3abcd" autocomplete="off" checked>
                                                                        <label onclick="yesBtnParkschadenClickedd()" id="yesBtnParkschaden" class="inFormYesNoBtn documentFormBtn " for="btnradio3abcd">Ja</label>

                                                                        <input type="radio" class="btn-check" name="parking_damage" value="Nein" id="btnradio4abcd" autocomplete="off">
                                                                        <label onclick="noBtnParkschadenClickedd()" id="noBtnParkschaden" class="inFormYesNoBtn documentFormBtn " for="btnradio4abcd">Nein</label>
                                                                    </div>
                                                                    <script>

                                                                    </script>
                                                                </div>
                                                                <div class="input-div1 mb-2">
                                                                    <div class="">
                                                                            <span class="GrundversicherungSpans">
                                                                                + 24h Pannenhilfe:
                                                                            </span>
                                                                    </div>
                                                                    <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                                                                        <input type="radio" class="btn-check showpdf" name="hour_breakdown_assistance" value="Ja" id="btnradio3abcde" autocomplete="off" checked>
                                                                        <label id="yesBtnPannenhilfe" onclick="yesBtnPannenhilfeClickedd()" class="inFormYesNoBtn documentFormBtn " for="btnradio3abcde">Ja</label>

                                                                        <input type="radio" class="btn-check" name="hour_breakdown_assistance" value="Nein" id="btnradio4abcde" autocomplete="off">
                                                                        <label id="noBtnPannenhilfe" onclick="noBtnPannenhilfeClickedd()" class="inFormYesNoBtn documentFormBtn " for="btnradio4abcde">Nein</label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div>
                                                                <div class="">
                                                                        <span class="GrundversicherungSpans">
                                                                            Kommentar:
                                                                        </span>
                                                                </div>

                                                                <div class="col-12 col-6">
                                                                    <textarea class="GrundversicherungInput form-control showpdf" name="nuekommentar"></textarea>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row g-0 mt-3 justify-content-center" id="add_n" onclick="addanother_item_n()">
                                                    <div class="col-auto">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="48.694" viewBox="0 0 37.694 37.694" style="cursor:pointer;">
                                                            <g id="Group_621" data-name="Group 621" transform="translate(-663.236 -976.679)">
                                                                <g id="Group_550" data-name="Group 550" transform="translate(663.236 976.679)">
                                                                    <rect id="Rectangle_9" data-name="Rectangle 9" width="37.694" height="37.694" rx="18.847" fill="#2F60DC" />
                                                                    <g id="Group_42" data-name="Group 42" transform="translate(12.724 12.724)">
                                                                        <line id="Line_11" data-name="Line 11" y2="11.972" transform="translate(5.986 0)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="2" />
                                                                        <line id="Line_12" data-name="Line 12" x1="11.972" transform="translate(0 5.634)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="2" />
                                                                    </g>
                                                                </g>
                                                            </g>
                                                        </svg>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="py-4 py-md-4">
                                    <div class="pt-4 pt-md-0">
                                        <div class="row g-0 changeBtnAlign">
                                            <div class="col-4 col-md-3 col-lg-2 me-2">
                                                <button type="button" onclick="cancelBtnClickAuto()" class="cancelBtnKranken py-0 py-md-1 w-100">Abbrechen</button>
                                            </div>
                                            <div class="col-4 col-md-3 col-lg-2">
                                                <button type="button" onclick="continueToStep2Auto()" class="continueBtn py-0 py-md-1 w-100">Weiter</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="step2Auto" class="" style="display: none;">
                                <div class="">
                                    <div class="row g-0 justify-content-center">
                                        <div class="col-12 col-md-6 pe-0 pe-md-2">
                                            <div class="list-choice-title list-choice-title-step2 p-2 mt-4" onclick="openAutoDropdownStep222()">
                                                <div class="row g-0">
                                                    <div class="col my-auto">
                                                        <span>Autoversicherung</span>
                                                    </div>
                                                    <div class="col-auto">
                                                        <svg width="31" height="31" viewBox="0 0 31 31" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <circle cx="15.2314" cy="15.1093" r="15" fill="#2F60DC" />
                                                            <path d="M8.90704 13.1784C8.90681 13.0023 8.96701 12.8254 9.09028 12.6813C9.3644 12.3601 9.84662 12.322 10.1674 12.5968L15.0229 16.746L19.8676 12.5818C20.1876 12.306 20.67 12.3425 20.9449 12.6629C21.2187 12.9825 21.1832 13.4652 20.8635 13.7395L15.5222 18.3312C15.2364 18.5771 14.8142 18.5777 14.5278 18.3327L9.17449 13.7576C8.99823 13.6072 8.90732 13.3932 8.90704 13.1784Z" fill="white" />
                                                        </svg>
                                                    </div>
                                                </div>
                                            </div>
                                            <div id="Autoversicherung" class="Grundversicherung mt-4">
                                                <div class="p-4">
                                                    <div class="mb-3">
                                                        <div class="">
                                                            <div class="pe-3">
                                                                    <span class="GrundversicherungSpans">
                                                                        Gesellschaft:
                                                                    </span>
                                                            </div>
                                                            <select class="GrundversicherungInput form-control" aria-label="Default select example" name="society_PA">
                                                                <option value=""></option>
                                                                <option value="Helvetia">Helvetia</option>
                                                                <option value="Zurich">Zurich</option>
                                                                <option value="Axa">Axa</option>
                                                            </select>
                                                        </div>

                                                    </div>
                                                    <div class="mb-3">
                                                        <div class="">
                                                            <div class="pe-3">
                                                                    <span class="GrundversicherungSpans">
                                                                        Beginn Versicherung:
                                                                    </span>
                                                            </div>
                                                            <input class="GrundversicherungInput form-control" type="date" name="beginning_insurance_PA" id="" min="1900-01-01" max="9999-12-31">
                                                        </div>

                                                    </div>
                                                    <div class="mb-3">
                                                        <div class="">
                                                            <div class="pe-3">
                                                                    <span class="GrundversicherungSpans">
                                                                        Versicherung:
                                                                    </span>
                                                            </div>
                                                            <input class="GrundversicherungInput form-control" type="text" name="insurance_PA" id="">
                                                        </div>

                                                    </div>
                                                    <div class="mb-3">
                                                        <div class="">
                                                            <div class="pe-3">
                                                                    <span class="GrundversicherungSpans">
                                                                        Status:
                                                                    </span>
                                                            </div>
                                                            <select class="GrundversicherungInput form-control" aria-label="Default select example" name="status_PA">
                                                                <option selected value="Nicht Ausgewählt">Nicht Ausgewählt
                                                                </option>
                                                                <option value="Aufgenomen">Aufgenomen </option>
                                                                <option value="Offen">Offen</option>
                                                                <option value="Abgelehnt">Abgelehnt </option>
                                                                <option value="Zuruckgezogen">Zuruckgezogen</option>
                                                                <option value="Provisionert">Provisionert </option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="mb-3">
                                                        <div class="">
                                                            <div class="pe-3">
                                                                    <span class="GrundversicherungSpans">
                                                                        Letze Anpassung:
                                                                    </span>
                                                            </div>
                                                            <input class="GrundversicherungInput form-control" type="date"
{{--                                                                   name="last_adjustment_PA" --}}
                                                                   id="" min="1900-01-01" max="9999-12-31" readonly>
                                                        </div>
                                                    </div>
                                                    <div class="mb-3">
                                                        <div class="">
                                                            <div class="pe-3">
                                                                    <span class="GrundversicherungSpans">
                                                                        Gesamtprovision:
                                                                    </span>
                                                            </div>
                                                            <input class="GrundversicherungInput form-control" type="number" name="total_commisions_PA" id="">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="py-4" id="step2BtnDiv">
                                        <div class="row g-0 changeBtnAlign">
                                            <div class="col-4 col-md-3 col-lg-2 me-2">
                                                <button type="button" onclick="backBtnAuto()" class="cancelBtnKranken py-0 py-md-1 w-100">Zurück</button>
                                            </div>
                                            <div class="col-4 col-md-3 col-lg-2">
                                                <button onclick="toNextModal()" type="button" class="continueBtn py-0 py-md-1 w-100">Weiter</button>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div id="vorsorgeModal" class="documentsFormModals px-4">
                            <div class="" style="position: relative;">
                                <div class="cornerSvgDiv">
                                    <svg class="cornerSvg" viewBox="0 0 243 217" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g filter="url(#filter0_d_28_428)">
                                            <path d="M37.3623 125.778C42.7729 134.784 66.3703 137.598 74.8984 143.797C83.4265 149.996 87.4712 172.365 97.8185 174.815C108.166 177.264 124.613 159.747 135.204 158.073C145.796 156.4 155.994 152.687 165.216 147.146C174.439 141.605 182.506 134.344 188.956 125.778C195.406 117.213 200.113 107.51 202.809 97.224C205.505 86.938 206.136 76.2703 204.666 65.8299C203.197 55.3896 194.367 43.4368 188.956 34.4315L68.6647 34.4315C67.4261 34.4315 66.1893 34.3352 64.9657 34.1435C50.4656 31.8724 37.3623 43.0831 37.3623 57.76L37.3623 65.83L37.3623 125.778Z" fill="#EDF0F8"/>
                                        </g>
                                        <path d="M114 120C101.297 120 91.0009 109.639 91.0009 96.8575V78.3442C90.976 76.8318 91.4478 75.3528 92.3446 74.1325C93.2413 72.9122 94.5138 72.0175 95.9681 71.5848L99.2351 70.6366C102.402 69.705 105.48 68.4973 108.434 67.0276L110.919 65.7307C111.874 65.2503 112.93 65 114 65C115.07 65 116.126 65.2503 117.081 65.7307L119.659 67.0031C122.612 68.4821 125.69 69.698 128.857 70.6366L132.032 71.5848C133.486 72.0175 134.759 72.9122 135.655 74.1325C136.552 75.3528 137.024 76.8318 136.999 78.3442V96.8575C136.999 109.639 126.703 120 114 120ZM114 69.6411C113.65 69.6411 113.303 69.7191 112.987 69.8735L110.435 71.1459C107.262 72.7637 103.943 74.0811 100.523 75.0807L97.2571 76.0289C96.7615 76.1756 96.3293 76.4831 96.029 76.9026C95.7288 77.322 95.5777 77.8294 95.5998 78.3442V96.8575C95.5998 107.082 103.839 115.371 114 115.371C124.161 115.371 132.399 107.082 132.399 96.8575V78.3442C132.421 77.8296 132.27 77.3224 131.97 76.9029C131.67 76.4835 131.238 76.1759 130.743 76.0289L127.593 75.0807C124.154 74.0791 120.813 72.7698 117.611 71.1688L115.034 69.8735C114.713 69.7162 114.358 69.6366 114 69.6411ZM114 105.675C113.667 105.673 113.338 105.601 113.033 105.466C112.758 105.338 112.51 105.157 112.305 104.933C112.099 104.71 111.94 104.448 111.836 104.163C111.625 103.585 111.65 102.948 111.907 102.389L115.795 93.8495H108.643C108.245 93.8513 107.853 93.7497 107.506 93.5548C107.159 93.3598 106.868 93.0782 106.664 92.7377C106.462 92.3853 106.356 91.9865 106.356 91.5808C106.356 91.175 106.462 90.7763 106.664 90.4239L112.024 79.9866C112.161 79.7171 112.35 79.4774 112.581 79.2814C112.812 79.0853 113.079 78.9367 113.368 78.8443C113.656 78.7519 113.961 78.7174 114.263 78.7428C114.565 78.7683 114.859 78.8532 115.128 78.9926C116.259 79.5798 116.702 80.9776 116.118 82.1154L112.484 89.0582H119.383C120.166 89.0598 120.893 89.4604 121.316 90.1226C121.735 90.7802 121.795 91.6091 121.476 92.3217L116.118 104.148C115.962 104.586 115.676 104.967 115.298 105.24C114.92 105.513 114.468 105.664 114.002 105.675H114Z" fill="#14B971"/>
                                        <defs>
                                            <filter id="filter0_d_28_428" x="0.361328" y="0.850342" width="242.078" height="215.199" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                                                <feFlood flood-opacity="0" result="BackgroundImageFix"/>
                                                <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
                                                <feOffset dy="4"/>
                                                <feGaussianBlur stdDeviation="18.5"/>
                                                <feComposite in2="hardAlpha" operator="out"/>
                                                <feColorMatrix type="matrix" values="0 0 0 0 0.875 0 0 0 0 0.875 0 0 0 0 0.875 0 0 0 0.25 0"/>
                                                <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_28_428"/>
                                                <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_28_428" result="shape"/>
                                            </filter>
                                        </defs>
                                    </svg>
                                </div>
                                <div class="row g-0 justify-content-center pt-4">
                                    <div class="col-4 col-md-2">
                                        <div>
                                            <div class="text-center">
                                                <span id="step1Vorsorgee" class="activeStepTitle">Step 1</span>
                                            </div>
                                            <div class="mx-auto">
                                                <div id="step1LineVorsorge" class="blueLine mx-auto"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-4 col-4 col-md-2">
                                        <div>
                                            <div class="text-center">
                                                <span id="step2Vorsorgee" class="passiveStepTitle">Step 2</span>
                                            </div>
                                            <div>
                                                <div id="step2LineVorsorge" class="greyLine mx-auto"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="step1Vorsorge">
                                <div class="row g-0 justify-content-center">
                                    <div class="col-12 col-md-11 col-xl-10">
                                        <div class="Grundversicherung mt-4" style="display: block;">
                                            <div class="p-4">
                                                <div class=" my-2">
                                                        <span class="ZusatzversicherungTitle">
                                                            3a/3b Anfragen
                                                        </span>
                                                </div>
                                                <div class="row">
                                                    <div class="col-12 col-sm-12 col-md-6 col-lg-4 col-xl-4">
                                                        <div class="">
                                                            <div class="mb-2">
                                                                <div class="">
                                                                        <span class="GrundversicherungSpans">
                                                                            Nationalitat:
                                                                        </span>
                                                                </div>
                                                                <select onchange="hideNation()" class="w-100 form-control GrundversicherungInput" name="nationality_sachen" id="schweiz">
                                                                    <option value="Swiss">Swiss</option>
                                                                    <option value="Deutschland">Deutschland</option>
                                                                    <option value="Italien">Italien</option>
                                                                    <option value="French">French</option>
                                                                    <optgroup label="A">
                                                                        <option value="Afghanistan">Afghanistan</option>
                                                                        <option value="Ägypten">Ägypten</option>
                                                                        <option value="Åland">Åland</option>
                                                                        <option value="Albanien">Albanien</option>
                                                                        <option value="Algerien">Algerien</option>
                                                                        <option value="Amerikanisch-Samoa">
                                                                            Amerikanisch-Samoa
                                                                        </option>
                                                                        <option value="Amerikanische Jungferninseln">
                                                                            Amerikanische Jungferninseln
                                                                        </option>
                                                                        <option value="Andorra">Andorra</option>
                                                                        <option value="Angola">Angola</option>
                                                                        <option value="Anguilla">Anguilla</option>
                                                                        <option value="Antarktis">Antarktis</option>
                                                                        <option value="Antigua und Barbuda">Antigua und
                                                                            Barbuda
                                                                        </option>
                                                                        <option value="Äquatorialguinea">Äquatorialguinea
                                                                        </option>
                                                                        <option value="Argentinien">Argentinien</option>
                                                                        <option value="Armenien">Armenien</option>
                                                                        <option value="Aruba">Aruba</option>
                                                                        <option value="Ascension">Ascension</option>
                                                                        <option value="Aserbaidschan">Aserbaidschan</option>
                                                                        <option value="Äthiopien">Äthiopien</option>
                                                                        <option value="Australien">Australien</option>
                                                                    </optgroup>
                                                                    <optgroup label="B">
                                                                        <option value="Bahamas">Bahamas</option>
                                                                        <option value="Bahrain">Bahrain</option>
                                                                        <option value="Bangladesch">Bangladesch</option>
                                                                        <option value="Barbados">Barbados</option>
                                                                        <option value="Belarus">Belarus</option>
                                                                        <option value="Belgien">Belgien</option>
                                                                        <option value="Belize">Belize</option>
                                                                        <option value="Benin">Benin</option>
                                                                        <option value="Bermuda">Bermuda</option>
                                                                        <option value="Bhutan">Bhutan</option>
                                                                        <option value="Bolivien">Bolivien</option>
                                                                        <option value="Bosnien und Herzegowina">Bosnien und
                                                                            Herzegowina
                                                                        </option>
                                                                        <option value="Botswana">Botswana</option>
                                                                        <option value="Bouvetinsel">Bouvetinsel</option>
                                                                        <option value="Brasilien">Brasilien</option>
                                                                        <option value="Britische Jungferninseln">Britische
                                                                            Jungferninseln
                                                                        </option>
                                                                        <option value="Britisches Territorium im Indischen Ozean">
                                                                            Britisches Territorium im Indischen Ozean
                                                                        </option>
                                                                        <option value="Brunei Darussalam">Brunei
                                                                            Darussalam
                                                                        </option>
                                                                        <option value="Bulgarien">Bulgarien</option>
                                                                        <option value="Burkina Faso">Burkina Faso</option>
                                                                        <option value="Burundi">Burundi</option>
                                                                    </optgroup>
                                                                    <optgroup label="C">
                                                                        <option value="Ceuta, Melilla">Ceuta, Melilla
                                                                        </option>
                                                                        <option value="Chile">Chile</option>
                                                                        <option value="Volksrepublik China">Volksrepublik
                                                                            China
                                                                        </option>
                                                                        <option value="Clipperton">Clipperton</option>
                                                                        <option value="Cookinseln">Cookinseln</option>
                                                                        <option value="Costa Rica">Costa Rica</option>
                                                                        <option value="Côte d'Ivoire">Côte d'Ivoire</option>
                                                                    </optgroup>
                                                                    <optgroup label="D">
                                                                        <option value="Dänemark">Dänemark</option>
                                                                        <option value="Deutschland">Deutschland</option>
                                                                        <option value="Diego Garcia">Diego Garcia</option>
                                                                        <option value="Dominica">Dominica</option>
                                                                        <option value="Dominikanische Republik">
                                                                            Dominikanische Republik
                                                                        </option>
                                                                        <option value="Dschibuti">Dschibuti</option>
                                                                    </optgroup>
                                                                    <optgroup label="E">
                                                                        <option value="Ecuador">Ecuador</option>
                                                                        <option value="El Salvador">El Salvador</option>
                                                                        <option value="Eritrea">Eritrea</option>
                                                                        <option value="Estland">Estland</option>
                                                                    </optgroup>
                                                                    <optgroup label="F">
                                                                        <option value="Falklandinseln">Falklandinseln
                                                                        </option>
                                                                        <option value="Färöer">Färöer</option>
                                                                        <option value="Fidschi">Fidschi</option>
                                                                        <option value="Finnland">Finnland</option>
                                                                        <option value="Frankreich">Frankreich</option>
                                                                        <option value="Französisch-Guayana">
                                                                            Französisch-Guayana
                                                                        </option>
                                                                        <option value="Französisch-Polynesien">
                                                                            Französisch-Polynesien
                                                                        </option>
                                                                    </optgroup>
                                                                    <optgroup label="G">
                                                                        <option value="Gabun">Gabun</option>
                                                                        <option value="Gambia">Gambia</option>
                                                                        <option value="Georgien">Georgien</option>
                                                                        <option value="Ghana">Ghana</option>
                                                                        <option value="Gibraltar">Gibraltar</option>
                                                                        <option value="Grenada">Grenada</option>
                                                                        <option value="Griechenland">Griechenland</option>
                                                                        <option value="Grönland">Grönland</option>
                                                                        <option value="Großbritannien">Großbritannien
                                                                        </option>
                                                                        <option value="Guadeloupe">Guadeloupe</option>
                                                                        <option value="Guam">Guam</option>
                                                                        <option value="Guatemala">Guatemala</option>
                                                                        <option value="Guernsey (Kanalinsel)">Guernsey
                                                                            (Kanalinsel)
                                                                        </option>
                                                                        <option value="Guinea">Guinea</option>
                                                                        <option value="Guinea-Bissau">Guinea-Bissau</option>
                                                                        <option value="Guyana">Guyana</option>
                                                                    </optgroup>
                                                                    <optgroup label="H">
                                                                        <option value="Haiti">Haiti</option>
                                                                        <option value="Heard- und McDonald-Inseln">Heard-
                                                                            und McDonald-Inseln
                                                                        </option>
                                                                        <option value="Honduras">Honduras</option>
                                                                        <option value="Hongkong">Hongkong</option>
                                                                    </optgroup>
                                                                    <optgroup label="I">
                                                                        <option value="Indien">Indien</option>
                                                                        <option value="Indonesien">Indonesien</option>
                                                                        <option value="Insel Man">Insel Man</option>
                                                                        <option value="Irak">Irak</option>
                                                                        <option value="Iran">Iran</option>
                                                                        <option value="Irland">Irland</option>
                                                                        <option value="Island">Island</option>
                                                                        <option value="Israel">Israel</option>
                                                                        <option value="Italien">Italien</option>
                                                                    </optgroup>
                                                                    <optgroup label="J">
                                                                        <option value="Jamaika">Jamaika</option>
                                                                        <option value="Japan">Japan</option>
                                                                        <option value="Jemen">Jemen</option>
                                                                        <option value="Jersey (Kanalinsel)">Jersey
                                                                            (Kanalinsel)
                                                                        </option>
                                                                        <option value="Jordanien">Jordanien</option>
                                                                    </optgroup>
                                                                    <optgroup label="K">
                                                                        <option value="Kaimaninseln">Kaimaninseln</option>
                                                                        <option value="Kambodscha">Kambodscha</option>
                                                                        <option value="Kamerun">Kamerun</option>
                                                                        <option value="Kanada">Kanada</option>
                                                                        <option value="Kanarische Inseln">Kanarische
                                                                            Inseln
                                                                        </option>
                                                                        <option value="Kap Verde">Kap Verde</option>
                                                                        <option value="Kasachstan">Kasachstan</option>
                                                                        <option value="Katar">Katar</option>
                                                                        <option value="Kenia">Kenia</option>
                                                                        <option value="Kirgisistan">Kirgisistan</option>
                                                                        <option value="Kiribati">Kiribati</option>
                                                                        <option value="Kokosinseln">Kokosinseln</option>
                                                                        <option value="Kolumbien">Kolumbien</option>
                                                                        <option value="Komoren">Komoren</option>
                                                                        <option value="Demokratische Republik Kongo">
                                                                            Demokratische Republik Kongo
                                                                        </option>
                                                                        <option value="Demokratische Volksrepublik Korea (Nordkorea)">
                                                                            Demokratische Volksrepublik Korea (Nordkorea)
                                                                        </option>
                                                                        <option value="Republik Korea (Südkorea)">Republik
                                                                            Korea (Südkorea)
                                                                        </option>
                                                                        <option value="Kosovo">Kosovo</option>
                                                                        <option value="Kroatien">Kroatien</option>
                                                                        <option value="Kuba">Kuba</option>
                                                                        <option value="Kuwait">Kuwait</option>
                                                                    </optgroup>
                                                                    <optgroup label="L">
                                                                        <option value="Laos">Laos</option>
                                                                        <option value="Lesotho">Lesotho</option>
                                                                        <option value="Lettland">Lettland</option>
                                                                        <option value="Libanon">Libanon</option>
                                                                        <option value="Liberia">Liberia</option>
                                                                        <option value="Libyen">Libyen</option>
                                                                        <option value="Liechtenstein">Liechtenstein</option>
                                                                        <option value="Litauen">Litauen</option>
                                                                        <option value="Luxemburg">Luxemburg</option>
                                                                    </optgroup>
                                                                    <optgroup label="M">
                                                                        <option value="Macao">Macao</option>
                                                                        <option value="Madagaskar">Madagaskar</option>
                                                                        <option value="Malawi">Malawi</option>
                                                                        <option value="Malaysia">Malaysia</option>
                                                                        <option value="Malediven">Malediven</option>
                                                                        <option value="Mali">Mali</option>
                                                                        <option value="Malta">Malta</option>
                                                                        <option value="Marokko">Marokko</option>
                                                                        <option value="Marshallinseln">Marshallinseln
                                                                        </option>
                                                                        <option value="Martinique">Martinique</option>
                                                                        <option value="Mauretanien">Mauretanien</option>
                                                                        <option value="Mauritius">Mauritius</option>
                                                                        <option value="Mayotte">Mayotte</option>
                                                                        <option value="Mazedonien">Mazedonien</option>
                                                                        <option value="Mexiko">Mexiko</option>
                                                                        <option value="Mikronesien">Mikronesien</option>
                                                                        <option value="Moldawien (Republik Moldau)">
                                                                            Moldawien (Republik Moldau)
                                                                        </option>
                                                                        <option value="Monaco">Monaco</option>
                                                                        <option value="Mongolei">Mongolei</option>
                                                                        <option value="Montenegro">Montenegro</option>
                                                                        <option value="Montserrat">Montserrat</option>
                                                                        <option value="Mosambik">Mosambik</option>
                                                                        <option value="Myanmar">Myanmar (Burma)</option>
                                                                    </optgroup>
                                                                    <optgroup label="N">
                                                                        <option value="Namibia">Namibia</option>
                                                                        <option value="Nauru">Nauru</option>
                                                                        <option value="Nepal">Nepal</option>
                                                                        <option value="Neukaledonien">Neukaledonien</option>
                                                                        <option value="Neuseeland">Neuseeland</option>
                                                                        <option value="Nicaragua">Nicaragua</option>
                                                                        <option value="Niederlande">Niederlande</option>
                                                                        <option value="Niederländische Antillen">
                                                                            Niederländische Antillen
                                                                        </option>
                                                                        <option value="Niger">Niger</option>
                                                                        <option value="Nigeria">Nigeria</option>
                                                                        <option value="Niue">Niue</option>
                                                                        <option value="Nördliche Marianen">Nördliche
                                                                            Marianen
                                                                        </option>
                                                                        <option value="Norfolkinsel">Norfolkinsel</option>
                                                                        <option value="Norwegen">Norwegen</option>
                                                                    </optgroup>
                                                                    <optgroup label="O">
                                                                        <option value="Oman">Oman</option>
                                                                        <option value="Orbit">Orbit</option>
                                                                        <option value="Österreich">Österreich</option>
                                                                        <option value="Osttimor (Timor-Leste)">Osttimor
                                                                            (Timor-Leste)
                                                                        </option>
                                                                    </optgroup>
                                                                    <optgroup label="P">
                                                                        <option value="Pakistan">Pakistan</option>
                                                                        <option value="Palästinensische Autonomiegebiete">
                                                                            Palästinensische Autonomiegebiete
                                                                        </option>
                                                                        <option value="Palau">Palau</option>
                                                                        <option value="Panama">Panama</option>
                                                                        <option value="Papua-Neuguinea">Papua-Neuguinea
                                                                        </option>
                                                                        <option value="Paraguay">Paraguay</option>
                                                                        <option value="Peru">Peru</option>
                                                                        <option value="Philippinen">Philippinen</option>
                                                                        <option value="Pitcairninseln">Pitcairninseln
                                                                        </option>
                                                                        <option value="Polen">Polen</option>
                                                                        <option value="Portugal">Portugal</option>
                                                                        <option value="Puerto Rico">Puerto Rico</option>
                                                                    </optgroup>
                                                                    <optgroup label="R">
                                                                        <option value="Republik China (Taiwan)">Republik
                                                                            China (Taiwan)
                                                                        </option>
                                                                        <option value="Republik Kongo">Republik Kongo
                                                                        </option>
                                                                        <option value="Réunion">Réunion</option>
                                                                        <option value="Ruanda">Ruanda</option>
                                                                        <option value="Rumänien">Rumänien</option>
                                                                        <option value="Russische Föderation">Russische
                                                                            Föderation
                                                                        </option>
                                                                    </optgroup>
                                                                    <optgroup label="S">
                                                                        <option value="Saint-Barthélemy">Saint-Barthélemy
                                                                        </option>
                                                                        <option value="Saint-Martin">Saint-Martin</option>
                                                                        <option value="Salomonen">Salomonen</option>
                                                                        <option value="Sambia">Sambia</option>
                                                                        <option value="Samoa">Samoa</option>
                                                                        <option value="San Marino">San Marino</option>
                                                                        <option value="São Tomé und Príncipe">São Tomé und
                                                                            Príncipe
                                                                        </option>
                                                                        <option value="Saudi-Arabien">Saudi-Arabien</option>
                                                                        <option value="Schweden">Schweden</option>
                                                                        <option value="Schweiz">Schweiz</option>
                                                                        <option value="Senegal">Senegal</option>
                                                                        <option value="Serbien">Serbien</option>
                                                                        <option value="Seychellen">Seychellen</option>
                                                                        <option value="Sierra Leone">Sierra Leone</option>
                                                                        <option value="Simbabwe">Simbabwe</option>
                                                                        <option value="Singapur">Singapur</option>
                                                                        <option value="Slowakei">Slowakei</option>
                                                                        <option value="Slowenien">Slowenien</option>
                                                                        <option value="Somalia">Somalia</option>
                                                                        <option value="Spanien">Spanien</option>
                                                                        <option value="Sri Lanka">Sri Lanka</option>
                                                                        <option value="St. Helena">St. Helena</option>
                                                                        <option value="St. Kitts und Nevis">St. Kitts und
                                                                            Nevis
                                                                        </option>
                                                                        <option value="St. Lucia">St. Lucia</option>
                                                                        <option value="Saint-Pierre und Miquelon">
                                                                            Saint-Pierre und Miquelon
                                                                        </option>
                                                                        <option value="St. Vincent und die Grenadinen">St.
                                                                            Vincent und die Grenadinen
                                                                        </option>
                                                                        <option value="Südafrika">Südafrika</option>
                                                                        <option value="Sudan">Sudan</option>
                                                                        <option value="Südgeorgien und die Südlichen Sandwichinseln">
                                                                            Südgeorgien und die Südlichen Sandwichinseln
                                                                        </option>
                                                                        <option value="Suriname">Suriname</option>
                                                                        <option value="Svalbard und Jan Mayen">Svalbard und
                                                                            Jan Mayen
                                                                        </option>
                                                                        <option value="Swasiland">Swasiland</option>
                                                                        <option value="Syrien">Syrien</option>
                                                                    </optgroup>
                                                                    <optgroup label="T">
                                                                        <option value="Tadschikistan">Tadschikistan</option>
                                                                        <option value="Tansania">Tansania</option>
                                                                        <option value="Thailand">Thailand</option>
                                                                        <option value="Togo">Togo</option>
                                                                        <option value="Tokelau">Tokelau</option>
                                                                        <option value="Tonga">Tonga</option>
                                                                        <option value="Trinidad und Tobago">Trinidad und
                                                                            Tobago
                                                                        </option>
                                                                        <option value="Tristan da Cunha">Tristan da Cunha
                                                                        </option>
                                                                        <option value="Tschad">Tschad</option>
                                                                        <option value="Tschechische Republik">Tschechische
                                                                            Republik
                                                                        </option>
                                                                        <option value="Tunesien">Tunesien</option>
                                                                        <option value="Türkei">Türkei</option>
                                                                        <option value="Turkmenistan">Turkmenistan</option>
                                                                        <option value="Turks- und Caicosinseln">Turks- und
                                                                            Caicosinseln
                                                                        </option>
                                                                        <option value="Tuvalu">Tuvalu</option>
                                                                    </optgroup>
                                                                    <optgroup label="U">
                                                                        <option value="Uganda">Uganda</option>
                                                                        <option value="Ukraine">Ukraine</option>
                                                                        <option value="Ungarn">Ungarn</option>
                                                                        <option value="Uruguay">Uruguay</option>
                                                                        <option value="Usbekistan">Usbekistan</option>
                                                                    </optgroup>
                                                                    <optgroup label="V">
                                                                        <option value="Vanuatu">Vanuatu</option>
                                                                        <option value="Vatikanstadt">Vatikanstadt</option>
                                                                        <option value="Venezuela">Venezuela</option>
                                                                        <option value="Vereinigte Arabische Emirate">
                                                                            Vereinigte Arabische Emirate
                                                                        </option>
                                                                        <option value="Vereinigte Staaten von Amerika (USA)">
                                                                            Vereinigte Staaten von Amerika (USA)
                                                                        </option>
                                                                        <option value="Vereinigtes Königreich Großbritannien und Nordirland">
                                                                            Vereinigtes Königreich Großbritannien und
                                                                            Nordirland
                                                                        </option>
                                                                        <option value="Vietnam">Vietnam</option>
                                                                    </optgroup>
                                                                    <optgroup label="W">
                                                                        <option value="Wallis und Futuna">Wallis und
                                                                            Futuna
                                                                        </option>
                                                                        <option value="Weihnachtsinsel">Weihnachtsinsel
                                                                        </option>
                                                                        <option value="Westsahara">Westsahara</option>
                                                                    </optgroup>
                                                                    <optgroup label="Z">
                                                                        <option value="Zentralafrikanische Republik">
                                                                            Zentralafrikanische Republik
                                                                        </option>
                                                                        <option value="Zypern">Zypern</option>
                                                                    </optgroup>
                                                                </select>
                                                            </div>
                                                            <div class="mb-2" id="admin">
                                                                <div class="">
                                                                        <span class="GrundversicherungSpans">
                                                                            Aufenthaltsgenehmigung
                                                                        </span>
                                                                </div>
                                                                <select name="residence_permit" class="w-100 form-control GrundversicherungInput" aria-label="Default select example">
                                                                    <option selected></option>
                                                                    <option value="Aufenthaltsbewilligung (Ausweis B)">
                                                                        Aufenthaltsbewilligung (Ausweis B)
                                                                    </option>
                                                                    <option value="Niederlassungsausweis (Ausweis C)">
                                                                        Niederlassungsausweis (Ausweis C)
                                                                    </option>
                                                                    <option value="Aufenthaltsbewilligung mit Erwerbstätigkeit (AUsweis Ci)">
                                                                        Aufenthaltsbewilligung mit Erwerbstätigkeit (AUsweis
                                                                        Ci)
                                                                    </option>
                                                                    <option value="Grenzgängerbewilligung (Auweis G)">
                                                                        Grenzgängerbewilligung (Auweis G)
                                                                    </option>
                                                                    <option value=" Kurzaufenthaltsbewilligung (Ausweis L)">
                                                                        Kurzaufenthaltsbewilligung (Ausweis L)
                                                                    </option>
                                                                    <option value="Vorläufig aufenommene Ausländer (Ausweis F)">
                                                                        Vorläufig aufenommene Ausländer (Ausweis F)
                                                                    </option>
                                                                    <option value="Asylsuchende (Ausweis N)">Asylsuchende
                                                                        (Ausweis N)
                                                                    </option>
                                                                    <option value="Schutzbedürftige (Ausweis S)">
                                                                        Schutzbedürftige (Ausweis S)
                                                                    </option>
                                                                </select>
                                                            </div>
                                                            <div class=" mb-2">
                                                                <label for="telephone_nr" class="GrundversicherungSpans">Telefonnumer </label> <br>
                                                                <div class="input-group">
                                                                    <input name="telephone_nr" id="int-tel" type="number" class="w-100 form-control GrundversicherungInput">
                                                                </div>
                                                            </div>
                                                            <div class=" mb-2">
                                                                <div class="">
                                                                        <span class="GrundversicherungSpans" >
                                                                            Email
                                                                        </span>
                                                                </div>
                                                                <input name="email" class="w-100 form-control GrundversicherungInput" type="email" id="">
                                                            </div>
                                                            <div class=" mb-2">
                                                                <div class="">
                                                                        <span class="GrundversicherungSpans">
                                                                            Zivilstand
                                                                        </span>
                                                                </div>
                                                                <select name="zivilstand" class="w-100 form-control GrundversicherungInput" aria-label="Default select example">
                                                                    <option selected></option>
                                                                    <option value="ledig">Ledig</option>
                                                                    <option value="Verheiratet">Verheiratet</option>
                                                                    <option value="Verwitwet">Verwitwet</option>
                                                                    <option value="Geschieden">Geschieden</option>
                                                                    <option value="In eingetragener Partnerschaft">In
                                                                        eingetragener Partnerschaft
                                                                    </option>
                                                                    <option value="In aufgelöster Partnerschaft">In
                                                                        aufgelöster Partnerschaft
                                                                    </option>
                                                                </select>
                                                            </div>
                                                            <div class="">
                                                                <div class="">
                                                                        <span class="GrundversicherungSpans">
                                                                            Arbeitsverhältnis
                                                                        </span>
                                                                </div>
                                                                <select name="employment_relationship" class="w-100 form-control GrundversicherungInput" aria-label="Default select example">
                                                                    <option selected></option>
                                                                    <option value="Angestellt">Angestellt</option>
                                                                    <option value="Selbstständig ">Selbstständig</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-12 col-sm-12 col-md-6 col-lg-4 col-xl-4">
                                                        <div class="">
                                                            <div class="mb-2">
                                                                <div class="">
                                                                        <span class="GrundversicherungSpans">
                                                                            Beruf:
                                                                        </span>
                                                                </div>
                                                                <input name="job" class="w-100 form-control GrundversicherungInput" type="text" id="">
                                                            </div>
                                                            <div class="input-select-div mb-2">
                                                                <div class="">
                                                                        <span class="GrundversicherungSpans">
                                                                            Zahlungsrythmus:
                                                                        </span>
                                                                </div>
                                                                <select name="payment_frequency" class="w-100 form-control GrundversicherungInput" aria-label="Default select example">
                                                                    <option selected></option>
                                                                    <option value="Monatlich">Monatlich</option>
                                                                    <option value="Quartalsweise">Quartalsweise</option>
                                                                    <option value="Jährlich">Jährlich</option>
                                                                </select>
                                                            </div>
                                                            <!-- input groupd here asap -->
                                                            <div class="mb-2">
                                                                <div class="">
                                                                        <span class="GrundversicherungSpans">
                                                                            Betrag pro Monat:
                                                                        </span>
                                                                </div>
                                                                <input name="amount_per_month" class="w-100 form-control GrundversicherungInput" type="text" id="">
                                                            </div>
                                                            <div class="mb-2">
                                                                <div class="">
                                                                        <span class="GrundversicherungSpans">
                                                                            Anteli Garantie/Fond:
                                                                        </span>
                                                                </div>
                                                                <select name="share_guarantee" class="w-100 form-control GrundversicherungInput" aria-label="Default select example">
                                                                    <option selected></option>
                                                                    <option value="10/90">10/90</option>
                                                                    <option value="20/80">20/80</option>
                                                                    <option value="30/70">30/70</option>
                                                                    <option value="40/60">40/60</option>
                                                                    <option value="50/50">50/50</option>
                                                                    <option value="60/40">60/40</option>
                                                                    <option value="70/30">70/30</option>
                                                                    <option value="80/20">80/20</option>
                                                                    <option value="90/10">90/10</option>
                                                                </select>
                                                            </div>
                                                            <div class="mb-2">
                                                                <div class="">
                                                                        <span class="GrundversicherungSpans">
                                                                            Vertragsbeginn ab:
                                                                        </span>
                                                                </div>
                                                                <select name="start_of_contract" class="w-100 form-control GrundversicherungInput" aria-label="Default select example">
                                                                    <option value="Januar">Januar</option>
                                                                    <option value="Februar">Februar</option>
                                                                    <option value="März">März</option>
                                                                    <option value="April">April</option>
                                                                    <option value="Mai">Mai</option>
                                                                    <option value="Juni">Juni</option>
                                                                    <option value="Juli">Juli</option>
                                                                    <option value="August">August</option>
                                                                    <option value="September">September</option>
                                                                    <option value="Oktober">Oktober</option>
                                                                    <option value="November">November</option>
                                                                    <option value="Dezember">Dezember</option>
                                                                </select>
                                                            </div>
                                                            <div class="group-button-div">
                                                                <div class="">
                                                                        <span class="GrundversicherungSpans">
                                                                            Pramienbefreiung:
                                                                        </span>
                                                                </div>
                                                                <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                                                                    <input type="radio" class="btn-check showpdf" name="premium_exemption" value="Ja" id="btnradio3" autocomplete="off" checked>
                                                                    <label id="yesBtnPramienbefreiung" onclick="yesBtnPramienbefreiungClicked()" class="inFormYesNoBtn documentFormBtn px-0 me-1" for="btnradio3">Ja</label>

                                                                    <input type="radio" class="btn-check" name="premium_exemption" value="Nein" id="btnradio4" autocomplete="off">
                                                                    <label id="noBtnPramienbefreiung" onclick="noBtnPramienbefreiungClicked()" class="inFormYesNoBtn documentFormBtn px-0" for="btnradio4">Nein</label>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-12 col-sm-12 col-md-6 col-lg-4 col-xl-4">
                                                        <div class="">
                                                            <div class="group-button-div mb-2">
                                                                <div class="">
                                                                        <span class="GrundversicherungSpans">
                                                                            EU - Rente:
                                                                        </span>
                                                                </div>
                                                                <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                                                                    <input type="radio" class="btn-check showpdf" name="eu_pension" value="Ja" id="btnradio5" autocomplete="off" checked>
                                                                    <label onclick="yesBtnRenteClicked()" id="yesBtnRente" class="inFormYesNoBtn documentFormBtn px-0 me-1" for="btnradio5" onclick="showel(this)">Ja</label>

                                                                    <input type="radio" class="btn-check" name="eu_pension" value="Nein" id="btnradio6" autocomplete="off">
                                                                    <label onclick="noBtnRenteClicked()" id="noBtnRente" class="inFormYesNoBtn documentFormBtn px-0" for="btnradio6">Nein</label>
                                                                </div>

                                                            </div>
                                                            <div class="group-button-div mb-2">
                                                                <div class="">
                                                                        <span class="GrundversicherungSpans">
                                                                            Todesfalkapital:
                                                                        </span>
                                                                </div>
                                                                <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                                                                    <input type="radio" class="btn-check showpdf" name="death_benefit" value="Ja" id="btnradio7" autocomplete="off" checked>
                                                                    <label onclick="yesBtnTodesfalkapitalClicked()" id="yesBtnTodesfalkapital" class="inFormYesNoBtn documentFormBtn px-0 me-1" for="btnradio7">Ja</label>

                                                                    <input type="radio" class="btn-check" name="death_benefit" value="Nein" id="btnradio8" autocomplete="off">
                                                                    <label onclick="noBtnTodesfalkapitalClicked()" id="noBtnTodesfalkapital" class="inFormYesNoBtn documentFormBtn px-0" for="btnradio8">Nein</label>
                                                                </div>

                                                            </div>
                                                            <div class="mb-2">
                                                                <div class="">
                                                                        <span class="GrundversicherungSpans">
                                                                            Raucher:
                                                                        </span>
                                                                </div>
                                                                <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                                                                    <input type="radio" class="btn-check showpdf" name="smoker" value="Ja" id="btnradio9" autocomplete="off" checked>
                                                                    <label onclick="yesBtnRaucherClicked()" id="yesBtnRaucher" class="inFormYesNoBtn documentFormBtn px-0 me-1" for="btnradio9">Ja</label>

                                                                    <input type="radio" class="btn-check" name="smoker" value="Nein" id="btnradio10" autocomplete="off">
                                                                    <label onclick="noBtnRaucherClicked()" id="noBtnRaucher" class="inFormYesNoBtn documentFormBtn px-0" for="btnradio10">Nein</label>
                                                                </div>

                                                            </div>
                                                            <div class="mb-2">
                                                                <label for="exampleFormControlTextarea2" class="GrundversicherungSpans">Gewünschte
                                                                    Gesellschaften:</label>
                                                                <textarea name="desired" class="w-100 form-control GrundversicherungInput" id="exampleFormControlTextarea2" rows="3"></textarea>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="py-4 py-md-4">
                                    <div class="pt-4 pt-md-0">
                                        <div class="row g-0 changeBtnAlign">
                                            <div class="col-4 col-md-3 col-lg-2 me-2">
                                                <button type="button" onclick="cancelBtnClickVorsorge()" class="cancelBtnKranken py-0 py-md-1 w-100">Abbrechen</button>
                                            </div>
                                            <div class="col-4 col-md-3 col-lg-2">
                                                <button type="button" onclick="continueToStep2Vorsorge()" class="continueBtn py-0 py-md-1 w-100">Weiter</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="step2Vorsorge" class="" style="display: none;">
                                <div class="">
                                    <div class="row g-0 justify-content-center">
                                        <div class="col-12 col-md-6 pe-0 pe-md-2">
                                            <div class="list-choice-title list-choice-title-step2 p-2 mt-4" onclick="openVorsorgeDropdownStep2()">
                                                <div class="row g-0">
                                                    <div class="col my-auto">
                                                        <span>Vorsorge</span>
                                                    </div>
                                                    <div class="col-auto">
                                                        <svg width="31" height="31" viewBox="0 0 31 31" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <circle cx="15.2314" cy="15.1093" r="15" fill="#2F60DC" />
                                                            <path d="M8.90704 13.1784C8.90681 13.0023 8.96701 12.8254 9.09028 12.6813C9.3644 12.3601 9.84662 12.322 10.1674 12.5968L15.0229 16.746L19.8676 12.5818C20.1876 12.306 20.67 12.3425 20.9449 12.6629C21.2187 12.9825 21.1832 13.4652 20.8635 13.7395L15.5222 18.3312C15.2364 18.5771 14.8142 18.5777 14.5278 18.3327L9.17449 13.7576C8.99823 13.6072 8.90732 13.3932 8.90704 13.1784Z" fill="white" />
                                                        </svg>
                                                    </div>
                                                </div>
                                            </div>
                                            <div id="Vorsorge" class="Grundversicherung mt-4">
                                                <div class="p-4">
                                                    <div class="mb-3">
                                                        <div class="justify-content-between">
                                                            <div class="pe-3">
                                                                    <span class="GrundversicherungSpans" >
                                                                        Abschlussdatum:
                                                                    </span>
                                                            </div>
                                                            <input class=" w-100 form-control GrundversicherungInput" type="date" name="graduation_date_PV" id="" min="1900-01-01" max="9999-12-31">
                                                        </div>

                                                    </div>
                                                    <div class="mb-3">
                                                        <div class="justify-content-between">
                                                            <div class="pe-3">
                                                                    <span class="GrundversicherungSpans">
                                                                        Beginn:
                                                                    </span>
                                                            </div>
                                                            <input class=" w-100 form-control GrundversicherungInput" type="date" name="begin_PV" id="" min="1900-01-01" max="9999-12-31">
                                                        </div>

                                                    </div>
                                                    <div class="mb-3">
                                                        <div class="  justify-content-between">
                                                            <div class="pe-3">
                                                                    <span class="GrundversicherungSpans">
                                                                        Gesellschaft:
                                                                    </span>
                                                            </div>
                                                            <select class="w-100 form-control GrundversicherungInput" aria-label="Default select example" name="society_PV">
                                                                <option value=""></option>
                                                                <option value="Helvetia">Helvetia</option>
                                                                <option value="Pax">Pax</option>
                                                                <option value="Axa">Axa</option>
                                                                <option value="GM">GM</option>
                                                                <option value="Zurich">Zurich</option>
                                                            </select>
                                                        </div>

                                                    </div>
                                                    <div class="mb-3">
                                                        <div class="  justify-content-between">
                                                            <div class="pe-3">
                                                                    <span class="GrundversicherungSpans">
                                                                        Pramie
                                                                    </span>
                                                            </div>
                                                            <input class=" w-100 form-control GrundversicherungInput" type="text" name="pramie_PV" id="">
                                                        </div>

                                                    </div>
                                                    <div class="mb-3">
                                                        <div class="  justify-content-between">
                                                            <div class="pe-3">
                                                                    <span class="GrundversicherungSpans">
                                                                        Zahlungsrythmus:
                                                                    </span>
                                                            </div>
                                                            <input class=" w-100 form-control GrundversicherungInput" type="text" name="payment_rythm_PV" id="">
                                                        </div>

                                                    </div>
                                                    <div class="mb-3">
                                                        <div class="  justify-content-between">
                                                            <div class="pe-3">
                                                                    <span class="ZusatzversicherungTitle">
                                                                        Lauftzeit:
                                                                    </span>
                                                            </div>
                                                            <label for="from2">From</label>
                                                            <input class=" w-100 form-control GrundversicherungInput" type="date" name="duration_from_PV" id="from2" min="1900-01-01" max="9999-12-31">
                                                            <label for="to2">To</label>
                                                            <input class=" w-100 form-control GrundversicherungInput" type="date" name="duration_to_PV" id="to2" min="1900-01-01" max="9999-12-31">
                                                        </div>
                                                    </div>
                                                    <div class="mb-3">
                                                        <div class="  justify-content-between">
                                                            <div class="pe-3">
                                                                    <span class="GrundversicherungSpans">
                                                                        Produktion:
                                                                    </span>
                                                            </div>
                                                            <input class=" w-100 form-control GrundversicherungInput" type="text" name="production_PV" id="">
                                                        </div>
                                                    </div>
                                                    <div class="mb-3">
                                                        <div class="  justify-content-between">
                                                            <div class="pe-3">
                                                                    <span class="GrundversicherungSpans">
                                                                        Status:
                                                                    </span>
                                                            </div>
                                                            <select class="w-100 form-control GrundversicherungInput" aria-label="Default select example" name="status_PV">
                                                                <option selected value="Nicht Ausgewählt">Nicht Ausgewählt
                                                                </option>
                                                                <option value="Aufgenomen">Aufgenomen </option>
                                                                <option value="Offen">Offen</option>
                                                                <option value="Abgelehnt">Abgelehnt </option>
                                                                <option value="Zuruckgezogen">Zuruckgezogen</option>
                                                                <option value="Provisionert">Provisionert </option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="mb-3">
                                                        <div class="  justify-content-between">
                                                            <div class="pe-3">
                                                                    <span class="GrundversicherungSpans">
                                                                        Letze Anpassung:
                                                                    </span>
                                                            </div>
                                                            <input class=" w-100 form-control GrundversicherungInput" type="date"
{{--                                                                   name="last_adjustment_PV"--}}
                                                                   id="" min="1900-01-01" max="9999-12-31" readonly>
                                                        </div>
                                                    </div>
                                                    <div class="mb-3">
                                                        <div class="  justify-content-between">
                                                            <div class="pe-3">
                                                                    <span class="GrundversicherungSpans">
                                                                        Gesamtprovision:
                                                                    </span>
                                                            </div>
                                                            <input class=" w-100 form-control GrundversicherungInput" type="number" name="total_commisions_PV" id="">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="py-4" id="step2BtnDiv">
                                        <div class="row g-0 changeBtnAlign">
                                            <div class="col-4 col-md-3 col-lg-2 me-2">
                                                <button type="button" onclick="backBtnVorsorge()" class="cancelBtnKranken py-0 py-md-1 w-100">Zurück</button>
                                            </div>
                                            <div class="col-4 col-md-3 col-lg-2">
                                                <button type="button" onclick="toNextModal2()" class="continueBtn py-0 py-md-1 w-100">Weiter</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div id="sachenModal" class="documentsFormModals px-4">
                            <div class="" style="position: relative;">
                                <div class="cornerSvgDiv">
                                    <svg class="cornerSvg" viewBox="0 0 243 217" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g filter="url(#filter0_d_28_428)">
                                            <path d="M37.3623 125.778C42.7729 134.784 66.3703 137.598 74.8984 143.797C83.4265 149.996 87.4712 172.365 97.8185 174.815C108.166 177.264 124.613 159.747 135.204 158.073C145.796 156.4 155.994 152.687 165.216 147.146C174.439 141.605 182.506 134.344 188.956 125.778C195.406 117.213 200.113 107.51 202.809 97.224C205.505 86.938 206.136 76.2703 204.666 65.8299C203.197 55.3896 194.367 43.4368 188.956 34.4315L68.6647 34.4315C67.4261 34.4315 66.1893 34.3352 64.9657 34.1435C50.4656 31.8724 37.3623 43.0831 37.3623 57.76L37.3623 65.83L37.3623 125.778Z" fill="#EDF0F8"/>
                                        </g>
                                        <path d="M136 84C140.963 84 145 87.813 145 92.5C145 97.1868 140.963 101 136 101C131.037 101 127 97.1868 127 92.5C127 87.813 131.037 84 136 84ZM136 87.9726C133.357 87.9726 131.206 90.0034 131.206 92.4998C131.206 94.9958 133.357 97.0266 136 97.0266C138.643 97.0266 140.794 94.9958 140.794 92.4998C140.794 90.0037 138.643 87.9726 136 87.9726Z" fill="#5288F5"/>
                                        <path d="M91.4999 84C96.187 84 100 87.813 100 92.5C100 97.1868 96.1867 101 91.4999 101C86.813 101 83 97.1868 83 92.5C83 87.813 86.813 84 91.4999 84ZM91.4999 87.9726C89.0035 87.9726 86.9727 90.0034 86.9727 92.4998C86.9727 94.9958 89.0035 97.0266 91.4999 97.0266C93.9962 97.0266 96.0271 94.9958 96.0271 92.4998C96.0271 90.0037 93.9962 87.9726 91.4999 87.9726Z" fill="#5288F5"/>
                                        <path d="M113.5 84C118.187 84 122 87.813 122 92.5C122 97.1868 118.187 101 113.5 101C108.813 101 105 97.1868 105 92.5C105 87.813 108.813 84 113.5 84ZM113.5 87.9726C111.004 87.9726 108.973 90.0034 108.973 92.4998C108.973 94.9958 111.004 97.0266 113.5 97.0266C115.996 97.0266 118.027 94.9958 118.027 92.4998C118.027 90.0037 115.996 87.9726 113.5 87.9726Z" fill="#5288F5"/>
                                        <defs>
                                            <filter id="filter0_d_28_428" x="0.361328" y="0.850342" width="242.078" height="215.199" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                                                <feFlood flood-opacity="0" result="BackgroundImageFix"/>
                                                <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
                                                <feOffset dy="4"/>
                                                <feGaussianBlur stdDeviation="18.5"/>
                                                <feComposite in2="hardAlpha" operator="out"/>
                                                <feColorMatrix type="matrix" values="0 0 0 0 0.875 0 0 0 0 0.875 0 0 0 0 0.875 0 0 0 0.25 0"/>
                                                <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_28_428"/>
                                                <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_28_428" result="shape"/>
                                            </filter>
                                        </defs>
                                    </svg>


                                </div>
                                <div class="row g-0 justify-content-center pt-4">
                                    <div class="col-4 col-md-2">
                                        <div>
                                            <div class="text-center">
                                                <span id="step1Sachenn" class="activeStepTitle">Step 1</span>
                                            </div>
                                            <div class="mx-auto">
                                                <div id="step1LineSachen" class="blueLine mx-auto"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-4 col-4 col-md-2">
                                        <div>
                                            <div class="text-center">
                                                <span id="step2Sachenn" class="passiveStepTitle">Step 2</span>
                                            </div>
                                            <div>
                                                <div id="step2LineSachen" class="greyLine mx-auto"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="step1Sachen">
                                <div class="row g-0 justify-content-center pt-0 pt-md-4">
                                    <div class="row g-0">
                                        <div class="col-12 col-md-6 col-lg-6 col-xl-4 pe-0 pe-md-2">
                                            <div class="list-choice-title list-choice-title-step2 p-2 mt-4" onclick="openSachenDropdownStep2()">
                                                <div class="row g-0">
                                                    <div class="col my-auto">
                                                        <span>Geegnofferte?</span>
                                                    </div>
                                                    <div class="col-auto">
                                                        <svg width="31" height="31" viewBox="0 0 31 31" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <circle cx="15.2314" cy="15.1093" r="15" fill="#2F60DC" />
                                                            <path d="M8.90704 13.1784C8.90681 13.0023 8.96701 12.8254 9.09028 12.6813C9.3644 12.3601 9.84662 12.322 10.1674 12.5968L15.0229 16.746L19.8676 12.5818C20.1876 12.306 20.67 12.3425 20.9449 12.6629C21.2187 12.9825 21.1832 13.4652 20.8635 13.7395L15.5222 18.3312C15.2364 18.5771 14.8142 18.5777 14.5278 18.3327L9.17449 13.7576C8.99823 13.6072 8.90732 13.3932 8.90704 13.1784Z" fill="white" />
                                                        </svg>
                                                    </div>
                                                </div>
                                            </div>
                                            <div id="Gegenofertensachen" class="Grundversicherung mt-4">
                                                <div class="p-4">
                                                    <div class="">
                                                        <div class="GrundversicherungSpans">
                                                                <span class="GrundversicherungSpans">
                                                                    Police Hochladen:
                                                                </span>
                                                        </div>
                                                        <div class="">
                                                            <div class="inputFileBG w-100 mt-2">
                                                                <div class="my-2 p-4 text-center">
                                                                    <label for="sachenUpload">
                                                                        <div class="mb-2">
                                                                            <svg class="uploadSvgStyle" viewBox="0 0 23 23" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                                <path d="M21 14.6667V18.8889C21 19.4488 20.7776 19.9858 20.3817 20.3817C19.9858 20.7776 19.4488 21 18.8889 21H4.11111C3.55121 21 3.01424 20.7776 2.61833 20.3817C2.22242 19.9858 2 19.4488 2 18.8889V14.6667" stroke="#658BEB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                                                                <path d="M16.7777 7.27778L11.4999 2L6.22217 7.27778" stroke="#658BEB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                                                                <path d="M11.5 2V14.6667" stroke="#658BEB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                                                            </svg>
                                                                        </div>
                                                                        <div>
                                                                            <span class="fileInputSecondTitle">Durchsuche</span>
                                                                        </div>
                                                                        <div>
                                                                            <span class="fileInputFirstTitle">Laden Sie hier Ihre Dateien hoch</span>
                                                                        </div>
                                                                    </label>
                                                                    <input type="file" id="sachenUpload"
                                                                           name="upload_police__" hidden
                                                                           class="svg-div w-100 border-0  g-0"
                                                                           onchange="upload(this);">
                                                                    <input type="text"
                                                                           class="form-control text-center"
                                                                           id="sachenUploadc" disabled
                                                                           style="background:transparent; border:none;">
                                                                </div>
                                                            </div>

                                                        </div>
                                                        <div class="pt-3">
                                                            <div class="row g-0">
                                                                <div class="col-6 g-0 my-auto">
                                                                    <div class="GrundversicherungSpans">
                                                                            <span class="">
                                                                                Vergleichsart:
                                                                            </span>
                                                                    </div>
                                                                </div>
                                                                <div class="col g-0 d-flex justify-content-end">
                                                                    <div class="text-end">
                                                                        <select name="Hvergleichsart_select" class="form-control GrundversicherungInput" id="">
                                                                            <option selected>Auswählen</option>
                                                                            <option value="1:0 Aktualisierung">1:0
                                                                                Aktualisierung
                                                                            </option>
                                                                            <option value="0:1 Downgraden">0:1
                                                                                Downgraden
                                                                            </option>
                                                                            <option value="1:1 Das Gleiche">1:1 Das
                                                                                Gleiche
                                                                            </option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="">
                                                            <div class="mb-3 mt-3">
                                                                <label for="exampleFormControlTextarea2" class="GrundversicherungSpans">Kommentar</label>
                                                                <textarea name="comment__" class="form-control showpdf GrundversicherungInput" id="exampleFormControlTextarea" rows="3"></textarea>
                                                            </div>
                                                        </div>
                                                        @if(!Auth::user()->hasRole('fs'))
                                                            <div class="text-start GrundversicherungSpans">
                                                                Neue Offer
                                                                <div class="inputFileBG w-100 mt-2">
                                                                    <div class="my-2 p-4 text-center">
                                                                        <label for="sachenUploadd">
                                                                            <div class="mb-2">
                                                                                <svg class="uploadSvgStyle" viewBox="0 0 23 23" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M21 14.6667V18.8889C21 19.4488 20.7776 19.9858 20.3817 20.3817C19.9858 20.7776 19.4488 21 18.8889 21H4.11111C3.55121 21 3.01424 20.7776 2.61833 20.3817C2.22242 19.9858 2 19.4488 2 18.8889V14.6667" stroke="#658BEB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                                                                    <path d="M16.7777 7.27778L11.4999 2L6.22217 7.27778" stroke="#658BEB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                                                                    <path d="M11.5 2V14.6667" stroke="#658BEB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                                                                </svg>
                                                                            </div>
                                                                            <div>
                                                                                <span class="fileInputSecondTitle">Durchsuche</span>
                                                                            </div>
                                                                            <div>
                                                                                <span class="fileInputFirstTitle">Laden Sie hier Ihre Dateien hoch</span>
                                                                            </div>
                                                                        </label>
                                                                        <input type="file" id="sachenUploadd"
                                                                               name="newoffer" hidden
                                                                               class="svg-div w-100 border-0  g-0"
                                                                               onchange="upload(this);">
                                                                        <input type="text"
                                                                               class="form-control text-center"
                                                                               id="sachenUploaddc" disabled
                                                                               style="background:transparent; border:none;">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        @endif
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-6 col-lg-6 col-xl-4 ps-0 ps-md-0">
                                            <div class="list-choice-title list-choice-title-step2 p-2 mt-4" onclick="openSachenDropdownStep22()">
                                                <div class="row g-0">
                                                    <div class="col my-auto">
                                                        <span>Neues Sachversicherung</span>
                                                    </div>
                                                    <div class="col-auto">
                                                        <svg width="31" height="31" viewBox="0 0 31 31" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <circle cx="15.2314" cy="15.1093" r="15" fill="#2F60DC" />
                                                            <path d="M8.90704 13.1784C8.90681 13.0023 8.96701 12.8254 9.09028 12.6813C9.3644 12.3601 9.84662 12.322 10.1674 12.5968L15.0229 16.746L19.8676 12.5818C20.1876 12.306 20.67 12.3425 20.9449 12.6629C21.2187 12.9825 21.1832 13.4652 20.8635 13.7395L15.5222 18.3312C15.2364 18.5771 14.8142 18.5777 14.5278 18.3327L9.17449 13.7576C8.99823 13.6072 8.90732 13.3932 8.90704 13.1784Z" fill="white" />
                                                        </svg>
                                                    </div>
                                                </div>

                                            </div>
                                            <div class="Zusatzversicherung mt-4" id="NeuesSachen">
                                                <div class="p-4">
                                                    <div class="">
                                                        <div class="row mx-0">
                                                            <div class="col-6 d-flex g-0 my-auto">
                                                                <div class="text-nowrap">
                                                                        <span class="ZusatzversicherungTitle">
                                                                            Neue Anfarge
                                                                        </span>
                                                                </div>
                                                            </div>
                                                            <div class="col g-0 d-flex justify-content-end">
                                                                <div class="text-end ">
                                                                    <select name="noname" class="form-control GrundversicherungInput " id="">
                                                                        <option selected>Auswählen</option>
                                                                        <option value="1">Ja</option>
                                                                        <option value="2">Nein</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mt-2">
                                                            <div class="input-select-div pb-3">
                                                                <div class="GrundversicherungSpans">
                                                                        <span class="GrundversicherungSpans" >
                                                                            Anzahl Personen
                                                                        </span>
                                                                </div>
                                                                <select name="number_of_people" class="form-select w-100 showpdf GrundversicherungInput" aria-label="Default select example">
                                                                    <option selected></option>
                                                                    <option value="1">1</option>
                                                                    <option value="2">2</option>
                                                                    <option value="3">3</option>
                                                                    <option value="4">4</option>
                                                                    <option value="5">5</option>
                                                                    <option value="6">6</option>
                                                                    <option value="7">7</option>
                                                                    <option value="8">8</option>
                                                                    <option value="9">9</option>
                                                                    <option value="10">10</option>
                                                                    <option value="11">11</option>
                                                                    <option value="12">12</option>
                                                                    <option value="13">13</option>
                                                                    <option value="14">14</option>
                                                                    <option value="15">15</option>
                                                                    <option value="16">16</option>
                                                                    <option value="17">17</option>
                                                                    <option value="18">18</option>
                                                                    <option value="19">19</option>
                                                                    <option value="20">20</option>

                                                                </select>
                                                            </div>
                                                            <div class="input-select-div pb-3">
                                                                <div class="GrundversicherungSpans">
                                                                        <span class="GrundversicherungSpans" >
                                                                            Anzahl Zimmer
                                                                        </span>
                                                                </div>
                                                                <select name="number_of_rooms" class="form-select w-100 showpdf GrundversicherungInput" aria-label="Default select example">
                                                                    <option selected></option>
                                                                    <option value="1">1</option>
                                                                    <option value="2">2</option>
                                                                    <option value="3">3</option>
                                                                    <option value="4">4</option>
                                                                    <option value="5">5</option>
                                                                    <option value="6">6</option>
                                                                    <option value="7">7</option>
                                                                    <option value="8">8</option>
                                                                    <option value="9">9</option>
                                                                    <option value="10">10</option>
                                                                    <option value="11">11</option>
                                                                    <option value="12">12</option>
                                                                    <option value="13">13</option>
                                                                    <option value="14">14</option>
                                                                    <option value="15">15</option>
                                                                    <option value="16">16</option>
                                                                    <option value="17">17</option>
                                                                    <option value="18">18</option>
                                                                    <option value="19">19</option>
                                                                    <option value="20">20</option>
                                                                </select>
                                                            </div>
                                                            <div class="pb-3">
                                                                <div class="GrundversicherungSpans">
                                                                        <span class="" >
                                                                            Versicherungsumme
                                                                        </span>
                                                                </div>
                                                                <input name="sum_insured" class="py-1 w-100 showpdf form-contorl GrundversicherungInput" type="text" id="">
                                                            </div>
                                                            <div class="mb-3">
                                                                <label for="exampleFormControlTextarea4" class="GrundversicherungSpans" >
                                                                    Gewünschte Zusatzdeckung:</label>
                                                                <textarea name="desired_additional_coverage" class="form-control showpdf GrundversicherungInput" id="exampleFormControlTextarea4" rows="3">

                                                                </textarea>
                                                            </div>
                                                            <div class="input-select-div">
                                                                <div class="GrundversicherungSpans">
                                                                        <span class="GrundversicherungSpans" >
                                                                            Pricathaftpflicht?
                                                                        </span>
                                                                </div>
                                                                <select name="personal_liability" class="form-select w-100 showpdf GrundversicherungInput" aria-label="Default select example">
                                                                    <option selected></option>
                                                                    <option value="Ja">Ja</option>
                                                                    <option value="Nein">Nein</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-6 col-lg-6 col-xl-4 ps-0 pe-0 pe-md-2 pe-xl-0 ps-md-0 ps-xl-2">
                                            <div class="list-choice-title list-choice-title-step2 p-2 mt-4" onclick="openSachenDropdownStep222()">
                                                <div class="row g-0">
                                                    <div class="col my-auto ">
                                                        <span>Gesellschaft wahlen?</span>
                                                    </div>
                                                    <div class="col-auto">
                                                        <svg width="31" height="31" viewBox="0 0 31 31" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <circle cx="15.2314" cy="15.1093" r="15" fill="#2F60DC" />
                                                            <path d="M8.90704 13.1784C8.90681 13.0023 8.96701 12.8254 9.09028 12.6813C9.3644 12.3601 9.84662 12.322 10.1674 12.5968L15.0229 16.746L19.8676 12.5818C20.1876 12.306 20.67 12.3425 20.9449 12.6629C21.2187 12.9825 21.1832 13.4652 20.8635 13.7395L15.5222 18.3312C15.2364 18.5771 14.8142 18.5777 14.5278 18.3327L9.17449 13.7576C8.99823 13.6072 8.90732 13.3932 8.90704 13.1784Z" fill="white" />
                                                        </svg>
                                                    </div>
                                                </div>

                                            </div>
                                            <div class="Zusatzversicherung mt-4" id="GesellschaftSachen">
                                                <div class="p-4">
                                                    <div class="">
                                                        <div class="row mx-0">
                                                            <div class="col-6 d-flex g-0  my-auto">
                                                                <div class="text-nowrap ">
                                                                        <span class="ZusatzversicherungTitle">
                                                                            Neue Anfarge
                                                                        </span>
                                                                </div>
                                                            </div>
                                                            <div class="col g-0 d-flex justify-content-end">
                                                                <div class=" text-end ">
                                                                    <select name="noname" class="form-control GrundversicherungInput" id="">
                                                                        <option selected>Auswählen</option>
                                                                        <option value="1">Ja</option>
                                                                        <option value="2">Nein</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="">
                                                            <div class="GrundversicherungSpans">
                                                                    <span class="GrundversicherungSpans" >
                                                                        Gesellschaft
                                                                    </span>
                                                            </div>
                                                            <input name="society" class="GrundversicherungInput form-control showpdf" type="text" id="">
                                                        </div>
                                                        <div class="input-select-div">
                                                            <div class="GrundversicherungSpans">
                                                                    <span class="GrundversicherungSpans">
                                                                        Anzahl Personen
                                                                    </span>
                                                            </div>
                                                            <select name="n_of_p_legal_protection" class="GrundversicherungInput form-control w-100 showpdf" aria-label="Default select example">
                                                                <option selected></option>
                                                                <option value="1">1</option>
                                                                <option value="2">2</option>
                                                                <option value="3">3</option>
                                                                <option value="4">4</option>
                                                                <option value="5">5</option>
                                                                <option value="6">6</option>
                                                                <option value="7">7</option>
                                                                <option value="8">8</option>
                                                                <option value="9">9</option>
                                                                <option value="10">10</option>
                                                                <option value="11">11</option>
                                                                <option value="12">12</option>
                                                                <option value="13">13</option>
                                                                <option value="14">14</option>
                                                                <option value="15">15</option>
                                                                <option value="16">16</option>
                                                                <option value="17">17</option>
                                                                <option value="18">18</option>
                                                                <option value="19">19</option>
                                                                <option value="20">20</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="py-4 py-md-4">

                                    <div class="pt-4 pt-md-0">
                                        <div class="row g-0 changeBtnAlign">
                                            <div class="col-4 col-md-3 col-lg-2 me-2">
                                                <button type="button" onclick="cancelBtnClickSachen()" class="cancelBtnKranken py-0 py-md-1 w-100">Abbrechen</button>
                                            </div>
                                            <div class="col-4 col-md-3 col-lg-2">
                                                <button type="button" onclick="continueToStep2Sachen()" class="continueBtn py-0 py-md-1 w-100">Weiter</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="step2Sachen" class="" style="display: none;">
                                <div class="">
                                    <div class="row g-0 justify-content-center">
                                        <div class="col-12 col-md-5 col-lg-4 pe-0 pe-md-2">
                                            <div class="list-choice-title list-choice-title-step2 p-2 mt-4" onclick="openSachenDropdownStep2222()">
                                                <div class="row g-0">
                                                    <div class="col my-auto">
                                                        <span>Rechtsschutz</span>
                                                    </div>
                                                    <div class="col-auto">
                                                        <svg width="31" height="31" viewBox="0 0 31 31" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <circle cx="15.2314" cy="15.1093" r="15" fill="#2F60DC" />
                                                            <path d="M8.90704 13.1784C8.90681 13.0023 8.96701 12.8254 9.09028 12.6813C9.3644 12.3601 9.84662 12.322 10.1674 12.5968L15.0229 16.746L19.8676 12.5818C20.1876 12.306 20.67 12.3425 20.9449 12.6629C21.2187 12.9825 21.1832 13.4652 20.8635 13.7395L15.5222 18.3312C15.2364 18.5771 14.8142 18.5777 14.5278 18.3327L9.17449 13.7576C8.99823 13.6072 8.90732 13.3932 8.90704 13.1784Z" fill="white" />
                                                        </svg>
                                                    </div>
                                                </div>
                                            </div>
                                            <div id="Rechtsschutz" class="Grundversicherung mt-4">
                                                <div class="p-4">
                                                    <div class="">
                                                        <div class="mb-3">
                                                            <div class="  justify-content-between">
                                                                <div class="pe-3">
                                                                        <span class="GrundversicherungSpans" >
                                                                            Abschlussdatum:
                                                                        </span>
                                                                </div>
                                                                <input class="w-100 form-control GrundversicherungInput" type="date" name="graduation_date_PR" id="" min="1900-01-01" max="9999-12-31">
                                                            </div>

                                                        </div>
                                                        <div class="mb-3">
                                                            <div class="  justify-content-between">
                                                                <div class="pe-3">
                                                                        <span class="GrundversicherungSpans" >
                                                                            Gesellschaft:
                                                                        </span>
                                                                </div>
                                                                <select class="form-select GrundversicherungInput" aria-label="Default select example" name="society_PR">
                                                                    <option value=""></option>
                                                                    <option value="Helvetia">Helvetia</option>
                                                                    <option value="Zurich">Zurich</option>
                                                                    <option value="Axa">Axa</option>
                                                                    <option value="GM">GM</option>
                                                                </select>
                                                            </div>

                                                        </div>
                                                        <div class="mb-3">
                                                            <div class=" justify-content-between">
                                                                <div class="pe-3">
                                                                        <span class="GrundversicherungSpans" >
                                                                            Produkt
                                                                        </span>
                                                                </div>
                                                                <input class=" w-100 form-control GrundversicherungInput" type="text" name="produkt_PR" id="">
                                                            </div>

                                                        </div>
                                                        <div class="mb-3">
                                                            <div class="  justify-content-between">
                                                                <div class="pe-3">
                                                                        <span class="GrundversicherungSpans" >
                                                                            Status:
                                                                        </span>
                                                                </div>
                                                                <select class="form-control GrundversicherungInput" aria-label="Default select example" name="status_PR">
                                                                    <option selected value="Nicht Ausgewählt">Nicht Ausgewählt
                                                                    </option>
                                                                    <option value="Aufgenomen">Aufgenomen </option>
                                                                    <option value="Offen">Offen</option>
                                                                    <option value="Abgelehnt">Abgelehnt </option>
                                                                    <option value="Zuruckgezogen">Zuruckgezogen</option>
                                                                    <option value="Provisionert">Provisionert </option>
                                                                </select>
                                                            </div>

                                                        </div>
                                                        <div class="mb-3">
                                                            <div class="  justify-content-between">
                                                                <div class="pe-3">
                                                                        <span class="GrundversicherungSpans" >
                                                                            Letze Anpassung:
                                                                        </span>
                                                                </div>
                                                                <input class=" w-100 form-control GrundversicherungInput" type="date"
{{--                                                                       name="last_adjustment_PR"--}}
                                                                       id="" min="1900-01-01" max="9999-12-31" readonly>
                                                            </div>

                                                        </div>
                                                        <div class="mb-3">
                                                            <div class="  justify-content-between">
                                                                <div class="pe-3">
                                                                        <span class="GrundversicherungSpans" >
                                                                            Gesamtprovision:
                                                                        </span>
                                                                </div>
                                                                <input class=" w-100 form-control GrundversicherungInput" type="number" name="total_commisions_PR" id="">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-5 col-lg-4 ps-0 ps-md-2">
                                            <div class="list-choice-title list-choice-title-step2 p-2 mt-4" onclick="openSachenDropdownStep22222()">
                                                <div class="row g-0">
                                                    <div class="col my-auto">
                                                        <span>Hausrat</span>
                                                    </div>
                                                    <div class="col-auto">
                                                        <svg width="31" height="31" viewBox="0 0 31 31" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <circle cx="15.2314" cy="15.1093" r="15" fill="#2F60DC" />
                                                            <path d="M8.90704 13.1784C8.90681 13.0023 8.96701 12.8254 9.09028 12.6813C9.3644 12.3601 9.84662 12.322 10.1674 12.5968L15.0229 16.746L19.8676 12.5818C20.1876 12.306 20.67 12.3425 20.9449 12.6629C21.2187 12.9825 21.1832 13.4652 20.8635 13.7395L15.5222 18.3312C15.2364 18.5771 14.8142 18.5777 14.5278 18.3327L9.17449 13.7576C8.99823 13.6072 8.90732 13.3932 8.90704 13.1784Z" fill="white" />
                                                        </svg>
                                                    </div>
                                                </div>

                                            </div>
                                            <div class="Zusatzversicherung mt-4" id="Hausrat">
                                                <div class="p-4">
                                                    <div class="">
                                                        <div class="mb-3">
                                                            <div class="  justify-content-between">
                                                                <div class="pe-3 GrundversicherungSpans">
                                                                        <span class="" >
                                                                            Gesellschaft:
                                                                        </span>
                                                                </div>
                                                                <select class="form-control GrundversicherungInput" aria-label="Default select example" name="society_PH">
                                                                    <option value=""></option>
                                                                    <option value="Helvetia">Helvetia</option>
                                                                    <option value="Zurich">Zurich</option>
                                                                    <option value="Axa">Axa</option>
                                                                </select>
                                                            </div>

                                                        </div>
                                                        <div class="mb-3">
                                                            <div class="  justify-content-between">
                                                                <div class="pe-3 GrundversicherungSpans">
                                                                        <span class="" >
                                                                            Beginn Versicherung:
                                                                        </span>
                                                                </div>
                                                                <input class=" w-100 form-control GrundversicherungInput" type="date" name="beginning_insurance_PH" id="" min="1900-01-01" max="9999-12-31">
                                                            </div>

                                                        </div>
                                                        <div class="mb-3">
                                                            <div class="  justify-content-between">
                                                                <div class="pe-3 GrundversicherungSpans">
                                                                        <span class="" >
                                                                            Versicherung:
                                                                        </span>
                                                                </div>
                                                                <input class=" w-100 form-control GrundversicherungInput" type="text" name="insurance_PH" id="">
                                                            </div>

                                                        </div>
                                                        <div class="mb-3">
                                                            <div class="  justify-content-between">
                                                                <div class="pe-3 GrundversicherungSpans">
                                                                        <span class="" >
                                                                            Status:
                                                                        </span>
                                                                </div>
                                                                <select class="form-control GrundversicherungInput" aria-label="Default select example" name="status_PH">
                                                                    <option selected value="Nicht Ausgewählt">Nicht Ausgewählt
                                                                    </option>
                                                                    <option value="Aufgenomen">Aufgenomen </option>
                                                                    <option value="Offen">Offen</option>
                                                                    <option value="Abgelehnt">Abgelehnt </option>
                                                                    <option value="Zuruckgezogen">Zuruckgezogen</option>
                                                                    <option value="Provisionert">Provisionert </option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="mb-3">
                                                            <div class="  justify-content-between">
                                                                <div class="pe-3 GrundversicherungSpans">
                                                                        <span class="" >
                                                                            Letze Anpassung:
                                                                        </span>
                                                                </div>
                                                                <input class=" w-100 form-control GrundversicherungInput" type="date"
{{--                                                                       name="last_adjustment_PH"--}}
                                                                       id="" min="1900-01-01" max="9999-12-31" readonly>
                                                            </div>
                                                        </div>
                                                        <div class="mb-3">
                                                            <div class="  justify-content-between">
                                                                <div class="pe-3 GrundversicherungSpans">
                                                                        <span class="" >
                                                                            Gesamtprovision:
                                                                        </span>
                                                                </div>
                                                                <input class=" w-100 form-control GrundversicherungInput" type="number" name="total_commisions_PH" id="">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="py-4" id="step2BtnDiv">
                                        <div class="row g-0 changeBtnAlign">
                                            <div class="col-4 col-md-3 col-lg-2 me-2">
                                                <button type="button" onclick="backBtnSachen()" class="cancelBtnKranken py-0 py-md-1 w-100">Zurück</button>
                                            </div>
                                            <div class="col-4 col-md-3 col-lg-2">
                                                <button type="submit" class="continueBtn py-0 py-md-1 w-100">Einreichen</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="pb-4" id="produkteTitleDiv">
                            <span class="documentFormTitle">Produkte</span>
                        </div>
                        <div class="px-0 px-md-0 px-xl-5 mx-0 mx-md-0 mx-lg-4 mx-xl-5">
                            <div class="row g-0">
                                <div class="col-6 col-md-6 col-lg-3 pe-2 pb-3">
                                    <div id="krankenkaseDiv" class="documentFormGreyBGDiv2 pt-4 pb-2" onclick="openKrankenkasseModal();">
                                        <div class="row flex-column g-0">
                                            <div class="col">
                                                <div class="text-center">
                                                    <svg class="ProduktsSvgClass" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M52.1307 59.4837H7.35333C5.39758 59.4754 3.525 58.6916 2.14645 57.3043C0.767899 55.9169 -0.00403406 54.0394 1.58557e-05 52.0837V13.5881C-0.00403406 11.6324 0.767899 9.75486 2.14645 8.36755C3.525 6.98023 5.39758 6.19642 7.35333 6.18808H11.0024V10.7177H7.35333C6.59465 10.7209 5.86822 11.0249 5.33341 11.563C4.7986 12.1011 4.49909 12.8295 4.50059 13.5881V52.0837C4.49918 52.8424 4.79871 53.5706 5.33349 54.1088C5.86827 54.647 6.59465 54.9511 7.35333 54.9545H52.1307C52.8894 54.9511 53.6157 54.647 54.1505 54.1088C54.6852 53.5706 54.9846 52.8423 54.9831 52.0837V13.5881C54.9846 12.8295 54.6852 12.1013 54.1504 11.5631C53.6157 11.025 52.8894 10.721 52.1307 10.7177H47.9449V6.18879H52.1307C54.0863 6.19722 55.9587 6.98098 57.3371 8.36813C58.7156 9.75528 59.4876 11.6326 59.4837 13.5881V52.0837C59.4878 54.0394 58.7159 55.9168 57.3374 57.3041C55.9589 58.6914 54.0864 59.4753 52.1307 59.4837ZM36.8477 15.7791H22.2158C20.1325 15.7652 18.1393 14.9278 16.6711 13.4497C15.2029 11.9717 14.3789 9.97289 14.3789 7.88956C14.3789 5.80623 15.2029 3.80746 16.6711 2.32939C18.1393 0.851327 20.1325 0.0139563 22.2158 0H36.8477C38.931 0.0139563 40.9242 0.851327 42.3924 2.32939C43.8606 3.80746 44.6846 5.80623 44.6846 7.88956C44.6846 9.97289 43.8606 11.9717 42.3924 13.4497C40.9242 14.9278 38.931 15.7652 36.8477 15.7791V15.7791ZM22.2158 4.52891C21.3304 4.53799 20.4845 4.89606 19.8616 5.52532C19.2388 6.15458 18.8894 7.00419 18.8894 7.88956C18.8894 8.77493 19.2388 9.62454 19.8616 10.2538C20.4845 10.8831 21.3304 11.2411 22.2158 11.2502H36.8477C37.733 11.2411 38.579 10.8831 39.2018 10.2538C39.8247 9.62454 40.174 8.77493 40.174 7.88956C40.174 7.00419 39.8247 6.15458 39.2018 5.52532C38.579 4.89606 37.733 4.53799 36.8477 4.52891H22.2158Z" fill="#5288F5" />
                                                        <path d="M40.3207 32.8575H31.9521V24.7517H27.5322V32.8575H19.1621V37.4049H27.5322V45.5111H31.9521V37.406H40.3207V32.8586V32.8575Z" fill="#F79C42" />
                                                    </svg>
                                                </div>
                                            </div>
                                            <div class="col">
                                                <div class="text-center">
                                                    <span class="underSvgSpan">Krankenkasse</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-6 col-md-6 col-lg-3 ps-2 pe-md-2 pb-3">
                                    <div id="autoDiv" class="documentFormGreyBGDiv2 pt-4 pb-2" onclick="openAutoModal();">
                                        <div class="row flex-column g-0">
                                            <div class="col">
                                                <div class="text-center">
                                                    <svg class="ProduktsSvgClass" viewBox="0 0 66 57" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M60.8349 23.9188C60.3062 20.7118 58.5859 10.9046 56.7231 7.19143C55.4827 4.7214 52.2982 2.83041 47.2632 1.5792C43.1717 0.562842 37.9415 0 32.5364 0C27.1313 0 21.9011 0.558792 17.8096 1.5792C12.7746 2.83446 9.5901 4.7214 8.34965 7.19143C6.48694 10.9005 4.76658 20.7118 4.23787 23.9188C1.395 25.8584 0 28.6645 0 32.3938V42.5169C0 45.157 1.70003 47.4084 4.06705 48.2425V52.64C4.06705 54.8711 5.89316 56.6892 8.1341 56.6892H12.2012C14.4421 56.6892 16.2682 54.8711 16.2682 52.64V48.5907H48.8046V52.64C48.8046 54.8711 50.6307 56.6892 52.8717 56.6892H56.9387C59.1796 56.6892 61.0058 54.8711 61.0058 52.64V48.2425C63.3728 47.4084 65.0728 45.157 65.0728 42.5169V32.3938C65.0728 28.6645 63.6778 25.8584 60.8349 23.9188ZM11.9856 9.00548C13.1935 6.60429 20.803 4.04923 32.5364 4.04923C44.2698 4.04923 51.8793 6.60024 53.0872 9.00548C54.2544 11.3338 55.5518 17.4927 56.353 21.8942C55.9545 21.7767 55.5437 21.6674 55.1207 21.5702C54.0348 21.3151 52.8635 21.1086 51.6109 20.9386L39.8205 12.5283C38.9095 11.8764 37.6365 12.0869 36.9817 12.994C36.3269 13.901 36.5384 15.1684 37.4494 15.8203L43.8184 20.3636C40.3614 20.2502 36.5709 20.2502 32.5323 20.2502C32.0565 20.2502 31.5847 20.2502 31.1129 20.2502L19.4242 12.4919C18.4888 11.8723 17.228 12.1234 16.6058 13.0547C15.9835 13.986 16.2357 15.2413 17.1711 15.8608L23.8573 20.2988C18.4034 20.396 13.6612 20.6916 9.948 21.5702C9.52503 21.6715 9.11426 21.7808 8.71569 21.8942C9.52096 17.4927 10.8143 11.3338 11.9856 9.00548ZM12.2012 52.64H8.1341V48.5907H12.2012V52.64ZM52.8717 52.64V48.5907H56.9387V52.64H52.8717ZM61.0058 42.5169C61.0058 43.6345 60.0947 44.5415 58.9722 44.5415H6.10057C4.97807 44.5415 4.06705 43.6345 4.06705 42.5169V32.3938C4.06705 28.6523 6.04364 26.6561 10.8916 25.5061C15.9957 24.2954 23.6621 24.2954 32.5364 24.2954C41.4107 24.2954 49.073 24.2954 54.1812 25.5061C59.0292 26.6561 61.0058 28.6523 61.0058 32.3938V42.5169Z" fill="#F79C42" />
                                                    </svg>
                                                </div>
                                            </div>
                                            <div class="col">
                                                <div class="text-center">
                                                    <span class="underSvgSpan">Auto</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-6 col-md-6 col-lg-3 pe-2 ps-0 ps-md-2">
                                    <div id="VorsorgeDiv" class="documentFormGreyBGDiv2 pt-4 pb-2" onclick="openVorsorgeModal();">
                                        <div class="row flex-column g-0">
                                            <div class="col">
                                                <div class="text-center">
                                                    <svg class="ProduktsSvgClass" viewBox="0 0 50 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M24.7516 59.4837C11.0816 59.4837 0.00101231 48.2783 0.00101231 34.4546V14.432C-0.0258343 12.7964 0.481952 11.1968 1.447 9.877C2.41204 8.55721 3.78142 7.58959 5.34647 7.1216L8.86222 6.09616C12.2702 5.08857 15.5829 3.78243 18.7621 2.19286L21.4357 0.790314C22.464 0.270693 23.5998 0 24.7516 0C25.9034 0 27.0392 0.270693 28.0676 0.790314L30.8418 2.16639C34.0191 3.76599 37.3315 5.08103 40.7401 6.09616L44.1568 7.1216C45.7218 7.58959 47.0912 8.55721 48.0562 9.877C49.0213 11.1968 49.5291 12.7964 49.5022 14.432V34.4546C49.5022 48.2783 38.4216 59.4837 24.7516 59.4837ZM24.7516 5.01944C24.3751 5.01944 24.0019 5.10379 23.6617 5.27084L20.9155 6.64692C17.5003 8.3966 13.9287 9.82137 10.2477 10.9025L6.73361 11.928C6.20028 12.0867 5.73514 12.4192 5.41204 12.8729C5.08893 13.3265 4.92636 13.8753 4.95014 14.432V34.4546C4.95014 45.5129 13.8163 54.4772 24.7516 54.4772C35.6869 54.4772 44.5514 45.5129 44.5514 34.4546V14.432C44.5753 13.8755 44.413 13.3269 44.0902 12.8733C43.7674 12.4197 43.3027 12.087 42.7696 11.928L39.3794 10.9025C35.6787 9.81928 32.0834 8.40326 28.6373 6.67173L25.8646 5.27084C25.5185 5.10068 25.1372 5.01455 24.7516 5.01944ZM24.7516 43.9913C24.3929 43.9883 24.0387 43.9112 23.7113 43.7647C23.4146 43.6261 23.1482 43.4303 22.9272 43.1885C22.7062 42.9467 22.5349 42.6637 22.4232 42.3555C22.1953 41.7309 22.2226 41.0415 22.4992 40.4369L26.6837 31.2013H18.9867C18.558 31.2033 18.1361 31.0934 17.7626 30.8826C17.3891 30.6718 17.0768 30.3672 16.8565 29.9989C16.6392 29.6178 16.525 29.1865 16.525 28.7477C16.525 28.3089 16.6392 27.8776 16.8565 27.4965L22.6247 16.2084C22.7723 15.9169 22.9761 15.6577 23.2244 15.4456C23.4727 15.2336 23.7605 15.0729 24.0711 14.9729C24.3818 14.873 24.7091 14.8357 25.0343 14.8632C25.3594 14.8907 25.6759 14.9825 25.9654 15.1333C27.1824 15.7684 27.6597 17.2801 27.0305 18.5106L23.1201 26.0195H30.5446C31.3868 26.0212 32.1695 26.4545 32.6253 27.1707C33.0761 27.8819 33.1405 28.7783 32.7971 29.549L27.0305 42.339C26.8629 42.8131 26.5554 43.225 26.1487 43.5201C25.742 43.8152 25.2553 43.9795 24.7533 43.9913H24.7516Z" fill="#14B971" />
                                                    </svg>
                                                </div>
                                            </div>
                                            <div class="col">
                                                <div class="text-center">
                                                    <span class="underSvgSpan">Vorsorge</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-6 col-md-6 col-lg-3 ps-2">
                                    <div id="SachenDiv" class="documentFormGreyBGDiv2 pt-4 pb-2" onclick="openSachenModal();">
                                        <div class="row flex-column g-0">
                                            <div class="col">
                                                <div class="text-center">
                                                    <svg class="ProduktsSvgClass" viewBox="0 0 64 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M54.693 0C59.756 0 63.875 3.8503 63.875 8.58322C63.875 13.3159 59.756 17.1664 54.693 17.1664C49.63 17.1664 45.5109 13.3159 45.5109 8.58322C45.5109 3.8503 49.63 0 54.693 0ZM54.693 4.01153C51.9963 4.01153 49.8025 6.06223 49.8025 8.58298C49.8025 11.1035 51.9963 13.1542 54.693 13.1542C57.3897 13.1542 59.5835 11.1035 59.5835 8.58298C59.5835 6.06247 57.3897 4.01153 54.693 4.01153Z" fill="#5288F5" />
                                                        <path d="M8.9823 0C13.9354 0 17.9649 3.8503 17.9649 8.58322C17.9649 13.3159 13.9352 17.1664 8.9823 17.1664C4.02943 17.1664 -9.53674e-06 13.3159 -9.53674e-06 8.58322C-9.53674e-06 3.8503 4.02943 0 8.9823 0ZM8.9823 4.01153C6.34427 4.01153 4.19816 6.06223 4.19816 8.58298C4.19816 11.1035 6.34427 13.1542 8.9823 13.1542C11.6203 13.1542 13.7665 11.1035 13.7665 8.58298C13.7665 6.06247 11.6203 4.01153 8.9823 4.01153Z" fill="#5288F5" />
                                                        <path d="M31.5385 0C36.3814 0 40.3213 3.8503 40.3213 8.58322C40.3213 13.3159 36.3814 17.1664 31.5385 17.1664C26.6956 17.1664 22.7557 13.3159 22.7557 8.58322C22.7557 3.8503 26.6959 0 31.5385 0ZM31.5385 4.01153C28.959 4.01153 26.8606 6.06223 26.8606 8.58298C26.8606 11.1035 28.959 13.1542 31.5385 13.1542C34.1179 13.1542 36.2164 11.1035 36.2164 8.58298C36.2164 6.06247 34.1179 4.01153 31.5385 4.01153Z" fill="#5288F5" />
                                                    </svg>

                                                </div>
                                            </div>
                                            <div class="col">
                                                <div class="text-center">
                                                    <span class="underSvgSpan">Sachen</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="text-center mt-2">
                                <button id="submitt1" type="submit" title="Accept" class="px-5 py-2" style="border: none; background: rgb(47, 96, 220); border-radius: 10px; color: rgb(255, 255, 255); font-size: 17px; font-weight: 500;">
                                    Einreichen
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>



        <div id="kranken1" class="text-center"></div>
    </div>
</div>
{{-- mobile--}}
<div class="mobile-nav" id="mobile-nav">
    <a href="{{route('dashboard')}}" class="m-nav {{ (request()->is('/')) ? 'activeClassNavMob__' : '' }}">
    <span>
        <svg class="img-fluid " width="26" viewBox="0 0 25 21"
             fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M9.91637 12.6H9.01637V13.5V19.75C9.01637 19.9128 8.8661 20.1 8.6247 20.1H4.7497C4.50829 20.1 4.35803 19.9128 4.35803 19.75V11V10.1H3.45803H1.99054L12.2234 1.18035C12.2237 1.18012 12.2239 1.17989 12.2242 1.17966C12.3767 1.0484 12.6227 1.0484 12.7752 1.17966C12.7755 1.17989 12.7757 1.18012 12.776 1.18035L23.0089 10.1H21.5414H20.6414V11V19.75C20.6414 19.9128 20.4911 20.1 20.2497 20.1H16.3747C16.1333 20.1 15.983 19.9128 15.983 19.75V13.5V12.6H15.083H9.91637Z"
                                stroke="#A7A4A4" stroke-width="1.8" />
                        </svg>
    </span>
    </a>
    @if(in_array('backoffice',$urole) ||
    in_array('fs',$urole) || in_array('admin',$urole))
        <a href="{{route('tasks')}}" class="m-nav {{ (request()->is('tasks')) ? 'activeClassNavMob__' : '' }}">
            <span>
                <svg width="26" viewBox="0 0 25 21" fill="none"
                     xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_171_588)">
                                <path
                                    d="M19.2756 0.953899H15.3806L15.2222 0.356418C15.1679 0.148233 14.9476 0 14.6937 0H10.3063C10.0523 0 9.83295 0.148233 9.77772 0.356418L9.62016 0.953899H5.72439C4.29932 0.953899 3.14062 1.92756 3.14062 3.12462V18.8293C3.14062 20.0264 4.29932 21 5.72439 21H19.2756C20.7007 21 21.8602 20.0264 21.8602 18.8293V3.12462C21.8602 1.92756 20.7006 0.953899 19.2756 0.953899ZM20.1712 18.8293C20.1712 19.2439 19.7696 19.5813 19.2756 19.5813H5.72433C5.23115 19.5813 4.82952 19.2439 4.82952 18.8293V3.12462C4.82952 2.70998 5.23115 2.37266 5.72433 2.37266H9.24487L9.15501 2.71208C9.11869 2.8468 9.15831 2.98812 9.26059 3.09553C9.36361 3.20326 9.51953 3.26593 9.68357 3.26593H15.317C15.4812 3.26593 15.637 3.20326 15.7393 3.09553C15.8424 2.9878 15.882 2.84684 15.8457 2.71208L15.7558 2.37266H19.2756C19.7696 2.37266 20.1712 2.71003 20.1712 3.12462V18.8293Z"
                                    fill="#A7A4A4" />
                                <path
                                    d="M9.07262 10.5013H11.3693L10.8235 10.1882C10.0531 9.74661 9.85528 8.86364 10.3814 8.21665C10.9068 7.57032 11.9582 7.40304 12.7285 7.84533L12.8184 7.89694V7.35558C12.8184 7.00469 12.4795 6.72 12.0621 6.72H9.07262C8.65537 6.72 8.31641 7.00473 8.31641 7.35558V9.86572C8.31641 10.2166 8.65537 10.5013 9.07262 10.5013Z"
                                    fill="#A7A4A4" />
                                <path
                                    d="M16.1054 7.01682L13.4581 9.12206L12.2524 8.43108C11.8689 8.20973 11.3427 8.29355 11.0788 8.61674C10.8157 8.94019 10.9147 9.3815 11.3007 9.60248L13.068 10.6163C13.2124 10.6994 13.3781 10.7399 13.5439 10.7399C13.7542 10.7399 13.9628 10.6742 14.1245 10.5456L17.2666 8.04696C17.6055 7.77784 17.6194 7.32859 17.2995 7.04421C16.9779 6.75984 16.4442 6.7477 16.1054 7.01682Z"
                                    fill="#A7A4A4" />
                                <path
                                    d="M11.7457 12.176H8.75621C8.33897 12.176 8 12.4607 8 12.8116V15.3217C8 15.6725 8.33897 15.9573 8.75621 15.9573H11.7457C12.163 15.9573 12.502 15.6725 12.502 15.3217V12.8116C12.502 12.4607 12.163 12.176 11.7457 12.176Z"
                                    fill="#A7A4A4" />
                            </g>
                            <defs>
                                <clipPath id="clip0_171_588">
                                    <rect width="25" height="21" fill="white" />
                                </clipPath>
                            </defs>
                        </svg>
            </span>
           
        </a>
    @endif
    @if(Auth::guard('admins')->check())
        <a href="{{route('costumers')}}"
           class="m-nav {{ (request()->is('costumers')) ? 'activeClassNavMob__' : '' }}">
    <span>
        <svg width="26" viewBox="0 0 30 30" fill="none"
             xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M14.6364 16.3418C15.5814 15.3135 16.1605 13.9336 16.1605 12.4189C16.1605 9.24902 13.6252 6.6709 10.5079 6.6709C7.39069 6.6709 4.8554 9.24902 4.8554 12.4189C4.8554 13.9395 5.44025 15.3223 6.39098 16.3535C5.78597 16.7109 5.22417 17.1533 4.71424 17.6689C3.16425 19.2451 2.30859 21.3428 2.30859 23.5752C2.30859 24.9287 2.63703 25.8897 3.3083 26.5078C4.38868 27.501 5.99628 27.3311 7.85453 27.1377C8.70731 27.0498 9.5889 26.9561 10.5195 26.9561C11.45 26.9561 12.3316 27.0469 13.1844 27.1377C13.9104 27.2139 14.599 27.2842 15.2328 27.2842C16.221 27.2842 17.0738 27.1113 17.7306 26.5049C18.4048 25.8867 18.7303 24.9287 18.7303 23.5723C18.7303 21.3428 17.8747 19.2451 16.3247 17.666C15.8176 17.1445 15.2472 16.7021 14.6364 16.3418ZM10.5079 8.5459C12.6082 8.5459 14.3166 10.2832 14.3166 12.4189C14.3166 14.5547 12.6082 16.292 10.5079 16.292C8.40769 16.292 6.69925 14.5547 6.69925 12.4189C6.70213 10.2832 8.41057 8.5459 10.5079 8.5459ZM16.5004 25.1133C16.028 25.5469 14.7401 25.4121 13.3774 25.2715C12.5189 25.1836 11.548 25.0811 10.5252 25.0811C9.50247 25.0811 8.53157 25.1836 7.67303 25.2715C6.31031 25.4121 5.0225 25.5469 4.55002 25.1133C4.29073 24.8731 4.1582 24.3574 4.1582 23.5723C4.1582 20.8887 5.77445 18.5801 8.06773 17.5986C8.80815 17.9619 9.63788 18.1641 10.5137 18.1641C11.4673 18.1641 12.3662 17.9209 13.1556 17.4961C13.1239 17.54 13.0893 17.584 13.0519 17.625C15.3106 18.6211 16.8951 20.9121 16.8951 23.5693C16.8923 24.3545 16.7597 24.8731 16.5004 25.1133Z"
                                fill="#A7A4A4" />
                            <path
                                d="M24.7417 13.6729C24.2289 13.1514 23.6585 12.709 23.0477 12.3457C24.0071 11.3027 24.5891 9.89649 24.5718 8.35548C24.5631 7.68165 24.4421 7.03712 24.2232 6.43653C24.2232 6.4336 24.2203 6.43067 24.2203 6.42481C24.2116 6.40431 24.2059 6.3838 24.1972 6.36329C23.3906 4.21583 21.3508 2.67481 18.9653 2.65431C16.9861 2.63673 15.2373 3.65626 14.2117 5.21485C13.8026 5.83888 14.2405 6.67384 14.978 6.67384C15.2863 6.67384 15.5715 6.51856 15.7444 6.25782C15.8913 6.03517 16.0613 5.82716 16.2485 5.63966C16.2975 5.61036 16.3465 5.5752 16.3926 5.53419C17.084 4.91017 17.9973 4.53517 18.997 4.55567C20.6306 4.5879 22.0192 5.67774 22.5263 7.17774C22.6645 7.59376 22.7337 8.042 22.7222 8.50489C22.6732 10.4854 21.1405 12.126 19.1958 12.2666C19.1036 12.2725 19.0114 12.2754 18.9221 12.2783C18.8616 12.2783 18.8011 12.2842 18.7435 12.2959C18.3142 12.2959 17.9397 12.6035 17.8533 13.0342C17.8533 13.04 17.8504 13.0459 17.8504 13.0518C17.7351 13.6113 18.1414 14.1445 18.7032 14.168C18.7752 14.1709 18.8472 14.1709 18.9221 14.1709C19.8066 14.1709 20.6421 13.9629 21.3883 13.5938C23.647 14.5899 25.3064 16.919 25.3064 19.5762C25.3064 20.3584 25.1739 20.877 24.9146 21.1172C24.4421 21.5508 23.1543 21.416 21.7916 21.2754C21.5323 21.249 20.9676 21.1963 20.9561 21.2022C20.4548 21.2109 20.0515 21.627 20.0515 22.1367C20.0515 22.6465 20.4519 23.0596 20.9475 23.0713C20.9503 23.0742 21.3911 23.1182 21.6015 23.1416C22.3275 23.2178 23.016 23.2881 23.6498 23.2881C24.638 23.2881 25.4908 23.1152 26.1477 22.5088C26.8218 21.8906 27.1474 20.9326 27.1474 19.5762C27.1474 17.3467 26.2917 15.249 24.7417 13.6729Z"
                                fill="#A7A4A4" />
                        </svg>
    </span>
        </a>
    @endif
    @if(in_array('admin',$urole) ||
    in_array('fs',$urole) ||
    in_array('salesmanager',$urole)
    ||in_array('menagment',$urole))
        <a href="{{route('leads')}}" class="m-nav {{ (request()->is('leads')) ? 'activeClassNavMob__' : '' }}">
    <span>
        <svg xmlns="http://www.w3.org/2000/svg" width="26" fill="none" class="bi bi-hdd-stack" viewBox="0 0 16 16">
               <path fill="#A7A4A4" d="M14 10a1 1 0 0 1 1 1v1a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1v-1a1 1 0 0 1 1-1h12zM2 9a2 2 0 0 0-2 2v1a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-1a2 2 0 0 0-2-2H2z"/>
               <path fill="#A7A4A4" d="M5 11.5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0zm-2 0a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0zM14 3a1 1 0 0 1 1 1v1a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h12zM2 2a2 2 0 0 0-2 2v1a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H2z"/>
               <path fill="#A7A4A4" d="M5 4.5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0zm-2 0a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0z"/>
        </svg>
    </span>
        </a>
    @endif
    <div class="m-nav" onclick="openBurgerFunct()">
    <span>
    <svg width="26" height="26" viewBox="0 0 20 14" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M1 7H19" stroke="#A7A4A4" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M1 1H19" stroke="#A7A4A4" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M1 13H19" stroke="#A7A4A4" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
    </span>
    </div>
</div>
<div class="bottom-burger-modal" id="bottom-burger" style="display: none; text-decoration: none !important;">
    <div class="my-2">
        <div class="row">
            <div class="col">
                <img src="" class="img-fluid" alt="">
            </div>
            <div class="col me-2 mt-2">
                <div class="my-auto text-end pe-2">
                <svg onclick="openBurgerFunct()"  width="18" height="18" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M18 2L2 18" stroke="#434343" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M2 2L18 18" stroke="#434343" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                </div>
            </div>
        </div>
    </div>
    <div class="content-of-burger col-9 mx-auto">
        <div class="my-3 m-burger">
            @if(in_array('fs',$urole) ||
                in_array('salesmanager',$urole) ||
                in_array('menagment',$urole) ||
                in_array('admin',$urole))
                <a href="{{route('Appointments')}}"
                   class="m-nav text-decoration-none {{ (request()->is('Appointments')) ? 'activeClassNavMob__' : '' }}">
                    <div class="row g-0">
                        <div class="col-auto my-auto me-3">
                            <svg width="22"
                                viewBox="0 0 21 23" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M18.5625 7.79948V20.3989H2.25V7.79948H18.5625ZM18.5625 5.99956H2.25C1.2495 5.99956 0.4375 6.80413 0.4375 7.79948V20.3989C0.4375 21.3942 1.2495 22.1988 2.25 22.1988H18.5625C19.5648 22.1988 20.375 21.3942 20.375 20.3989V7.79948C20.375 6.80413 19.5648 5.99956 18.5625 5.99956ZM19.4688 2.39974H16.75V1.49978C16.75 1.003 16.344 0.599823 15.8438 0.599823C15.3435 0.599823 14.9375 1.003 14.9375 1.49978V2.39974H5.875V1.49978C5.875 1.003 5.469 0.599823 4.96875 0.599823C4.4685 0.599823 4.0625 1.003 4.0625 1.49978V2.39974H1.34375C0.8435 2.39974 0.4375 2.80292 0.4375 3.29969C0.4375 3.79647 0.8435 4.19965 1.34375 4.19965H19.4688C19.969 4.19965 20.375 3.79647 20.375 3.29969C20.375 2.80292 19.969 2.39974 19.4688 2.39974ZM5.875 9.59939H4.0625V11.3993H5.875V9.59939ZM9.5 9.59939H7.6875V11.3993H9.5V9.59939ZM13.125 9.59939H11.3125V11.3993H13.125V9.59939ZM16.75 9.59939H14.9375V11.3993H16.75V9.59939ZM5.875 13.1992H4.0625V14.9991H5.875V13.1992ZM9.5 13.1992H7.6875V14.9991H9.5V13.1992ZM13.125 13.1992H11.3125V14.9991H13.125V13.1992ZM16.75 13.1992H14.9375V14.9991H16.75V13.1992ZM5.875 16.799H4.0625V18.599H5.875V16.799ZM9.5 16.799H7.6875V18.599H9.5V16.799ZM13.125 16.799H11.3125V18.599H13.125V16.799ZM16.75 16.799H14.9375V18.599H16.75V16.799Z"
                                    fill="#A7A4A4" />
                            </svg>
                        </div>
                    
                        <div class="col my-auto">
                            <div>
                                <span class="fs-6 {{ (request()->is('Appointments')) ? 'activeClassNavMob__' : '' }}" style="color: #A7A4A4;font-weight: 500">
                                    Kalender
                                </span>
                            </div>
                        </div> 
                    </div>     
                </a>
            @endif
        </div>
    <div class="my-3 m-burger">
        <a href="{{route('hr_view')}}" class="m-nav text-decoration-none {{ (request()->is('hr_view')) ? 'activeClassNavMob__' : '' }}">
                <div class="row g-0">
                    <div class="col-auto my-auto pe-3">
                        <svg width="22" height="24" viewBox="0 0 22 28" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M18.8757 6.77321L18.8782 6.77093L18.7214 6.60039L18.6374 6.48654H18.9258C19.9479 6.48654 20.7768 7.31541 20.7767 8.33758V8.3376C20.7767 11.5768 20.774 16.1418 20.7712 19.8972C20.7698 21.7749 20.7684 23.4501 20.7674 24.6559L20.7661 26.0792L20.7658 26.4642L20.7657 26.5641L20.7657 26.5895L20.7657 26.5959L20.7657 26.5976L20.7657 26.598C20.7657 26.5981 20.7657 26.5981 21.2657 26.5986L20.7657 26.5981V26.5986C20.7657 27.0966 20.3619 27.5 19.8646 27.5C19.3669 27.5 18.9631 27.0964 18.9631 26.5986V18.2472V17.7472H18.4631H17.5287H17.0287V18.2472V26.5986C17.0287 26.9096 17.0826 27.2036 17.1749 27.4763C17.11 27.4919 17.0428 27.5001 16.974 27.5001C16.4765 27.5001 16.0725 27.0964 16.0725 26.5986V26.5986L16.0708 13.2328L16.1896 13.1822L16.1899 13.1821L16.353 13.1128L16.353 13.1128L16.3549 13.112C16.5642 13.0221 16.7542 12.8839 16.909 12.7007L16.909 12.7006L20.5026 8.44529L20.51 8.43659L20.5169 8.42756C20.5382 8.39988 20.5524 8.37559 20.5599 8.36195C20.5637 8.35511 20.5666 8.34956 20.5678 8.34716L20.5684 8.3461C20.5668 8.3491 20.5592 8.36398 20.5477 8.38207C20.546 8.38475 20.5442 8.38755 20.5422 8.39045C20.5456 8.38529 20.5483 8.38092 20.5502 8.37769L20.5543 8.37084L20.5554 8.36901L20.5555 8.36882M18.8757 6.77321L18.7322 6.61495L18.8594 6.78734C18.8648 6.78291 18.8702 6.7782 18.8757 6.77321ZM18.8757 6.77321L18.8598 6.78785L18.8602 6.78833C18.8581 6.78996 18.8561 6.79156 18.8541 6.79312L14.9585 10.3748L14.8952 10.433L14.816 10.4667L10.7969 12.1784L10.7966 12.1786C10.4575 12.3227 10.2992 12.7147 10.4433 13.0542C10.552 13.3081 10.7985 13.4611 11.0591 13.4611C11.1455 13.4611 11.2332 13.444 11.3179 13.4077L11.3194 13.407L15.5237 11.617L15.525 11.6164C15.5945 11.587 15.6578 11.5462 15.7136 11.4947L15.7143 11.494L19.7532 7.77978C19.7654 7.76611 19.7796 7.75153 19.7962 7.73683L20.3061 8.26537L20.3787 8.34063L20.4899 8.45584C20.4937 8.45176 20.4974 8.44774 20.5009 8.44382C20.5062 8.43781 20.5111 8.43201 20.5156 8.4265C20.5236 8.41659 20.5302 8.40761 20.5355 8.40003C20.5427 8.38966 20.5481 8.38105 20.5513 8.37591C20.5532 8.37282 20.5548 8.37007 20.5555 8.36882M20.5555 8.36882C20.5559 8.36817 20.556 8.36793 20.5558 8.36826L20.5555 8.36882ZM20.1207 8.1226L20.1212 8.12309L20.1213 8.12327L20.4584 8.48982L20.4582 8.49004L17.5586 11.1565L16.527 12.378C16.423 12.5012 16.2964 12.5929 16.1575 12.6526L20.1207 8.1226ZM20.1207 8.1226C20.1219 8.12102 20.1228 8.1193 20.1237 8.11756C20.1248 8.11525 20.126 8.11292 20.128 8.11088C20.1262 8.11245 20.1251 8.11441 20.1239 8.11638C20.1228 8.11831 20.1217 8.12024 20.12 8.12178L20.1207 8.1226ZM19.7851 7.7504L19.7815 7.75375L19.7852 7.75042L19.7851 7.7504ZM19.716 7.82689L17.1969 10.8098L16.0527 11.862C15.9549 11.9524 15.8427 12.025 15.7196 12.077L11.5153 13.867C11.3667 13.9309 11.2117 13.9611 11.0591 13.9611C10.6048 13.9611 10.1732 13.6946 9.98336 13.2503L19.716 7.82689ZM17.4825 6.53904L16.369 7.32988C16.6224 6.94042 17.0182 6.65214 17.4825 6.53904Z" fill="#A7A4A4" stroke="#A7A4A4"/>
                                <path d="M20.6555 2.73067V2.73069C20.6555 3.96267 19.6577 4.96087 18.4247 4.96087C17.1929 4.96087 16.1941 3.96255 16.1941 2.73069C16.1941 1.49825 17.1929 0.5 18.4247 0.5C19.6577 0.5 20.6555 1.49815 20.6555 2.73067Z" fill="#A7A4A4" stroke="#A7A4A4"/>
                                <path d="M5.80586 2.73069C5.80586 3.96254 4.80711 4.96087 3.57512 4.96087C2.34231 4.96087 1.34448 3.96268 1.34448 2.73069C1.34448 1.49813 2.34237 0.5 3.57512 0.5C4.80705 0.5 5.80586 1.49827 5.80586 2.73069Z" fill="#A7A4A4" stroke="#A7A4A4"/>
                                <path d="M6.66035 10.1828L6.70721 10.228L6.76409 10.2597L9.05835 11.5382C8.81058 11.9305 8.67934 12.3912 8.69168 12.8624L5.98097 11.3523L5.97961 11.3516C5.93141 11.3249 5.88472 11.2906 5.84061 11.2487L2.6157 8.13821L1.88404 8.81765L4.76635 12.286L4.76633 12.286L4.76889 12.2891C4.80797 12.3353 4.8539 12.3783 4.9037 12.4146L4.90368 12.4147L4.90881 12.4183L5.20673 12.63L5.20691 12.6301L5.92912 13.1437L5.9274 26.5985V26.5986C5.9274 27.0963 5.52336 27.5 5.02595 27.5C4.95702 27.5 4.88973 27.4918 4.82476 27.4762C4.91713 27.2036 4.97119 26.9096 4.97119 26.5986V18.2472V17.7472H4.47119H3.53673H3.03673V18.2472V26.5986C3.03673 27.0965 2.633 27.5001 2.13528 27.5001C1.63805 27.5001 1.23422 27.0966 1.23422 26.5986L1.23422 26.5981L0.73422 26.5986C1.23422 26.5981 1.23422 26.5981 1.23422 26.598L1.23422 26.5976L1.23422 26.596L1.23421 26.5897L1.23419 26.5647L1.2341 26.4665L1.23374 26.0877L1.23249 24.6851C1.23145 23.4955 1.23007 21.8397 1.22868 19.975C1.22591 16.2455 1.22314 11.6804 1.22314 8.33765C1.22314 7.31541 2.05197 6.48654 3.07425 6.48654H4.07804C4.09839 6.48654 4.11866 6.48687 4.13884 6.48752L3.54381 7.17654L6.66035 10.1828ZM4.29837 6.49953C4.98439 6.58096 5.55567 7.03785 5.80069 7.65895L4.29837 6.49953Z" fill="#A7A4A4" stroke="#A7A4A4"/>
                            </svg>
                    </div>
                    <div class="col my-auto">
                        <div>
                            <span class="fs-6 {{ (request()->is('hr_view')) ? 'activeClassNavMob__' : '' }}" style="color: #A7A4A4;font-weight: 500">
                                HR
                            </span>
                        </div>
                        
                    </div>
                </div>
        </a>
        </div>
        <div class="my-3 m-burger">
        @if(Auth::check() && !auth()->user()->hasRole('callagent')  && !auth()->user()->hasRole('fs') && !auth()->user()->hasRole('salesmanager'))
            <a href="{{route('finance')}}" class="m-nav text-decoration-none {{ (request()->is('finance')) ? 'activeClassNavMob__' : '' }}">
                <div class="row g-0">
                    <div class="col-auto pe-3">
                        <svg width="22" height="24" viewBox="0 0 23 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M20.2927 0H5.14407C3.71769 0 2.55754 1.06117 2.55754 2.36567V2.57302C1.14468 2.58773 0 3.64193 0 4.93727V12.2971C0 13.6016 1.16038 14.6628 2.58654 14.6628H17.7352C19.1614 14.6628 20.3217 13.6016 20.3217 12.2971V12.0898C21.7343 12.0754 22.8793 11.0212 22.8793 9.72551V2.36578C22.8796 1.06128 21.7189 0 20.2927 0ZM18.6632 12.2971C18.6632 12.6803 18.2384 13.0038 17.7355 13.0038H2.58686C2.08397 13.0038 1.65924 12.6803 1.65924 12.2971V4.93738C1.65924 4.5544 2.08419 4.23073 2.58686 4.23073H17.7355C18.2384 4.23073 18.6632 4.55451 18.6632 4.93738V12.2971ZM20.3221 10.4299V4.93727C20.3221 3.63277 19.1617 2.5716 17.7355 2.5716H4.21645V2.36567C4.21645 1.98269 4.6414 1.65902 5.14407 1.65902H20.2927C20.7956 1.65902 21.2204 1.9828 21.2204 2.36567V9.72551H21.2207C21.2206 10.101 20.8118 10.4174 20.3221 10.4299Z" fill="#A7A4A4"/>
                            <path d="M10.1907 7.99572C9.49256 7.91254 9.13814 7.81301 9.13814 7.49883C9.13814 7.01217 9.84261 6.95963 10.1457 6.95963C10.5917 6.95963 11.0849 7.17526 11.2455 7.44039L11.3094 7.54625L12.3283 7.07486L12.2661 6.94796C11.9075 6.21559 11.2718 5.99439 10.781 5.90445V5.25635H9.58926V5.90107C8.53975 6.06449 7.91737 6.65558 7.91737 7.49861C7.91737 8.88574 9.21849 9.03117 10.0786 9.12765C10.8605 9.21998 11.2249 9.40771 11.2249 9.71819C11.2249 10.3188 10.3767 10.3654 10.1165 10.3654C9.53311 10.3654 8.97124 10.0765 8.80978 9.69301L8.75582 9.56557L7.65039 10.0339L7.7049 10.1613C8.01592 10.8896 8.68256 11.3489 9.58893 11.4633V12.162H10.7806V11.4284C11.6504 11.3212 12.4885 10.7649 12.4885 9.71786C12.4888 8.27917 11.1061 8.10877 10.1907 7.99572Z" fill="#A7A4A4"/>
                        </svg>
                    </div>
                    <div class="col">
                        <div>
                        <span class="fs-6 {{ (request()->is('finance')) ? 'activeClassNavMob__' : '' }} " style="color: #A7A4A4;font-weight: 500">
                            Finanzen
                        </span>
                        </div>
                    </div>
                </div>
            </a>
        @endif
        </div>
        <div class="my-3 m-burger">
            @if(Auth::check() && !auth()->user()->hasRole('callagent'))
                <a href="{{route('statistics')}}" class="m-nav text-decoration-none {{ (request()->is('statistics')) ? 'activeClassNavMob__' : '' }}">
                    <div class="row g-0">
                        <div class="col-auto pe-3">
                            <svg width="22" height="24" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M19.3571 18.7143H15.8401V11.3353C15.8401 10.9802 15.5524 10.6924 15.1973 10.6924H13.007C12.6519 10.6924 12.3641 10.9802 12.3641 11.3353V18.7143H11.0855V8.23843C11.0855 7.88336 10.7977 7.59557 10.4426 7.59557H8.25236C7.89729 7.59557 7.6095 7.88336 7.6095 8.23843V18.7143H6.33093V5.11093C6.33093 4.75586 6.04314 4.46807 5.68807 4.46807H3.49779C3.14271 4.46807 2.85493 4.75586 2.85493 5.11093V18.7143H1.28571V0.642857C1.28571 0.287786 0.997929 0 0.642857 0C0.287786 0 0 0.287786 0 0.642857V19.3571C0 19.7122 0.287786 20 0.642857 20H19.3571C19.7122 20 20 19.7122 20 19.3571C20 19.0021 19.7122 18.7143 19.3571 18.7143ZM13.6499 11.9781H14.5544V18.7143H13.6499V11.9781ZM8.89529 8.88129H9.79986V18.7143H8.89529V8.88129ZM4.14064 5.75379H5.04521V18.7143H4.14064V5.75379Z" fill="#A7A4A4"/>
                            </svg>
                        </div>
                        <div class="col">
                            <div>
                            <span class="fs-6 {{ (request()->is('statistics')) ? 'activeClassNavMob__' : '' }}" style="color: #A7A4A4;font-weight: 500" >
                                Statistik
                    </span>
                            </div>
                        </div>
                    </div> 
                </a>
            @endif
        </div>
        <div class="my-3 m-burger">
            @if(in_array('admin',$urole))
                <a href="{{route('addnewuser')}}"
                   class="m-nav text-decoration-none {{ (request()->is('addnewuser')) ? 'activeClassNavMob__' : '' }}">
                <div class="row g-0">
                    <div class="col-auto pe-3">
                        <svg width="22" height="24" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <circle cx="10.5" cy="10.5" r="9.5" fill="#A7A4A4" stroke="#A7A4A4" stroke-width="2"/>
                                    <path d="M14.9987 9.49654H11.5009V6.00171C11.5009 5.44852 11.0546 5 10.5014 5C9.94821 5 9.50211 5.44852 9.50211 6.00195V9.49896H6.00268C5.44948 9.49896 4.99976 9.94748 5 10.5009C4.99976 10.7774 5.11146 11.0308 5.29247 11.2119C5.47372 11.3933 5.72378 11.508 6.00001 11.508H9.50211V15.0001C9.50211 15.2768 9.61188 15.5274 9.79313 15.7081C9.97438 15.8894 10.2237 16.0016 10.5004 16.0016C11.0534 16.0016 11.5009 15.5531 11.5009 15.0001V11.5077H14.9987C15.5519 11.5077 16.0004 11.0553 16.0001 10.5021C15.9999 9.94917 15.5514 9.49654 14.9987 9.49654Z" fill="#fff"/>
                        </svg>
                    </div>
                    <div class="col ">
                        <div>
                        <span class="fs-6 {{ (request()->is('addnewuser')) ? 'activeClassNavMob__' : '' }}" style="color: #A7A4A4;font-weight: 500">
                            Registrieren
                        </span>
                        </div>
                    </div>
                </div>            
                </a>
            @endif
        </div>
        <div class="my-3 m-burger">
            @if(auth()->user()->admin_id != null)
                <a href="{{action('App\Http\Controllers\UserController@changerole')}}" class="m-nav text-decoration-none">
                <div class="row g-0">
                    <div class="col-auto pe-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="22" height="24" fill="#a7a4a4" class="bi bi-person-check" viewBox="0 0 16 16">
                                    <path d="M6 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H1s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C9.516 10.68 8.289 10 6 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z"/>
                                    <path fill-rule="evenodd" d="M15.854 5.146a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 0 1 .708-.708L12.5 7.793l2.646-2.647a.5.5 0 0 1 .708 0z"/>
                                </svg>
                    </div>
                    <div class="col">
                        <div>
                        <span class="fs-6 " style="color: #A7A4A4;font-weight: 500">
                            Rolle Wechseln
                        </span>
                        </div>
                    </div>
                </div> 
                </a>
            @endif
        </div>
        <div class="my-3 m-burger">
            <a href="{{route('logout')}}" class="m-nav text-decoration-none">
                <div class="row g-0">
                    <div class="col-auto pe-3">
                        <svg width="22" height="24" viewBox="0 0 18 16" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M5.80469 15.3333H2.13802C1.1255 15.3333 0.304688 14.5125 0.304688 13.5V2.49999C0.304688 1.48747 1.1255 0.666656 2.13802 0.666656H5.80469V2.49999H2.13802V13.5H5.80469V15.3333Z"
                                    fill="#A7A4A4" />
                                <path
                                    d="M10.6877 12.9363L11.9896 11.6454L8.39698 8.02219H16.778C17.2842 8.02219 17.6946 7.6118 17.6946 7.10552C17.6946 6.59925 17.2842 6.18885 16.778 6.18885H8.37938L12.0281 2.57095L10.7372 1.2691L4.87891 7.07793L10.6877 12.9363Z"
                                    fill="#A7A4A4" />
                        </svg>
                    </div>
                    <div class="col">
                        <div>
                        <span class="fs-6 " style="color: #A7A4A4;font-weight: 500">
                            Abmelden
                        </span>
                        </div>
                    </div>
                </div>
            </a>
        </div>

    </div>
</div>

    
   



</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    function openBurgerFunct() {
        $("#bottom-burger").slideToggle();
    }
</script>
{{--mobile--}}
<style>
    /* .firstHr {
        width: 5px;
        height: 3px;
        transition: all 0.2s ease-in-out;
        text-align: center;
    }

    .m-burger:hover .firstHr {
        width: 20px;
    } */

    .bottom-burger-modal {
        width: 100%;
        height: 100vh;
        overflow: auto;
        background: #F1F1F1;
        position: absolute;
        margin: 0;
        padding: 0;
        z-index: 3;
        position: fixed;
        bottom: 0;
        animation: myfirst 0.6s;
        animation-direction: reverse;
    }

    @keyframes myfirst {
        0% {
            left: 0px;
            top: 0px;
        }

        100% {
            left: 0px;
            top: 100%;
        }
    }

    .item-nvm {
        border: none;
        border-bottom: 1px solid #a7a7a7
    }

    .item-nvm:hover {
        background-color: #f3f3f3;
    }

    .m-nav .dropup .dropdown-toggle::after {
        display: none !important;
    }

    .mobile-nav {
        z-index: 1000;
        background: #F1F1F1;
        position: fixed;
        bottom: 0;
        height: 65px;
        border: none;
        
        margin-top: auto !important;
        margin-bottom: auto !important;
        width: 100% !important;
        display: flex;
        align-items: center !important;
        justify-content: space-evenly !important;
        vertical-align: middle !important;
    }

    .mobile-nav a {
        text-decoration: none !important;
        color: #000;
    }


    .active-dot {
        visibility: hidden;
        display: none;
    }

    .mobile-nav {
        display: none;
    }

    .first-col1 {
        display: block;
    }

    @media (max-width: 767.98px) {
        .first-col1 {
            display: none;
        }

        .mobile-nav {
            display: flex;
        }

        body {
            padding-bottom: 65px;
        }

        .be-gone {
            display: none;
        }
    }

    a {
        text-decoration: none;
    }
</style>
<style>
    .nav-form-links button.active {
        color: #434343 !important;
    }

    .nav-form-links .nav-form-links button:hover {
        color: #434343 !important;
        background-color: #fff !important;
    }

    .nav-form-links button:hover {
        color: #434343 !important;
    }

    .nav-form-links button {
        color: rgba(95, 95, 95, 0.8) !important;
    }

    .nav-form-links button:hover {
        background-color: transparent !important;
    }

    .nav-form-links button.active:hover {
        background-color: #fff !important;
    }

    .form-select:focus-visible {
        outline: none !important;
        box-shadow: none !important;
    }

    body {
        overflow-x: hidden !important;
    }

    .btn-group label {
        box-shadow: none !important;
    }

    .input-group .form-control:focus {
        border-color: #ced4da !important;
        box-shadow: none !important;
    }

    .slct1 {
        border: none !important;
        border-bottom-right-radius: 5px !important;
        border-bottom-left-radius: 5px !important;
    }

    .slct1:focus-visible {
        outline: none;
    }

    .date-input-div input[type="date"]:focus-visible {
        outline: none;
    }

    .ja-group-btn {
        width: 85px;
        font-size: 14px;
        border: none;
        background-color: #fff;
        border-bottom-left-radius: 12px;
        border-top-left-radius: 12px;
        border-right: 1px #9F9F9F solid !important;
    }

    .ja-group-btn:hover {
        background-color: #dfdbdb;
    }

    .ja-group-btn:focus {
        background-color: #a3a3a3;
        color: #fff;
    }

    .ja-group-btn1 {
        font-size: 14px;
        border: none;
        border-bottom: #C4C6D2 1px solid;
        background-color: #fff;
        border-bottom-left-radius: 0;
        border-top-left-radius: 12px;
        border-right: 1px #9F9F9F solid !important;
    }

    .ja-group-btn1:hover {
        background-color: #dfdbdb;
    }

    .ja-group-btn1:focus {
        background-color: #a3a3a3;
        color: #fff;
    }

    .nein-group-btn {
        width: 85px;
        font-size: 14px;
        border: none;
        background-color: #fff;
        border-bottom-right-radius: 12px;
        border-top-right-radius: 12px;
        border-left: 1px #c9c8c8 solid !important;
    }

    .nein-group-btn:hover {
        background-color: #dfdbdb;
    }

    .nein-group-btn:focus {
        background-color: #a3a3a3;
        color: #fff;
    }

    .nein-group-btn1 {
        font-size: 14px;
        border: none;
        border-bottom: #C4C6D2 1px solid;
        background-color: #fff;
        border-bottom-right-radius: 0;
        border-top-right-radius: 12px;
        border-left: 1px #c9c8c8 solid !important;
    }

    .nein-group-btn1:hover {
        background-color: #dfdbdb;
    }

    .nein-group-btn1:focus {
        background-color: #a3a3a3;
        color: #fff;
    }

    .steps-content .tab-content {
        border: 1px solid #dee2e6;
        border-top: none;
        border-top-left-radius: 0px;
        border-top-right-radius: 0px;
        border-bottom-left-radius: 17px;
        border-bottom-right-radius: 17px;
    }

    .input-select-div select:focus {
        outline: none;
        box-shadow: none;
        border-color: #fff;
    }

    .input-select-div select {
        border-radius: 7px !important;
    }

    .input-div1 input {
        border: none;
        border-radius: 5px;
    }

    .input-div1 input:focus-visible {
        outline: none;
    }

    .accordion-button:focus {
        background-color: #fff !important;
        color: #434343;
        box-shadow: none;
        border-color: #434343;
    }

    .accordion-button:not(.collapsed) {
        color: #434343;
        background-color: #fff;
        box-shadow: none;
    }

    .select-div select {
        border: none;
    }

    .select-div select:focus-visible {
        outline: none;
    }

    .upload-box input[type="file"] {
        display: none;
    }

    .upload-box1 input[type="file"] {
        display: none !important;
    }

    .krankenkasse-content {
        background-color: #fff;
        border-bottom-left-radius: 17px !important;
        border-bottom-right-radius: 17px !important;
        border-top-right-radius: 17px !important;
    }

    .gray-btn-kk {
        border: solid !important;
        border-left: none !important;
        border-top: #979797 solid 4px !important;
        border-right: #979797 solid 4px !important;
        border-bottom: none !important;
    }

    .auto-content {
        background-color: #fff;
        border-bottom-left-radius: 17px !important;
        border-bottom-right-radius: 17px !important;
        border-top-right-radius: 17px !important;
        border-top-left-radius: 17px !important;
    }

    .sachen-content {
        background-color: #fff;
        border-bottom-left-radius: 17px !important;
        border-bottom-right-radius: 17px !important;
        border-top-left-radius: 17px !important;
    }

    .vorsorge-content {
        background-color: #fff;
        border-bottom-left-radius: 17px !important;
        border-bottom-right-radius: 17px !important;
        border-top-left-radius: 17px !important;
    }

    .krankenkasse-btn {
        color: black;
        font-weight: 600;
        /*border: none !important;*/
        border-top-left-radius: 15px !important;
        border-top-right-radius: 15px !important;
        border-bottom-left-radius: 0px !important;
        /*border-top-right-radius: 15px !important;*/

    }

    .krankenkasse-btn:hover {
        color: black;
    }

    .auto-btn {
        color: black;
        font-weight: 600;
        /*border: none !important;*/
        border-top-left-radius: 15px !important;
        border-top-right-radius: 15px !important;
        border-bottom-left-radius: 0px !important;

    }

    .auto-btn:hover {
        color: black;
    }

    .sachen-btn {
        color: black;
        font-weight: 600;
        /*border: none !important;*/
        border-top-left-radius: 15px !important;
        border-top-right-radius: 15px !important;
        border-bottom-left-radius: 0px !important;

    }

    .sachen-btn:hover {
        color: black;
    }

    .vorsorge-btn {
        color: black;
        font-weight: 600;
        /*border: none !important;*/
        border-top-left-radius: 15px !important;
        border-top-right-radius: 15px !important;
        border-bottom-left-radius: 0px !important;

    }

    .vorsorge-btn:hover {
        color: black;
    }

    .upload-box {
        background-image: url("data:image/svg+xml,%3csvg width='100%25' height='100%25' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='100%25' height='100%25' fill='none' rx='9' ry='9' stroke='%23333' stroke-width='3' stroke-dasharray='6%2c 14' stroke-dashoffset='0' stroke-linecap='square'/%3e%3c/svg%3e");
        border-radius: 9px;
    }

    /* new navbar styling */
    /* overflow 1 */
    .column-v::-webkit-scrollbar {
        width: 0px;
        height: 0pc;
    }

    /* Track */
    .column-v::-webkit-scrollbar-track {
        background: transparent !important;
        border-radius: 10px;
    }

    /* Handle */
    .column-v::-webkit-scrollbar-thumb {
        background-clip: padding-box;
        background: #fff;
        border-radius: 10px;
        border: 1px rgb(46, 31, 131) solid;
    }

    /* Handle on hover */
    .column-v::-webkit-scrollbar-thumb:hover {
        background: #39AAFF;
        border-radius: 10px;
    }

    .hr-1 {
        opacity: 1 !important;
        height: 2.5px;
        background-color: #fff;
    }

    .log-out-div {
        /* position: fixed; */
        /* display: flex; */
        /* left: 30px !important; */
        bottom: 10px;
        left: 0;
        background-color: #0C71C3;
        /* width: 215px; */
    }

    .logg {
        position: relative;
        width: 100%;
    }

    .logg button {
        background-color: transparent;
        box-shadow: none !important;
        color: #fff !important;
        border-radius: 0;
        border: none;
        border-bottom: 1.5px #fff solid;
    }

    .column-v {
        /* max-width: 200px; */
        padding-left: 10px;
        display: block !important;
        height: 76vh;
        overflow-y: scroll;
        /* direction: rtl; */
        text-align: left !important;
        margin-left: 7px;
        text-overflow: ellipsis;
        white-space: nowrap;
        overflow-x: visible;
    }

    .nav-styling {
        /* max-width: 215px; */
        /* width: 100% !important; */
        height: 100vh !important;
        background-color: #0C71C3;
    }

    .nav-link {
        padding-top: 0.8rem;
        padding-bottom: 0.8rem;
        color: #fff !important;
        border-top-right-radius: 0px;
        border-top-left-radius: 10px;
        border-bottom-right-radius: 0px;
        border-bottom-left-radius: 10px;
        direction: initial;
    }

    /* .nav-link.active {
        color: #434343 !important;
        border-top-right-radius: 0px;
        border-top-left-radius: 10px;
        border-bottom-right-radius: 0px;
        border-bottom-left-radius: 10px;
    } */
    .nav-link:hover {
        background-color: #39AAFF !important;
        border-top-right-radius: 0px;
        border-top-left-radius: 10px;
        border-bottom-right-radius: 0px;
        border-bottom-left-radius: 10px;
    }

    .nav-link.activeClassNav__:hover {
        background-color: #fff !important;
        border-top-right-radius: 0px;
        border-top-left-radius: 10px;
        border-bottom-right-radius: 0px;
        border-bottom-left-radius: 10px;
    }

    .img-normal {
        display: block;
    }

    .img-collapsed {
        display: none
    }

    @import url('https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;1,100;1,200;1,300;1,400;1,500;1,600;1,700&family=Poppins:wght@200;800;900&display=swap');

    body {
        font-family: 'Montserrat', sans-serif;
    }

    @media (max-width: 991.98px) {
        .column-v {
            width: 80px;
            margin-left: 0;
            padding-left: 0;
        }

        .txt-dn {
            display: none;
        }

        .nav-link:hover .txt-dn {
            /* display: inline !important;
            justify-content: center;
            padding-top: 3px; */
            display: none;
            /* position: relative; */
        }

        .nav-link {
            text-align: center;
        }

        .log-out-div:hover .txt-dn {
            /* display: flex;
            justify-content: center;
            padding-top: 3px; */
            display: none;
            /* position: relative; */
            /* white-space: nowrap; */
        }

        .nav-styling {
            width: 80px;
        }

        .log-out-div {
            width: 80px;
        }

        .img-normal {
            display: none;
        }

        .img-collapsed {
            display: block;
        }
    }

    .desk-t {
        display: block;
    }

    .mobile-t {
        display: none;
    }

    @media (max-width: 575.98px) {
        .desk-t {
            display: none;
        }

        .mobile-t {
            display: block;
        }
    }
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.js"></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<script>
    $('input[type=radio][name=leasing]').change(function() {
        if (this.value == 'Ja') {
            $('#btnradio1').addClass('showpdf');
            $('#btnradio2 ').removeClass('showpdf');
        } else {
            $('#btnradio2').addClass('showpdf');
            $('#btnradio1').removeClass('showpdf');
        }
    });
    $('input[type=radio][name=repair_shop]').change(function() {
        if (this.value == 'Specific garage') {
            $('#btnradio1_').addClass('showpdf');
            $('#btnradio2_ ').removeClass('showpdf');
        } else {
            $('#btnradio2_').addClass('showpdf');
            $('#btnradio1_').removeClass('showpdf');
        }
    });
    $('input[type=radio][name=accident_coverage]').change(function() {
        if (this.value == 'Ja') {
            $('#btnradio3abcdef').addClass('showpdf');
            $('#btnradio4abcdef').removeClass('showpdf');
        } else {
            $('#btnradio4abcdef').addClass('showpdf');
            $('#btnradio3abcdef').removeClass('showpdf');
        }
    });
    $('input[type=radio][name=traffic_legal_protection]').change(function() {
        if (this.value == 'Ja') {
            $('#btnradio3a').addClass('showpdf');
            $('#btnradio4a ').removeClass('showpdf');
        } else {
            $('#btnradio4a').addClass('showpdf');
            $('#btnradio3a').removeClass('showpdf');
        }
    });
    $('input[type=radio][name=grossly]').change(function() {
        if (this.value == 'Ja') {
            $('#btnradio3ab').addClass('showpdf');
            $('#btnradio4ab ').removeClass('showpdf');
        } else {
            $('#btnradio4ab').addClass('showpdf');
            $('#btnradio3ab').removeClass('showpdf');
        }
    });
    $('input[type=radio][name=glass_protection]').change(function() {
        if (this.value == 'Ja') {
            $('#btnradio3abc').addClass('showpdf');
            $('#btnradio4abc ').removeClass('showpdf');
        } else {
            $('#btnradio4abc').addClass('showpdf');
            $('#btnradio3abc').removeClass('showpdf');
        }
    });
    $('input[type=radio][name=parking_damage]').change(function() {
        if (this.value == 'Ja') {
            $('#btnradio3abcd').addClass('showpdf');
            $('#btnradio4abcd ').removeClass('showpdf');
        } else {
            $('#btnradio4abcd').addClass('showpdf');
            $('#btnradio3abcd').removeClass('showpdf');
        }
    });
    $('input[type=radio][name=hour_breakdown_assistance]').change(function() {
        if (this.value == 'Ja') {
            $('#btnradio3abcde').addClass('showpdf');
            $('#btnradio4abcde ').removeClass('showpdf');
        } else {
            $('#btnradio4abcde').addClass('showpdf');
            $('#btnradio3abcde').removeClass('showpdf');
        }
    });
    var newgcnt = 0;
    var newncnt = 0;
    var cntt = 0;
    var cnttkranken = 0;
    var oferten = [];


    function upload(x) {
        var inputs = document.getElementsByClassName('showpdf');

        var fullPath = x.value;
        if (fullPath) {
            var startIndex = (fullPath.indexOf('\\') >= 0 ? fullPath.lastIndexOf('\\') : fullPath.lastIndexOf('/'));
            var filename = fullPath.substring(startIndex);
            if (filename.indexOf('\\') === 0 || filename.indexOf('/') === 0) {
                filename = filename.substring(1);
            }
            document.getElementById(x.id + 'c').value = filename;
        }
    }

    function addanother_item_g() {
        $("#add_g").remove();
        newgcnt++;
        $('#shtogegen').append('<div id="g'+newgcnt+'">'+
            '    <div class="text-end mb-2"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor"'+
            '            class="bi bi-x-circle" viewBox="0 0 16 16" style="cursor:pointer;" onclick="deletethat2(  newgcnt  )">'+
            '            <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />'+
            '            <path'+
            '                d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />'+
            '        </svg>'+
            '    </div>'+
            '    <hr style="height: 4px;">'+
            '    <div class="">'+
            '        <div class="">'+
            '            <span class="GrundversicherungSpans">'+
            '                Police Hochladen:'+
            '            </span>'+
            '        </div>'+
            '        <div class="">'+
            '            <div class="inputFileBG w-100 mt-2">'+
            '                <div class="my-2 p-4 text-center">'+
            '                    <label for="AutoUpload'+newgcnt+'">'+
            '                        <div class="mb-2">'+
            '                            <svg class="uploadSvgStyle" viewBox="0 0 23 23" fill="none"'+
            '                                xmlns="http://www.w3.org/2000/svg">'+
            '                                <path'+
            '                                    d="M21 14.6667V18.8889C21 19.4488 20.7776 19.9858 20.3817 20.3817C19.9858 20.7776 19.4488 21 18.8889 21H4.11111C3.55121 21 3.01424 20.7776 2.61833 20.3817C2.22242 19.9858 2 19.4488 2 18.8889V14.6667"'+
            '                                    stroke="#658BEB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />'+
            '                                <path d="M16.7777 7.27778L11.4999 2L6.22217 7.27778" stroke="#658BEB" stroke-width="3"'+
            '                                    stroke-linecap="round" stroke-linejoin="round" />'+
            '                                <path d="M11.5 2V14.6667" stroke="#658BEB" stroke-width="3" stroke-linecap="round"'+
            '                                    stroke-linejoin="round" />'+
            '                            </svg>'+
            '                        </div>'+
            '                        <div>'+
            '                            <span class="fileInputSecondTitle">Durchsuche</span>'+
            '                        </div>'+
            '                        <div>'+
            '                            <span class="fileInputFirstTitle">Laden Sie hier Ihre Dateien hoch</span>'+
            '                        </div>'+
            '                    </label>'+
            '                    <input type="file" id="AutoUpload'+newgcnt+'" name="upload_policeFahrzeug'+newgcnt+'" hidden'+
            '                        class="svg-div w-100 border-0  g-0" onchange="upload(this);">'+
            '                    <input type="text" class="form-control text-center" id="AutoUpload'+newgcnt+'c" disabled'+
            '                        style="background:transparent; border:none;">'+
            '                </div>'+
            '            </div>'+
            '        </div>'+
            '        <div class="mt-3">'+
            '            <div class="row g-0 ms-1">'+
            '                <div class="col-6 d-flex g-0 my-auto">'+
            '                    <div class="text-nowrap">'+
            '                        <span class="GrundversicherungSpans">'+
            '                            Vergleichsart:'+
            '                        </span>'+
            '                    </div>'+
            '                </div>'+
            '                <div class="col g-0 d-flex justify-content-end">'+
            '                    <div class="text-end">'+
            '                        <select name="vergleichsart_select'+newgcnt+'" class="form-control GrundversicherungInput"'+
            '                            id="">'+
            '                            <option selected>Auswählen</option>'+
            '                            <option value="1:0 Aktualisierung">1:0'+
            '                                Aktualisierung'+
            '                            </option>'+
            '                            <option value="0:1 Downgraden">0:1'+
            '                                Downgraden'+
            '                            </option>'+
            '                            <option value="1:1 Das Gleiche">1:1 Das'+
            '                                Gleiche'+
            '                            </option>'+
            '                        </select>'+
            '                    </div>'+
            '                </div>'+
            '            </div>'+
            '        </div>'+
            '        <div class="">'+
            '            <div class="mb-3 mt-3">'+
            '                <label for="exampleFormControlTextarea1" class="form-label GrundversicherungSpans">Kommentar</label>'+
            '                <textarea name="commentFahrenzug'+newgcnt+'" class="form-control GrundversicherungInput showpdf"'+
            '                    id="exampleFormControlTextarea1" rows="3"></textarea>'+
            '            </div>'+
            '        </div>'+
            '    </div>'+
            '    <div class="row g-0">'+
            '        @if(!Auth::user()->hasRole("fs"))'+
            '        <div class="col-12">'+
            '            <div class="GrundversicherungSpans">'+
            '                Neue Offer:'+
            '            </div>'+
            '            <div class="text-start">'+
            '                <div class="inputFileBG w-100 mt-2 mb-3 p-4">'+
            '                    <div class="mx-1 my-2 text-center">'+
            '                        <label for="AutoUploadNewOffer'+newgcnt+'">'+
            '                            <div class="mb-2">'+
            '                                <svg class="uploadSvgStyle" viewBox="0 0 23 23" fill="none"'+
            '                                    xmlns="http://www.w3.org/2000/svg">'+
            '                                    <path'+
            '                                        d="M21 14.6667V18.8889C21 19.4488 20.7776 19.9858 20.3817 20.3817C19.9858 20.7776 19.4488 21 18.8889 21H4.11111C3.55121 21 3.01424 20.7776 2.61833 20.3817C2.22242 19.9858 2 19.4488 2 18.8889V14.6667"'+
            '                                        stroke="#658BEB" stroke-width="3" stroke-linecap="round"'+
            '                                        stroke-linejoin="round" />'+
            '                                    <path d="M16.7777 7.27778L11.4999 2L6.22217 7.27778" stroke="#658BEB"'+
            '                                        stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />'+
            '                                    <path d="M11.5 2V14.6667" stroke="#658BEB" stroke-width="3" stroke-linecap="round"'+
            '                                        stroke-linejoin="round" />'+
            '                                </svg>'+
            '                            </div>'+
            '                            <div>'+
            '                                <span class="fileInputSecondTitle">Durchsuche</span>'+
            '                            </div>'+
            '                            <div>'+
            '                                <span class="fileInputFirstTitle">Laden Sie hier Ihre Dateien hoch</span>'+
            '                            </div>'+
            '                        </label>'+
            '                        <input type="file" id="AutoUploadNewOffer'+newgcnt+'" name="offer'+newgcnt+'" hidden'+
            '                            class="svg-div w-100 border-0  g-0" onchange="upload(this);">'+
            '                        <input type="text" class="form-control text-center" id="AutoUploadNewOffer'+newgcnt+'c" disabled'+
            '                            style="background:transparent; border:none;">'+
            '                    </div>'+
            '                </div>'+
            '            </div>'+
            '        </div>'+
            '    </div>'+
            '</div>'+
            '    @endif'+
            '    <div class="row g-0 justify-content-center">'+
            '        <div class="col-auto my-auto">'+
            '            <div class="d-inline text-center mt-3" id="add_g" onclick="addanother_item_g()">'+
            '                <svg xmlns="http://www.w3.org/2000/svg" width="48.694" viewBox="0 0 37.694 37.694"'+
            '                    style="cursor:pointer;">'+
            '                    <g id="Group_621" data-name="Group 621" transform="translate(-663.236 -976.679)">'+
            '                        <g id="Group_550" data-name="Group 550" transform="translate(663.236 976.679)">'+
            '                            <rect id="Rectangle_9" data-name="Rectangle 9" width="37.694" height="37.694" rx="18.847"'+
            '                                fill="#2F60DC" />'+
            '                            <g id="Group_42" data-name="Group 42" transform="translate(12.724 12.724)">'+
            '                                <line id="Line_11" data-name="Line 11" y2="11.972" transform="translate(5.986 0)"'+
            '                                    fill="none" stroke="#fff" stroke-linecap="round" stroke-width="2" />'+
            '                                <line id="Line_12" data-name="Line 12" x1="11.972" transform="translate(0 5.634)"'+
            '                                    fill="none" stroke="#fff" stroke-linecap="round" stroke-width="2" />'+
            '                            </g>'+
            '                        </g>'+
            '                    </g>'+
            '                </svg>'+
            '            </div>'+
            '        </div>'+
            '    </div>');

        document.getElementById('newgcount').value = newgcnt;
    }

    function addanother_item_n() {
        $('#add_n').remove();
        newncnt++;
        $('#shtonew').append('<div class="" id="n' + newncnt + '">' +
            ' <div class="text-end mb-2"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16" style="cursor:pointer;" onclick="deletethat(' + newncnt + ')">' +
            '<path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>' +
            '<path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/></svg></div>' +
            '                                                    <div class="row">'+
            '                                                        <div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6">'+
            '                                                            <div class="mb-3">'+
            '                                                                <div class="">'+
            '                                                                    <div class="">'+
            '                                                                            <span class="GrundversicherungSpans">'+
            '                                                                                Fahrzeugausweis hochladen'+
            '                                                                            </span>'+
            '                                                                    </div>'+
            '                                                                    <div class="inputFileBG w-100 mt-2">'+
            '                                                                        <div class="mx-1 my-2 p-4 text-center">'+
            '                                                                            <label for="AutoUploadNewFahrenzug' + newncnt + '">'+
            '                                                                                <div class="mb-2">'+
            '                                                                                    <svg class="uploadSvgStyle" viewBox="0 0 23 23" fill="none" xmlns="http://www.w3.org/2000/svg">'+
            '                                                                                        <path d="M21 14.6667V18.8889C21 19.4488 20.7776 19.9858 20.3817 20.3817C19.9858 20.7776 19.4488 21 18.8889 21H4.11111C3.55121 21 3.01424 20.7776 2.61833 20.3817C2.22242 19.9858 2 19.4488 2 18.8889V14.6667" stroke="#658BEB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />'+
            '                                                                                        <path d="M16.7777 7.27778L11.4999 2L6.22217 7.27778" stroke="#658BEB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />'+
            '                                                                                        <path d="M11.5 2V14.6667" stroke="#658BEB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />'+
            '                                                                                    </svg>'+
            '                                                                                </div>'+
            '                                                                                <div>'+
            '                                                                                        <span class="fileInputFirstTitle">Laden Sie hier Ihre Dateien hoch</span>'+
            '                                                                                </div>'+
            '                                                                                <div>'+
            '                                                                                    <span class="fileInputSecondTitle">Durchsuche</span>'+
            '                                                                                </div>'+
            '                                                                            </label>'+
            '                                                                            <input type="file" id="AutoUploadNewFahrenzug' + newncnt + '"'+
            '                                                                                   name="vehicle_id' + newncnt + '" hidden'+
            '                                                                                   class="svg-div w-100 border-0  g-0"'+
            '                                                                                   onchange="upload(this);">'+
            '                                                                            <input type="text"'+
            '                                                                                   class="form-control text-center"'+
            '                                                                                   id="AutoUploadNewFahrenzug' + newncnt + 'c"'+
            '                                                                                   disabled'+
            '                                                                                   style="background:transparent; border:none;">'+
            '                                                                        </div>'+
            '                                                                    </div>'+
            '                                                                </div>'+
            '                                                            </div>'+
            '                                                        </div>'+
            '                                                        <div class="col">'+
            '                                                            <div class="">'+
            '                                                                <div class="row g-0">'+
            '                                                                    <div class="col my-auto">'+
            '                                                                        <div class="">'+
            '                                                                                <span class="GrundversicherungSpans ">'+
            '                                                                                    Leasing:'+
            '                                                                                </span>'+
            '                                                                        </div>'+
            '                                                                    </div>'+
            '                                                                    <div class="col-auto">'+
            '                                                                        <div class="btn-group w-100" role="group" aria-label="Basic radio toggle button group">'+
            '                                                                            <input type="radio" class="btn-check showpdf" value="Ja" name="leasing' + newncnt + '" id="btnradio1' + newncnt + '" autocomplete="off" checked>'+
            '                                                                            <label onclick="yesBtnLeasingClicked(' + newncnt + ');" id="yesBtnLeasing' + newncnt + '" class="inFormYesNoBtn documentFormBtn px-0 me-1" value="Ja" for="btnradio1' + newncnt + '" onclick="showel(this)">Ja</label>'+
            '                                                                            <input type="radio" class="btn-check" name="leasing' + newncnt + '" value="Nein" id="btnradio2' + newncnt + '" autocomplete="off">'+
            '                                                                            <label onclick="noBtnLeasingClicked(' + newncnt + ');" id="noBtnLeasing' + newncnt + '" class="inFormYesNoBtn documentFormBtn px-0" for="btnradio2' + newncnt + '">Nein</label>'+
            '                                                                        </div>'+
            '                                                                    </div>'+
            '                                                                    <div class="row g-0 pt-3">'+
            '                                                                        <div class="col-12">'+
            '                                                                            <select name="leasing_name' + newncnt + '" class="w-100 form-control GrundversicherungInput" id="">'+
            '                                                                                <option value="Gesellschaft">'+
            '                                                                                    Gesellschaft'+
            '                                                                                </option>'+
            '                                                                            </select>'+
            '                                                                        </div>'+
            '                                                                    </div>'+
            '                                                                </div>'+
            '                                                            </div>'+
            '                                                        </div>'+
            '                                                    </div>'+
            '                                                    <div class="my-3">'+
            '                                                        <div class="row">'+
            '                                                            <div class="col">'+
            '                                                                <div class="">'+
            '                                                                    <div class="">'+
            '                                                                            <span class="ZusatzversicherungTitle">'+
            '                                                                                Fahrzeuginformationen'+
            '                                                                            </span>'+
            '                                                                    </div>'+
            '                                                                    <div class="input-select-div mb-2">'+
            '                                                                        <div class="text-nowrap">'+
            '                                                                                <span class="GrundversicherungSpans">'+
            '                                                                                    Kaufjahr'+
            '                                                                                </span>'+
            '                                                                        </div>'+
            '                                                                        <select name="year_of_purchase' + newncnt + '" class="GrundversicherungInput form-control showpdf" aria-label="Default select example" id="">'+
            '                                                                            <option selected></option>'+
            '                                                                            @for($i = \Carbon\Carbon::now()->format('Y'); $i >= 1950 ;$i--)'+
            '                                                                                <option value="{{$i}}">{{$i}}</option>'+
            '                                                                            @endfor'+
            '                                                                        </select>'+
            '                                                                    </div>'+
            '                                                                </div>'+
            '                                                                <div class="date-input-div mb-2">'+
            '                                                                    <div class="">'+
            '                                                                            <span class="GrundversicherungSpans">'+
            '                                                                                Este inverkehrssetzung:'+
            '                                                                            </span>'+
            '                                                                    </div>'+
            ''+
            '                                                                    <input name="first_intro' + newncnt + '" type="date" class="GrundversicherungInput form-control showpdf">'+
            ''+
            '                                                                </div>'+
            '                                                                <div class="date-input-div mb-2">'+
            '                                                                    <div class="">'+
            '                                                                            <span class="GrundversicherungSpans">'+
            '                                                                                Beginn Versicherung:'+
            '                                                                            </span>'+
            '                                                                    </div>'+
            ''+
            '                                                                    <input name="insurance_date' + newncnt + '" type="date" class="GrundversicherungInput form-control showpdf">'+
            ''+
            '                                                                </div>'+
            '                                                                <div class="mb-2">'+
            '                                                                    <div class="">'+
            '                                                                            <span class="GrundversicherungSpans">'+
            '                                                                                Eingelöster Kanton:'+
            '                                                                            </span>'+
            '                                                                    </div>'+
            '                                                                    <select name="redeemed' + newncnt + '" class="GrundversicherungInput form-control showpdf" aria-label="Default select example">'+
            '                                                                        <option selected></option>'+
            '                                                                        <option value="Zürich">Zürich</option>'+
            '                                                                        <option value="Bern">Bern</option>'+
            '                                                                        <option value="Luzern">Luzern</option>'+
            '                                                                        <option value="Uri">Uri</option>'+
            '                                                                        <option value="Schwyz">Schwyz</option>'+
            '                                                                        <option value="Obwalden">Obwalden</option>'+
            '                                                                        <option value="Nidwalden">Nidwalden</option>'+
            '                                                                        <option value="Glarus">Glarus</option>'+
            '                                                                        <option value="Zug">Zug</option>'+
            '                                                                        <option value="Freiburg">Freiburg</option>'+
            '                                                                        <option value="Solothurn">Solothurn</option>'+
            '                                                                        <option value="Basel-Stadt">Basel-Stadt'+
            '                                                                        </option>'+
            '                                                                        <option value="Basel-Landschaft">'+
            '                                                                            Basel-Landschaft'+
            '                                                                        </option>'+
            '                                                                        <option value="Schaffhausen">Schaffhausen'+
            '                                                                        </option>'+
            '                                                                        <option value="Appenzell A.Rh.">Appenzell'+
            '                                                                            A.Rh.'+
            '                                                                        </option>'+
            '                                                                        <option value="Appenzell I.Rh.">Appenzell'+
            '                                                                            I.Rh.'+
            '                                                                        </option>'+
            '                                                                        <option value="Sankt Gallen">Sankt Gallen'+
            '                                                                        </option>'+
            '                                                                        <option value="Graubünden">Graubünden'+
            '                                                                        </option>'+
            '                                                                        <option value="Aargau">Aargau</option>'+
            '                                                                        <option value="Thurgau">Thurgau</option>'+
            '                                                                        <option value="Tessin">Tessin</option>'+
            '                                                                        <option value="Waadt">Waadt</option>'+
            '                                                                        <option value="Wallis">Wallis</option>'+
            '                                                                        <option value="Neuenburg">Neuenburg</option>'+
            '                                                                        <option value="Genf">Genf</option>'+
            '                                                                        <option value="Jura">Jura</option>'+
            '                                                                    </select>'+
            '                                                                </div>'+
            '                                                                <div class="mb-2">'+
            '                                                                    <div class="">'+
            '                                                                            <span class="GrundversicherungSpans">'+
            '                                                                                KM - Stand:'+
            '                                                                            </span>'+
            '                                                                    </div>'+
            ''+
            '                                                                    <input name="km_stood' + newncnt + '" class="GrundversicherungInput form-control showpdf" type="number" id="">'+
            ''+
            '                                                                </div>'+
            '                                                            </div>'+
            '                                                            <div class="col">'+
            '                                                                <div class="">'+
            '                                                                    <div class="">'+
            '                                                                            <span class="ZusatzversicherungTitle">'+
            '                                                                                Lenkerinformation'+
            '                                                                            </span>'+
            '                                                                    </div>'+
            '                                                                </div>'+
            '                                                                <div class="date-input-div mb-2">'+
            '                                                                    <div class="">'+
            '                                                                            <span class="GrundversicherungSpans">'+
            '                                                                                Ausstelldatum Fuhrerausweis:'+
            '                                                                            </span>'+
            '                                                                    </div>'+
            ''+
            '                                                                    <input name="placing_on_the_market' + newncnt + '" type="date" class="GrundversicherungInput form-control showpdf">'+
            ''+
            '                                                                </div>'+
            '                                                                <div class=" mb-2">'+
            '                                                                    <div class="">'+
            '                                                                            <span class="GrundversicherungSpans">'+
            '                                                                                Nationalität:'+
            '                                                                            </span>'+
            '                                                                    </div>'+
            '                                                                    <select class="GrundversicherungInput form-control showpdf" name="nationality' + newncnt + '">'+
            '                                                                        <option value="Swiss">Swiss</option>'+
            '                                                                        <option value="Deutschland">Deutschland'+
            '                                                                        </option>'+
            '                                                                        <option value="Italien">Italien</option>'+
            '                                                                        <option value="French">French</option>'+
            '                                                                        <optgroup label="A">'+
            '                                                                            <option value="Afghanistan">'+
            '                                                                                Afghanistan'+
            '                                                                            </option>'+
            '                                                                            <option value="Ägypten">Ägypten</option>'+
            '                                                                            <option value="Åland">Åland</option>'+
            '                                                                            <option value="Albanien">Albanien'+
            '                                                                            </option>'+
            '                                                                            <option value="Algerien">Algerien'+
            '                                                                            </option>'+
            '                                                                            <option value="Amerikanisch-Samoa">'+
            '                                                                                Amerikanisch-Samoa'+
            '                                                                            </option>'+
            '                                                                            <option value="Amerikanische Jungferninseln">'+
            '                                                                                Amerikanische Jungferninseln'+
            '                                                                            </option>'+
            '                                                                            <option value="Andorra">Andorra</option>'+
            '                                                                            <option value="Angola">Angola</option>'+
            '                                                                            <option value="Anguilla">Anguilla'+
            '                                                                            </option>'+
            '                                                                            <option value="Antarktis">Antarktis'+
            '                                                                            </option>'+
            '                                                                            <option value="Antigua und Barbuda">'+
            '                                                                                Antigua und Barbuda'+
            '                                                                            </option>'+
            '                                                                            <option value="Äquatorialguinea">'+
            '                                                                                Äquatorialguinea'+
            '                                                                            </option>'+
            '                                                                            <option value="Argentinien">'+
            '                                                                                Argentinien'+
            '                                                                            </option>'+
            '                                                                            <option value="Armenien">Armenien'+
            '                                                                            </option>'+
            '                                                                            <option value="Aruba">Aruba</option>'+
            '                                                                            <option value="Ascension">Ascension'+
            '                                                                            </option>'+
            '                                                                            <option value="Aserbaidschan">'+
            '                                                                                Aserbaidschan'+
            '                                                                            </option>'+
            '                                                                            <option value="Äthiopien">Äthiopien'+
            '                                                                            </option>'+
            '                                                                            <option value="Australien">Australien'+
            '                                                                            </option>'+
            '                                                                        </optgroup>'+
            '                                                                        <optgroup label="B">'+
            '                                                                            <option value="Bahamas">Bahamas</option>'+
            '                                                                            <option value="Bahrain">Bahrain</option>'+
            '                                                                            <option value="Bangladesch">'+
            '                                                                                Bangladesch'+
            '                                                                            </option>'+
            '                                                                            <option value="Barbados">Barbados'+
            '                                                                            </option>'+
            '                                                                            <option value="Belarus">Belarus</option>'+
            '                                                                            <option value="Belgien">Belgien</option>'+
            '                                                                            <option value="Belize">Belize</option>'+
            '                                                                            <option value="Benin">Benin</option>'+
            '                                                                            <option value="Bermuda">Bermuda</option>'+
            '                                                                            <option value="Bhutan">Bhutan</option>'+
            '                                                                            <option value="Bolivien">Bolivien'+
            '                                                                            </option>'+
            '                                                                            <option value="Bosnien und Herzegowina">'+
            '                                                                                Bosnien und Herzegowina'+
            '                                                                            </option>'+
            '                                                                            <option value="Botswana">Botswana'+
            '                                                                            </option>'+
            '                                                                            <option value="Bouvetinsel">'+
            '                                                                                Bouvetinsel'+
            '                                                                            </option>'+
            '                                                                            <option value="Brasilien">Brasilien'+
            '                                                                            </option>'+
            '                                                                            <option value="Britische Jungferninseln">'+
            '                                                                                Britische Jungferninseln'+
            '                                                                            </option>'+
            '                                                                            <option value="Britisches Territorium im Indischen Ozean">'+
            '                                                                                Britisches Territorium im Indischen'+
            '                                                                                Ozean'+
            '                                                                            </option>'+
            '                                                                            <option value="Brunei Darussalam">Brunei'+
            '                                                                                Darussalam'+
            '                                                                            </option>'+
            '                                                                            <option value="Bulgarien">Bulgarien'+
            '                                                                            </option>'+
            '                                                                            <option value="Burkina Faso">Burkina'+
            '                                                                                Faso'+
            '                                                                            </option>'+
            '                                                                            <option value="Burundi">Burundi</option>'+
            '                                                                        </optgroup>'+
            '                                                                        <optgroup label="C">'+
            '                                                                            <option value="Ceuta, Melilla">Ceuta,'+
            '                                                                                Melilla'+
            '                                                                            </option>'+
            '                                                                            <option value="Chile">Chile</option>'+
            '                                                                            <option value="Volksrepublik China">'+
            '                                                                                Volksrepublik China'+
            '                                                                            </option>'+
            '                                                                            <option value="Clipperton">Clipperton'+
            '                                                                            </option>'+
            '                                                                            <option value="Cookinseln">Cookinseln'+
            '                                                                            </option>'+
            '                                                                            <option value="Costa Rica">Costa Rica'+
            '                                                                            </option>'+
            '                                                                            <option value="Côte dIvoire">Côte'+
            '                                                                                dIvoire'+
            '                                                                            </option>'+
            '                                                                        </optgroup>'+
            '                                                                        <optgroup label="D">'+
            '                                                                            <option value="Dänemark">Dänemark'+
            '                                                                            </option>'+
            '                                                                            <option value="Deutschland">'+
            '                                                                                Deutschland'+
            '                                                                            </option>'+
            '                                                                            <option value="Diego Garcia">Diego'+
            '                                                                                Garcia'+
            '                                                                            </option>'+
            '                                                                            <option value="Dominica">Dominica'+
            '                                                                            </option>'+
            '                                                                            <option value="Dominikanische Republik">'+
            '                                                                                Dominikanische Republik'+
            '                                                                            </option>'+
            '                                                                            <option value="Dschibuti">Dschibuti'+
            '                                                                            </option>'+
            '                                                                        </optgroup>'+
            '                                                                        <optgroup label="E">'+
            '                                                                            <option value="Ecuador">Ecuador</option>'+
            '                                                                            <option value="El Salvador">El'+
            '                                                                                Salvador'+
            '                                                                            </option>'+
            '                                                                            <option value="Eritrea">Eritrea</option>'+
            '                                                                            <option value="Estland">Estland</option>'+
            '                                                                        </optgroup>'+
            '                                                                        <optgroup label="F">'+
            '                                                                            <option value="Falklandinseln">'+
            '                                                                                Falklandinseln'+
            '                                                                            </option>'+
            '                                                                            <option value="Färöer">Färöer</option>'+
            '                                                                            <option value="Fidschi">Fidschi</option>'+
            '                                                                            <option value="Finnland">Finnland'+
            '                                                                            </option>'+
            '                                                                            <option value="Frankreich">Frankreich'+
            '                                                                            </option>'+
            '                                                                            <option value="Französisch-Guayana">'+
            '                                                                                Französisch-Guayana'+
            '                                                                            </option>'+
            '                                                                            <option value="Französisch-Polynesien">'+
            '                                                                                Französisch-Polynesien'+
            '                                                                            </option>'+
            '                                                                        </optgroup>'+
            '                                                                        <optgroup label="G">'+
            '                                                                            <option value="Gabun">Gabun</option>'+
            '                                                                            <option value="Gambia">Gambia</option>'+
            '                                                                            <option value="Georgien">Georgien'+
            '                                                                            </option>'+
            '                                                                            <option value="Ghana">Ghana</option>'+
            '                                                                            <option value="Gibraltar">Gibraltar'+
            '                                                                            </option>'+
            '                                                                            <option value="Grenada">Grenada</option>'+
            '                                                                            <option value="Griechenland">'+
            '                                                                                Griechenland'+
            '                                                                            </option>'+
            '                                                                            <option value="Grönland">Grönland'+
            '                                                                            </option>'+
            '                                                                            <option value="Großbritannien">'+
            '                                                                                Großbritannien'+
            '                                                                            </option>'+
            '                                                                            <option value="Guadeloupe">Guadeloupe'+
            '                                                                            </option>'+
            '                                                                            <option value="Guam">Guam</option>'+
            '                                                                            <option value="Guatemala">Guatemala'+
            '                                                                            </option>'+
            '                                                                            <option value="Guernsey (Kanalinsel)">'+
            '                                                                                Guernsey (Kanalinsel)'+
            '                                                                            </option>'+
            '                                                                            <option value="Guinea">Guinea</option>'+
            '                                                                            <option value="Guinea-Bissau">'+
            '                                                                                Guinea-Bissau'+
            '                                                                            </option>'+
            '                                                                            <option value="Guyana">Guyana</option>'+
            '                                                                        </optgroup>'+
            '                                                                        <optgroup label="H">'+
            '                                                                            <option value="Haiti">Haiti</option>'+
            '                                                                            <option value="Heard- und McDonald-Inseln">'+
            '                                                                                Heard- und McDonald-Inseln'+
            '                                                                            </option>'+
            '                                                                            <option value="Honduras">Honduras'+
            '                                                                            </option>'+
            '                                                                            <option value="Hongkong">Hongkong'+
            '                                                                            </option>'+
            '                                                                        </optgroup>'+
            '                                                                        <optgroup label="I">'+
            '                                                                            <option value="Indien">Indien</option>'+
            '                                                                            <option value="Indonesien">Indonesien'+
            '                                                                            </option>'+
            '                                                                            <option value="Insel Man">Insel Man'+
            '                                                                            </option>'+
            '                                                                            <option value="Irak">Irak</option>'+
            '                                                                            <option value="Iran">Iran</option>'+
            '                                                                            <option value="Irland">Irland</option>'+
            '                                                                            <option value="Island">Island</option>'+
            '                                                                            <option value="Israel">Israel</option>'+
            '                                                                            <option value="Italien">Italien</option>'+
            '                                                                        </optgroup>'+
            '                                                                        <optgroup label="J">'+
            '                                                                            <option value="Jamaika">Jamaika</option>'+
            '                                                                            <option value="Japan">Japan</option>'+
            '                                                                            <option value="Jemen">Jemen</option>'+
            '                                                                            <option value="Jersey (Kanalinsel)">'+
            '                                                                                Jersey (Kanalinsel)'+
            '                                                                            </option>'+
            '                                                                            <option value="Jordanien">Jordanien'+
            '                                                                            </option>'+
            '                                                                        </optgroup>'+
            '                                                                        <optgroup label="K">'+
            '                                                                            <option value="Kaimaninseln">'+
            '                                                                                Kaimaninseln'+
            '                                                                            </option>'+
            '                                                                            <option value="Kambodscha">Kambodscha'+
            '                                                                            </option>'+
            '                                                                            <option value="Kamerun">Kamerun</option>'+
            '                                                                            <option value="Kanada">Kanada</option>'+
            '                                                                            <option value="Kanarische Inseln">'+
            '                                                                                Kanarische Inseln'+
            '                                                                            </option>'+
            '                                                                            <option value="Kap Verde">Kap Verde'+
            '                                                                            </option>'+
            '                                                                            <option value="Kasachstan">Kasachstan'+
            '                                                                            </option>'+
            '                                                                            <option value="Katar">Katar</option>'+
            '                                                                            <option value="Kenia">Kenia</option>'+
            '                                                                            <option value="Kirgisistan">'+
            '                                                                                Kirgisistan'+
            '                                                                            </option>'+
            '                                                                            <option value="Kiribati">Kiribati'+
            '                                                                            </option>'+
            '                                                                            <option value="Kokosinseln">'+
            '                                                                                Kokosinseln'+
            '                                                                            </option>'+
            '                                                                            <option value="Kolumbien">Kolumbien'+
            '                                                                            </option>'+
            '                                                                            <option value="Komoren">Komoren</option>'+
            '                                                                            <option value="Demokratische Republik Kongo">'+
            '                                                                                Demokratische Republik Kongo'+
            '                                                                            </option>'+
            '                                                                            <option value="Demokratische Volksrepublik Korea (Nordkorea)">'+
            '                                                                                Demokratische Volksrepublik Korea'+
            '                                                                                (Nordkorea)'+
            '                                                                            </option>'+
            '                                                                            <option value="Republik Korea (Südkorea)">'+
            '                                                                                Republik Korea (Südkorea)'+
            '                                                                            </option>'+
            '                                                                            <option value="Kosovo">Kosovo</option>'+
            '                                                                            <option value="Kroatien">Kroatien'+
            '                                                                            </option>'+
            '                                                                            <option value="Kuba">Kuba</option>'+
            '                                                                            <option value="Kuwait">Kuwait</option>'+
            '                                                                        </optgroup>'+
            '                                                                        <optgroup label="L">'+
            '                                                                            <option value="Laos">Laos</option>'+
            '                                                                            <option value="Lesotho">Lesotho</option>'+
            '                                                                            <option value="Lettland">Lettland'+
            '                                                                            </option>'+
            '                                                                            <option value="Libanon">Libanon</option>'+
            '                                                                            <option value="Liberia">Liberia</option>'+
            '                                                                            <option value="Libyen">Libyen</option>'+
            '                                                                            <option value="Liechtenstein">'+
            '                                                                                Liechtenstein'+
            '                                                                            </option>'+
            '                                                                            <option value="Litauen">Litauen</option>'+
            '                                                                            <option value="Luxemburg">Luxemburg'+
            '                                                                            </option>'+
            '                                                                        </optgroup>'+
            '                                                                        <optgroup label="M">'+
            '                                                                            <option value="Macao">Macao</option>'+
            '                                                                            <option value="Madagaskar">Madagaskar'+
            '                                                                            </option>'+
            '                                                                            <option value="Malawi">Malawi</option>'+
            '                                                                            <option value="Malaysia">Malaysia'+
            '                                                                            </option>'+
            '                                                                            <option value="Malediven">Malediven'+
            '                                                                            </option>'+
            '                                                                            <option value="Mali">Mali</option>'+
            '                                                                            <option value="Malta">Malta</option>'+
            '                                                                            <option value="Marokko">Marokko</option>'+
            '                                                                            <option value="Marshallinseln">'+
            '                                                                                Marshallinseln'+
            '                                                                            </option>'+
            '                                                                            <option value="Martinique">Martinique'+
            '                                                                            </option>'+
            '                                                                            <option value="Mauretanien">'+
            '                                                                                Mauretanien'+
            '                                                                            </option>'+
            '                                                                            <option value="Mauritius">Mauritius'+
            '                                                                            </option>'+
            '                                                                            <option value="Mayotte">Mayotte</option>'+
            '                                                                            <option value="Mazedonien">Mazedonien'+
            '                                                                            </option>'+
            '                                                                            <option value="Mexiko">Mexiko</option>'+
            '                                                                            <option value="Mikronesien">'+
            '                                                                                Mikronesien'+
            '                                                                            </option>'+
            '                                                                            <option value="Moldawien (Republik Moldau)">'+
            '                                                                                Moldawien (Republik Moldau)'+
            '                                                                            </option>'+
            '                                                                            <option value="Monaco">Monaco</option>'+
            '                                                                            <option value="Mongolei">Mongolei'+
            '                                                                            </option>'+
            '                                                                            <option value="Montenegro">Montenegro'+
            '                                                                            </option>'+
            '                                                                            <option value="Montserrat">Montserrat'+
            '                                                                            </option>'+
            '                                                                            <option value="Mosambik">Mosambik'+
            '                                                                            </option>'+
            '                                                                            <option value="Myanmar">Myanmar'+
            '                                                                                (Burma)'+
            '                                                                            </option>'+
            '                                                                        </optgroup>'+
            '                                                                        <optgroup label="N">'+
            '                                                                            <option value="Namibia">Namibia</option>'+
            '                                                                            <option value="Nauru">Nauru</option>'+
            '                                                                            <option value="Nepal">Nepal</option>'+
            '                                                                            <option value="Neukaledonien">'+
            '                                                                                Neukaledonien'+
            '                                                                            </option>'+
            '                                                                            <option value="Neuseeland">Neuseeland'+
            '                                                                            </option>'+
            '                                                                            <option value="Nicaragua">Nicaragua'+
            '                                                                            </option>'+
            '                                                                            <option value="Niederlande">'+
            '                                                                                Niederlande'+
            '                                                                            </option>'+
            '                                                                            <option value="Niederländische Antillen">'+
            '                                                                                Niederländische Antillen'+
            '                                                                            </option>'+
            '                                                                            <option value="Niger">Niger</option>'+
            '                                                                            <option value="Nigeria">Nigeria</option>'+
            '                                                                            <option value="Niue">Niue</option>'+
            '                                                                            <option value="Nördliche Marianen">'+
            '                                                                                Nördliche Marianen'+
            '                                                                            </option>'+
            '                                                                            <option value="Norfolkinsel">'+
            '                                                                                Norfolkinsel'+
            '                                                                            </option>'+
            '                                                                            <option value="Norwegen">Norwegen'+
            '                                                                            </option>'+
            '                                                                        </optgroup>'+
            '                                                                        <optgroup label="O">'+
            '                                                                            <option value="Oman">Oman</option>'+
            '                                                                            <option value="Orbit">Orbit</option>'+
            '                                                                            <option value="Österreich">Österreich'+
            '                                                                            </option>'+
            '                                                                            <option value="Osttimor (Timor-Leste)">'+
            '                                                                                Osttimor (Timor-Leste)'+
            '                                                                            </option>'+
            '                                                                        </optgroup>'+
            '                                                                        <optgroup label="P">'+
            '                                                                            <option value="Pakistan">Pakistan'+
            '                                                                            </option>'+
            '                                                                            <option value="Palästinensische Autonomiegebiete">'+
            '                                                                                Palästinensische Autonomiegebiete'+
            '                                                                            </option>'+
            '                                                                            <option value="Palau">Palau</option>'+
            '                                                                            <option value="Panama">Panama</option>'+
            '                                                                            <option value="Papua-Neuguinea">'+
            '                                                                                Papua-Neuguinea'+
            '                                                                            </option>'+
            '                                                                            <option value="Paraguay">Paraguay'+
            '                                                                            </option>'+
            '                                                                            <option value="Peru">Peru</option>'+
            '                                                                            <option value="Philippinen">'+
            '                                                                                Philippinen'+
            '                                                                            </option>'+
            '                                                                            <option value="Pitcairninseln">'+
            '                                                                                Pitcairninseln'+
            '                                                                            </option>'+
            '                                                                            <option value="Polen">Polen</option>'+
            '                                                                            <option value="Portugal">Portugal'+
            '                                                                            </option>'+
            '                                                                            <option value="Puerto Rico">Puerto'+
            '                                                                                Rico'+
            '                                                                            </option>'+
            '                                                                        </optgroup>'+
            '                                                                        <optgroup label="R">'+
            '                                                                            <option value="Republik China (Taiwan)">'+
            '                                                                                Republik China (Taiwan)'+
            '                                                                            </option>'+
            '                                                                            <option value="Republik Kongo">Republik'+
            '                                                                                Kongo'+
            '                                                                            </option>'+
            '                                                                            <option value="Réunion">Réunion</option>'+
            '                                                                            <option value="Ruanda">Ruanda</option>'+
            '                                                                            <option value="Rumänien">Rumänien'+
            '                                                                            </option>'+
            '                                                                            <option value="Russische Föderation">'+
            '                                                                                Russische Föderation'+
            '                                                                            </option>'+
            '                                                                        </optgroup>'+
            '                                                                        <optgroup label="S">'+
            '                                                                            <option value="Saint-Barthélemy">'+
            '                                                                                Saint-Barthélemy'+
            '                                                                            </option>'+
            '                                                                            <option value="Saint-Martin">'+
            '                                                                                Saint-Martin'+
            '                                                                            </option>'+
            '                                                                            <option value="Salomonen">Salomonen'+
            '                                                                            </option>'+
            '                                                                            <option value="Sambia">Sambia</option>'+
            '                                                                            <option value="Samoa">Samoa</option>'+
            '                                                                            <option value="San Marino">San Marino'+
            '                                                                            </option>'+
            '                                                                            <option value="São Tomé und Príncipe">'+
            '                                                                                São Tomé und Príncipe'+
            '                                                                            </option>'+
            '                                                                            <option value="Saudi-Arabien">'+
            '                                                                                Saudi-Arabien'+
            '                                                                            </option>'+
            '                                                                            <option value="Schweden">Schweden'+
            '                                                                            </option>'+
            '                                                                            <option value="Schweiz">Schweiz</option>'+
            '                                                                            <option value="Senegal">Senegal</option>'+
            '                                                                            <option value="Serbien">Serbien</option>'+
            '                                                                            <option value="Seychellen">Seychellen'+
            '                                                                            </option>'+
            '                                                                            <option value="Sierra Leone">Sierra'+
            '                                                                                Leone'+
            '                                                                            </option>'+
            '                                                                            <option value="Simbabwe">Simbabwe'+
            '                                                                            </option>'+
            '                                                                            <option value="Singapur">Singapur'+
            '                                                                            </option>'+
            '                                                                            <option value="Slowakei">Slowakei'+
            '                                                                            </option>'+
            '                                                                            <option value="Slowenien">Slowenien'+
            '                                                                            </option>'+
            '                                                                            <option value="Somalia">Somalia</option>'+
            '                                                                            <option value="Spanien">Spanien</option>'+
            '                                                                            <option value="Sri Lanka">Sri Lanka'+
            '                                                                            </option>'+
            '                                                                            <option value="St. Helena">St. Helena'+
            '                                                                            </option>'+
            '                                                                            <option value="St. Kitts und Nevis">St.'+
            '                                                                                Kitts und Nevis'+
            '                                                                            </option>'+
            '                                                                            <option value="St. Lucia">St. Lucia'+
            '                                                                            </option>'+
            '                                                                            <option value="Saint-Pierre und Miquelon">'+
            '                                                                                Saint-Pierre und Miquelon'+
            '                                                                            </option>'+
            '                                                                            <option value="St. Vincent und die Grenadinen">'+
            '                                                                                St. Vincent und die Grenadinen'+
            '                                                                            </option>'+
            '                                                                            <option value="Südafrika">Südafrika'+
            '                                                                            </option>'+
            '                                                                            <option value="Sudan">Sudan</option>'+
            '                                                                            <option value="Südgeorgien und die Südlichen Sandwichinseln">'+
            '                                                                                Südgeorgien und die Südlichen'+
            '                                                                                Sandwichinseln'+
            '                                                                            </option>'+
            '                                                                            <option value="Suriname">Suriname'+
            '                                                                            </option>'+
            '                                                                            <option value="Svalbard und Jan Mayen">'+
            '                                                                                Svalbard und Jan Mayen'+
            '                                                                            </option>'+
            '                                                                            <option value="Swasiland">Swasiland'+
            '                                                                            </option>'+
            '                                                                            <option value="Syrien">Syrien</option>'+
            '                                                                        </optgroup>'+
            '                                                                        <optgroup label="T">'+
            '                                                                            <option value="Tadschikistan">'+
            '                                                                                Tadschikistan'+
            '                                                                            </option>'+
            '                                                                            <option value="Tansania">Tansania'+
            '                                                                            </option>'+
            '                                                                            <option value="Thailand">Thailand'+
            '                                                                            </option>'+
            '                                                                            <option value="Togo">Togo</option>'+
            '                                                                            <option value="Tokelau">Tokelau</option>'+
            '                                                                            <option value="Tonga">Tonga</option>'+
            '                                                                            <option value="Trinidad und Tobago">'+
            '                                                                                Trinidad und Tobago'+
            '                                                                            </option>'+
            '                                                                            <option value="Tristan da Cunha">Tristan'+
            '                                                                                da Cunha'+
            '                                                                            </option>'+
            '                                                                            <option value="Tschad">Tschad</option>'+
            '                                                                            <option value="Tschechische Republik">'+
            '                                                                                Tschechische Republik'+
            '                                                                            </option>'+
            '                                                                            <option value="Tunesien">Tunesien'+
            '                                                                            </option>'+
            '                                                                            <option value="Türkei">Türkei</option>'+
            '                                                                            <option value="Turkmenistan">'+
            '                                                                                Turkmenistan'+
            '                                                                            </option>'+
            '                                                                            <option value="Turks- und Caicosinseln">'+
            '                                                                                Turks- und Caicosinseln'+
            '                                                                            </option>'+
            '                                                                            <option value="Tuvalu">Tuvalu</option>'+
            '                                                                        </optgroup>'+
            '                                                                        <optgroup label="U">'+
            '                                                                            <option value="Uganda">Uganda</option>'+
            '                                                                            <option value="Ukraine">Ukraine</option>'+
            '                                                                            <option value="Ungarn">Ungarn</option>'+
            '                                                                            <option value="Uruguay">Uruguay</option>'+
            '                                                                            <option value="Usbekistan">Usbekistan'+
            '                                                                            </option>'+
            '                                                                        </optgroup>'+
            '                                                                        <optgroup label="V">'+
            '                                                                            <option value="Vanuatu">Vanuatu</option>'+
            '                                                                            <option value="Vatikanstadt">'+
            '                                                                                Vatikanstadt'+
            '                                                                            </option>'+
            '                                                                            <option value="Venezuela">Venezuela'+
            '                                                                            </option>'+
            '                                                                            <option value="Vereinigte Arabische Emirate">'+
            '                                                                                Vereinigte Arabische Emirate'+
            '                                                                            </option>'+
            '                                                                            <option value="Vereinigte Staaten von Amerika (USA)">'+
            '                                                                                Vereinigte Staaten von Amerika (USA)'+
            '                                                                            </option>'+
            '                                                                            <option value="Vereinigtes Königreich Großbritannien und Nordirland">'+
            '                                                                                Vereinigtes Königreich'+
            '                                                                                Großbritannien und Nordirland'+
            '                                                                            </option>'+
            '                                                                            <option value="Vietnam">Vietnam</option>'+
            '                                                                        </optgroup>'+
            '                                                                        <optgroup label="W">'+
            '                                                                            <option value="Wallis und Futuna">Wallis'+
            '                                                                                und Futuna'+
            '                                                                            </option>'+
            '                                                                            <option value="Weihnachtsinsel">'+
            '                                                                                Weihnachtsinsel'+
            '                                                                            </option>'+
            '                                                                            <option value="Westsahara">Westsahara'+
            '                                                                            </option>'+
            '                                                                        </optgroup>'+
            '                                                                        <optgroup label="Z">'+
            '                                                                            <option value="Zentralafrikanische Republik">'+
            '                                                                                Zentralafrikanische Republik'+
            '                                                                            </option>'+
            '                                                                            <option value="Zypern">Zypern</option>'+
            '                                                                        </optgroup>'+
            '                                                                    </select>'+
            '                                                                </div>'+
            '                                                                <div class="mb-2">'+
            '                                                                    <div class="">'+
            '                                                                            <span class="GrundversicherungSpans">'+
            '                                                                                Häufigster Lenker?'+
            '                                                                            </span>'+
            '                                                                    </div>'+
            '                                                                    <select name="most_common' + newncnt + '" class="GrundversicherungInput form-control showpdf" aria-label="Default select example">'+
            '                                                                        <option selected></option>'+
            '                                                                        <option value="Ja">Ja</option>'+
            '                                                                        <option value="Nein">Nein</option>'+
            ''+
            '                                                                    </select>'+
            '                                                                </div>'+
            '                                                            </div>'+
            '                                                        </div>'+
            '                                                    </div>'+
            '                                                    <div class="my-3">'+
            '                                                        <div class="row">'+
            '                                                            <div class="col">'+
            '                                                                <div class="">'+
            '                                                                        <span class="ZusatzversicherungTitle">'+
            '                                                                            Gewünschte Deckung'+
            '                                                                        </span>'+
            '                                                                </div>'+
            '                                                                <div class=" mb-2">'+
            '                                                                    <div class="">'+
            '                                                                            <span class="GrundversicherungSpans">'+
            '                                                                                Versischerung:'+
            '                                                                            </span>'+
            '                                                                    </div>'+
            '                                                                    <select name="insurance' + newncnt + '" class="GrundversicherungInput form-control showpdf" aria-label="Default select example">'+
            '                                                                        <option selected></option>'+
            '                                                                        <option value="Haftpflicht">Haftpflicht'+
            '                                                                        </option>'+
            '                                                                        <option value="Teilkasko">Teilkasko</option>'+
            '                                                                        <option value="Vollkasko">Vollkasko</option>'+
            '                                                                    </select>'+
            ''+
            '                                                                </div>'+
            '                                                                <div class=" mb-2">'+
            '                                                                    <div class="">'+
            '                                                                            <span class="GrundversicherungSpans">'+
            '                                                                                Selbstbehalt Teilkasko:'+
            '                                                                            </span>'+
            '                                                                    </div>'+
            '                                                                    <select name="deductible' + newncnt + '" class="GrundversicherungInput form-control showpdf" aria-label="Default select example">'+
            ''+
            '                                                                        <option selected></option>'+
            '                                                                        <option value="500">500</option>'+
            '                                                                        <option value="1000">1000</option>'+
            '                                                                        <option value="1500">1500</option>'+
            '                                                                        <option value="2000">2000</option>'+
            '                                                                    </select>'+
            '                                                                </div>'+
            '                                                                <div class="mb-2">'+
            '                                                                    <div class="">'+
            '                                                                            <span class="GrundversicherungSpans">'+
            '                                                                                Mitgeführte Sachen:'+
            '                                                                            </span>'+
            '                                                                    </div>'+
            '                                                                    <select name="carried' + newncnt + '" class="GrundversicherungInput form-control showpdf" aria-label="Default select example">'+
            '                                                                        <option selected></option>'+
            '                                                                        @for($i=1000;$i<=20000;$i+=1000)'+
            '																			 <option value="{{$i}}">{{$i}}</option>'+
            '                                                                        @endfor'+
            '                                                                    </select>'+
            '                                                                </div>'+
            '                                                                <div class="">'+
            '                                                                        <span class="GrundversicherungSpans">'+
            '                                                                            Reparaturwerkstatt:'+
            '                                                                        </span>'+
            '                                                                    <!-- <div class="input-group mb-2">'+
            '                                                                  <input name="noname" type="text" placeholder="Partnergarage" class="form-control" aria-label=""'+
            '                                                                    aria-describedby="basic-addon1">'+
            '                                                                  <input name="noname" type="text" placeholder="Freie Wahl" class="form-control" aria-label=""'+
            '                                                                    aria-describedby="basic-addon1">'+
            '                                                                </div> -->'+
            '                                                                    <div class="row g-0 justify-content-start" role="group" aria-label="Basic radio toggle button group">'+
            '                                                                        <div class="col-6 pe-1">'+
            '                                                                            <input type="radio" class="btn-check showpdf " name="repair_shop' + newncnt + '" id="btnradio1_' + newncnt + '" value="Specific garage" checked>'+
            '                                                                            <label onclick="yesBtnGarageClicked('+newncnt+');" id="yesBtnGarage'+newncnt+'" class="inFormYesNoBtn documentFormBtn w-100 fs-6" for="btnradio1_' + newncnt + '">Specific'+
            '                                                                                garage</label>'+
            '                                                                        </div>'+
            '                                                                        <div class="col-6 my-auto">'+
            '                                                                            <input type="radio" class="btn-check " name="repair_shop' + newncnt + '" value="Freie Wahl" id="btnradio2_' + newncnt + '">'+
            '                                                                            <label onclick="noBtnGarageClicked('+newncnt+');" id="noBtnGarage'+newncnt+'" class="inFormYesNoBtn documentFormBtn w-100 fs-6" for="btnradio2_' + newncnt + '">Freie Wahl</label>'+
            '                                                                        </div>'+
            '                                                                    </div>'+
            '                                                                </div>'+
            '                                                                <div class="input-div1 mb-2">'+
            '                                                                    <div class="">'+
            '                                                                            <span class="GrundversicherungSpans">'+
            '                                                                                + Unfalldeckung:'+
            '                                                                            </span>'+
            '                                                                    </div>'+
            '                                                                    <div class="btn-group" role="group" aria-label="Basic radio toggle button group">'+
            '                                                                        <input type="radio" class="btn-check showpdf" name="accident_coverage' + newncnt + '" value="Ja" id="btnradio3abcdef' + newncnt + '" autocomplete="off" checked>'+
            '                                                                        <label onclick="yesBtnUnfalldeckungClicked('+newncnt+')" id="yesBtnUnfalldeckung'+newncnt+'" class="inFormYesNoBtn me-1 documentFormBtn" for="btnradio3abcdef' + newncnt + '">Ja</label>'+
            ''+
            '                                                                        <input  type="radio" class="btn-check " name="accident_coverage' + newncnt + '" value="Nein" id="btnradio4abcdef' + newncnt + '" autocomplete="off">'+
            '                                                                        <label onclick="noBtnUnfalldeckungClicked('+newncnt+')" id="noBtnUnfalldeckung'+newncnt+'" class="inFormYesNoBtn documentFormBtn" for="btnradio4abcdef' + newncnt + '">Nein</label>'+
            '                                                                    </div>'+
            '                                                                </div>'+
            ''+
            '                                                            </div>'+
            '                                                            <div class="col">'+
            '                                                                <div class="input-div1 mb-2">'+
            '                                                                    <div class="">'+
            '                                                                            <span class="GrundversicherungSpans">'+
            '                                                                                + Verkehrsrechtsschutz:'+
            '                                                                            </span>'+
            '                                                                    </div>'+
            '                                                                    <div class="btn-group" role="group" aria-label="Basic radio toggle button group">'+
            '                                                                        <input type="radio" class="btn-check showpdf" name="traffic_legal_protection' + newncnt + '" value="Ja" id="btnradio3a' + newncnt + '" autocomplete="off" checked>'+
            '                                                                        <label id="yesBtnVerkehrsrechtsschutz'+newncnt+'" onclick="yesBtnVerkehrsrechtsschutzClicked('+newncnt+')" class="inFormYesNoBtn documentFormBtn me-1" for="btnradio3a' + newncnt + '">Ja</label>'+
            ''+
            '                                                                        <input type="radio" class="btn-check" name="traffic_legal_protection' + newncnt + '" value="Nein" id="btnradio4a' + newncnt + '" autocomplete="off">'+
            '                                                                        <label id="noBtnVerkehrsrechtsschutz'+newncnt+'" onclick="noBtnVerkehrsrechtsschutzClicked('+newncnt+')" class="inFormYesNoBtn documentFormBtn " for="btnradio4a' + newncnt + '">Nein</label>'+
            '                                                                    </div>'+
            '                                                                </div>'+
            ''+
            '                                                                <div class="input-div1 mb-2">'+
            '                                                                    <div class="">'+
            '                                                                            <span class="GrundversicherungSpans">'+
            '                                                                                + Grobfahrlässigkeitschutz:'+
            '                                                                            </span>'+
            '                                                                    </div>'+
            '                                                                    <div class="btn-group" role="group" aria-label="Basic radio toggle button group">'+
            '                                                                        <input type="radio" class="btn-check showpdf" name="grossly' + newncnt + '" value="Ja" id="btnradio3ab' + newncnt + '" autocomplete="off" checked>'+
            '                                                                        <label onclick="yesBtnGrobfahrlässigkeitschutzClicked('+newncnt+')" id="yesBtnGrobfahrlässigkeitschutz'+newncnt+'" class="inFormYesNoBtn documentFormBtn me-1" for="btnradio3ab' + newncnt + '">Ja</label>'+
            ''+
            '                                                                        <input type="radio" class="btn-check" name="grossly' + newncnt + '" value="Nein" id="btnradio4ab' + newncnt + '' + newncnt + '" autocomplete="off">'+
            '                                                                        <label onclick="noBtnGrobfahrlässigkeitschutzClicked('+newncnt+')" id="noBtnGrobfahrlässigkeitschutz'+newncnt+'" class="inFormYesNoBtn documentFormBtn " for="btnradio4ab' + newncnt + '">Nein</label>'+
            '                                                                    </div>'+
            '                                                                </div>'+
            ''+
            '                                                                <div class="input-div1 mb-2">'+
            '                                                                    <div class="">'+
            '                                                                            <span class="GrundversicherungSpans">'+
            '                                                                                + Glasschutz:'+
            '                                                                            </span>'+
            '                                                                    </div>'+
            '                                                                    <div class="btn-group" role="group" aria-label="Basic radio toggle button group">'+
            '                                                                        <input type="radio" class="btn-check showpdf" name="glass_protection' + newncnt + '" value="Ja" id="btnradio3abc' + newncnt + '" autocomplete="off" checked>'+
            '                                                                        <label onclick="yesBtnGlasschutzClicked('+newncnt+')" id="yesBtnGlasschutz'+newncnt+'" class="inFormYesNoBtn documentFormBtn me-1" for="btnradio3abc' + newncnt + '">Ja</label>'+
            ''+
            '                                                                        <input type="radio" class="btn-check" name="glass_protection' + newncnt + '" value="Nein" id="btnradio4abc' + newncnt + '" autocomplete="off">'+
            '                                                                        <label onclick="noBtnGlasschutzClicked('+newncnt+')" id="noBtnGlasschutz'+newncnt+'" class="inFormYesNoBtn documentFormBtn " for="btnradio4abc' + newncnt + '">Nein</label>'+
            '                                                                    </div>'+
            '                                                                </div>'+
            ''+
            '                                                                <div class="input-div1 mb-2">'+
            '                                                                    <div class="">'+
            '                                                                            <span class="GrundversicherungSpans">'+
            '                                                                                + Parkschaden:'+
            '                                                                            </span>'+
            '                                                                    </div>'+
            ''+
            '                                                                    <div class="btn-group" role="group" aria-label="Basic radio toggle button group">'+
            '                                                                        <input type="radio" class="btn-check showpdf" name="parking_damage' + newncnt + '" value="Ja" id="btnradio3abcd' + newncnt + '" autocomplete="off" checked>'+
            '                                                                        <label onclick="yesBtnParkschadenClicked('+newncnt+')" id="yesBtnParkschaden'+newncnt+'" class="inFormYesNoBtn documentFormBtn " for="btnradio3abcd' + newncnt + '">Ja</label>'+
            ''+
            '                                                                        <input type="radio" class="btn-check" name="parking_damage' + newncnt + '" value="Nein" id="btnradio4abcd' + newncnt + '" autocomplete="off">'+
            '                                                                        <label onclick="noBtnParkschadenClicked('+newncnt+')" id="noBtnParkschaden'+newncnt+'" class="inFormYesNoBtn documentFormBtn " for="btnradio4abcd' + newncnt + '">Nein</label>'+
            '                                                                    </div>'+
            '                                                                </div>'+
            '                                                                <div class="input-div1 mb-2">'+
            '                                                                    <div class="">'+
            '                                                                            <span class="GrundversicherungSpans">'+
            '                                                                                + 24h Pannenhilfe:'+
            '                                                                            </span>'+
            '                                                                    </div>'+
            '                                                                    <div class="btn-group" role="group" aria-label="Basic radio toggle button group">'+
            '                                                                        <input type="radio" class="btn-check showpdf" name="hour_breakdown_assistance' + newncnt + '" value="Ja" id="btnradio3abcde' + newncnt + '" autocomplete="off" checked>'+
            '                                                                        <label id="yesBtnPannenhilfe'+newncnt+'" onclick="yesBtnPannenhilfeClicked('+newncnt+')" class="inFormYesNoBtn documentFormBtn " for="btnradio3abcde' + newncnt + '">Ja</label>'+
            ''+
            '                                                                        <input type="radio" class="btn-check" name="hour_breakdown_assistance' + newncnt + '" value="Nein" id="btnradio4abcde' + newncnt + '" autocomplete="off">'+
            '                                                                        <label id="noBtnPannenhilfe'+newncnt+'" onclick="noBtnPannenhilfeClicked('+newncnt+')" class="inFormYesNoBtn documentFormBtn " for="btnradio4abcde' + newncnt + '">Nein</label>'+
            '                                                                    </div>'+
            '                                                                </div>'+
            '                                                            </div>'+
            '                                                            <div>'+
            '                                                                <div class="">'+
            '                                                                        <span class="GrundversicherungSpans">'+
            '                                                                            Kommentar:'+
            '                                                                        </span>'+
            '                                                                </div>'+
            ''+
            '                                                                <div class="col-12 col-6">'+
            '                                                                    <textarea class="GrundversicherungInput form-control showpdf" name="nuekommentar' + newncnt + '"></textarea>'+
            '                                                                </div>'+
            '                                                            </div>'+
            '                                                        </div>'+
            '                                                    </div>'+
            '                                                </div>'+
            '                                                <div class="row g-0 mt-3 justify-content-center" id="add_n" onclick="addanother_item_n()">'+
            '                                                    <div class="col-auto">'+
            '                                                        <svg xmlns="http://www.w3.org/2000/svg" width="48.694" viewBox="0 0 37.694 37.694" style="cursor:pointer;">'+
            '                                                            <g id="Group_621" data-name="Group 621" transform="translate(-663.236 -976.679)">'+
            '                                                                <g id="Group_550" data-name="Group 550" transform="translate(663.236 976.679)">'+
            '                                                                    <rect id="Rectangle_9" data-name="Rectangle 9" width="37.694" height="37.694" rx="18.847" fill="#2F60DC" />'+
            '                                                                    <g id="Group_42" data-name="Group 42" transform="translate(12.724 12.724)">'+
            '                                                                        <line id="Line_11" data-name="Line 11" y2="11.972" transform="translate(5.986 0)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="2" />'+
            '                                                                        <line id="Line_12" data-name="Line 12" x1="11.972" transform="translate(0 5.634)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="2" />'+
            '                                                                    </g>'+
            '                                                                </g>'+
            '                                                            </g>'+
            '                                                        </svg>'+
            '                                                    </div>');

        document.getElementById('newncount').value = newncnt;

    }
    function yesBtnGarageClicked(x) {
        console.log(x);
        document.getElementById("yesBtnGarage" + x).style = "background: #60CB9D ";
        document.getElementById("noBtnGarage" + x).style = "background: rgba(231, 236, 249, 0.32)";
    }

    function noBtnGarageClicked(y) {
        document.getElementById("yesBtnGarage" + y).style = "background: rgba(231, 236, 249, 0.32)";
        document.getElementById("noBtnGarage" + y).style = "background: #60CB9D ";
    }
    function yesBtnLeasingClicked(x) {

        document.getElementById("yesBtnLeasing" + x).style = "background: #60CB9D";
        document.getElementById("noBtnLeasing" + x).style = "background: rgba(231, 236, 249, 0.32);";
    }

    function noBtnLeasingClicked(x) {
        document.getElementById("yesBtnLeasing" + x).style = "background: rgba(231, 236, 249, 0.32);";
        document.getElementById("noBtnLeasing" + x).style = "background: #EF7C6D";

    }
    function yesBtnVerkehrsrechtsschutzClicked(x) {
        document.getElementById("yesBtnVerkehrsrechtsschutz" + x).style = "background: #60CB9D ";
        document.getElementById("noBtnVerkehrsrechtsschutz" + x).style = "background: rgba(231, 236, 249, 0.32)";
    }

    function noBtnVerkehrsrechtsschutzClicked(x) {

        document.getElementById("yesBtnVerkehrsrechtsschutz" + x).style = "background: rgba(231, 236, 249, 0.32)";
        document.getElementById("noBtnVerkehrsrechtsschutz" + x).style = "background: rgb(239, 124, 109); ";
    }


    function yesBtnUnfalldeckungClicked(x) {
        document.getElementById("yesBtnUnfalldeckung" + x).style = "background: #60CB9D ";
        document.getElementById("noBtnUnfalldeckung" + x).style = "background: rgba(231, 236, 249, 0.32)";
    }

    function noBtnUnfalldeckungClicked(x) {

        document.getElementById("yesBtnUnfalldeckung" + x).style = "background: rgba(231, 236, 249, 0.32)";
        document.getElementById("noBtnUnfalldeckung" + x).style = "background: rgb(239, 124, 109); ";
    }

    function yesBtnGlasschutzClicked(x) {
        document.getElementById("yesBtnGlasschutz" + x).style = "background: #60CB9D ";
        document.getElementById("noBtnGlasschutz" + x).style = "background: rgba(231, 236, 249, 0.32)";
    }

    function noBtnGlasschutzClicked(x) {

        document.getElementById("yesBtnGlasschutz" + x).style = "background: rgba(231, 236, 249, 0.32)";
        document.getElementById("noBtnGlasschutz" + x).style = "background: rgb(239, 124, 109); ";
    }

    function yesBtnGrobfahrlässigkeitschutzClicked(x) {
        document.getElementById("yesBtnGrobfahrlässigkeitschutz" + x).style = "background: #60CB9D ";
        document.getElementById("noBtnGrobfahrlässigkeitschutz" + x).style = "background: rgba(231, 236, 249, 0.32)";
    }

    function noBtnGrobfahrlässigkeitschutzClicked(x) {

        document.getElementById("yesBtnGrobfahrlässigkeitschutz" + x).style = "background: rgba(231, 236, 249, 0.32)";
        document.getElementById("noBtnGrobfahrlässigkeitschutz" + x).style = "background: rgb(239, 124, 109); ";
    }

    function yesBtnParkschadenClicked(x) {
        document.getElementById("yesBtnParkschaden" + x).style = "background: #60CB9D ";
        document.getElementById("noBtnParkschaden" + x).style = "background: rgba(231, 236, 249, 0.32)";
    }
    function noBtnParkschadenClicked(x) {

        document.getElementById("yesBtnParkschaden" + x).style = "background: rgba(231, 236, 249, 0.32)";
        document.getElementById("noBtnParkschaden" + x).style = "background: rgb(239, 124, 109); ";
    }
    function noBtnPannenhilfeClicked(x) {

        document.getElementById("yesBtnPannenhilfe" + x).style = "background: rgba(231, 236, 249, 0.32)";
        document.getElementById("noBtnPannenhilfe" + x).style = "background: rgb(239, 124, 109); ";
    }
    function yesBtnPannenhilfeClicked(x) {
        document.getElementById("yesBtnPannenhilfe" + x).style = "background: #60CB9D ";
        document.getElementById("noBtnPannenhilfe" + x).style = "background: rgba(231, 236, 249, 0.32)";
    }




    function saveContentFunct11() {
        $("#add-btn11").slideToggle();
        $("#added-content11").slideToggle();
    }

    function deletethat(x) {
        $('#n' + x).remove();
        newncnt--;
        document.getElementById('newncount').value = newncnt;
    }

    function deletethat2(x) {
        $('#g' + x).remove();
        $('#of' + x).remove();
        newgcnt--;
        document.getElementById('newgcount').value = newgcnt;
    }


    // function changecntkranken(x) {
    //     cnttkranken = x;
    //     if (x == 3) {
    //         document.getElementById("submitt").setAttribute('data-bs-toggle', 'modal');
    //         document.getElementById("submitt").setAttribute('data-bs-target', '#exampleModal');
    //     }
    // }
    //
    // function nextoneKranken(){
    //     if (cnttkranken < 5 && cnttkranken > -1) {
    //         if (cntt == 0) {
    //             $('#nav-one-tab').addClass('active show');
    //             $('#nav-home').removeClass('active show');
    //             $('#nav-tabContent').addClass('active');
    //             $('#nav-home-tab').removeClass('active');
    //         }
    //         if (cntt == 1) {
    //             $('#nav-contact').addClass('active show');
    //             $('#nav-one-tab').removeClass('active show');
    //             $('#nav-contact-tab').addClass('active');
    //             $('#nav-tabContent').removeClass('active');
    //         }
    // }



    function changecnt(x) {
        cntt = x;
        if (x == 3) {
            document.getElementById("submitt").setAttribute('data-bs-toggle', 'modal');
            document.getElementById("submitt").setAttribute('data-bs-target', '#exampleModal');
        }
    }

    function nextonee() {
        if (cntt < 5 && cntt > -1) {
            if (cntt == 0) {
                $('#nav-profile').addClass('active show');
                $('#nav-home').removeClass('active show');
                $('#nav-profile-tab').addClass('active');
                $('#nav-home-tab').removeClass('active');
            }
            if (cntt == 1) {
                $('#nav-contact').addClass('active show');
                $('#nav-profile').removeClass('active show');
                $('#nav-contact-tab').addClass('active');
                $('#nav-profile-tab').removeClass('active');
            }
            if (cntt == 2) {
                $('#nav-fourth').addClass('active show');
                $('#nav-contact').removeClass('active show');
                $('#nav-fourth-tab').addClass('active');
                $('#nav-contact-tab').removeClass('active');
                document.getElementById("submitt").setAttribute('data-bs-toggle', 'modal');
                document.getElementById("submitt").setAttribute('data-bs-target', '#exampleModal');
            }
            if (cntt == 3) {
                document.getElementById("submitt").setAttribute('data-bs-toggle', 'modal');
                document.getElementById("submitt").setAttribute('data-bs-target', '#exampleModal');
            }
            cntt++;
        }
    }

    function addContentFunct11() {
        $("#added-content11").slideToggle();
        $("#add-btn11").slideToggle();
    }

    function hideSpan() {
        if (document.getElementById("bastelle-span").style.display === "none") {
            document.getElementById("bastelle-span").style.display = "block";
            document.getElementById("button1").style.setProperty("border-bottom-left-radius", "10px", "important");
            document.getElementById("button1").style.setProperty("border-bottom-right-radius", "10px", "important");
        } else {
            document.getElementById("bastelle-span").style.display = "none";
            document.getElementById("button1").style.setProperty("border-bottom-left-radius", "0px", "important");
            document.getElementById("button1").style.setProperty("border-bottom-right-radius", "0px", "important");
        }
    }

    // plus button function
    function addContentFunct() {
        // document.getElementById("added-content").style.display = "block";
        // document.getElementById("add-btn").style.display = "none";
        $("#added-content").slideToggle();
        $("#add-btn").slideToggle();
    }
    function aaa(){

    }
    function saveContentFunct() {
        // document.getElementById("added-content").style.display = "none";
        // document.getElementById("add-btn").style.display = "block";
        $("#add-btn").slideToggle();
        $("#added-content").slideToggle();
    }

    function msheleqeta() {
        var x = document.getElementById('manval').value;
        if (x == "No") {
            document.getElementById('mandat').innerHTML = "";

        }
    }

    function hideNation() {
        var x = document.getElementById('schweiz').value;
        if (x == "Swiss") {
            document.getElementById('admin').style.display = "none";
        } else {
            document.getElementById('admin').style.display = "inline";
        }
    }

    function workingOnIt() {
        alert('Kommt Bald...');
    }

    function showpdf() {
        var inputs = document.getElementsByClassName('showpdf');
        var GrundversicherungSpans = document.getElementsByClassName('GrundversicherungSpans');
        document.getElementById('old-content').style.display = 'none';
        document.getElementById('pdf').style.display = 'block';

        document.getElementById('pdf').innerHTML += '<div class="col">' +
            '    <div class="my-5 mx-4">' +
            '      <div class="" style="background-color: #EFEFEF;border-radius: 22px;">' +
            '        <div class="py-4 px-3">' +
            '          <span class="fs-4">' +
            '            Markus Jurgen' +
            '          </span> <br>' +
            '          <span class="fs-6 text-muted">' +
            '            Raumweg 23, 3700 Thun' +
            '          </span>' +
            '        </div>' +
            '        <div class="row mx-4">' +
            '          <nav class="g-0">' +
            '            <div class="nav nav-tabs" id="nav-tab" role="tablist">' +
            '              <button class="border-0 col py-2 fw-bold text-secondary" id=""' +
            '                type="button"' +
            '                aria-selected="true">Krankenkasse</button>' +
            '              <button class="border-0  col py-2 fw-bold text-secondary"' +
            '                 type="button"' +
            '                aria-selected="false">Auto</button>' +
            '              <button class="border-0  col py-2 fw-bold text-secondary"' +
            '                type="button"' +
            '                aria-selected="false">Vorsorge</button>' +
            '              <button class="border-0  col py-2 fw-bold text-secondary"' +
            '                 type="button"' +
            '                aria-selected="false">Sachen</button>' +
            '            </div>' +
            '          </nav>' +
            '        </div>' +
            '        <div class="tab-content mx-4 pb-3" id="nav-tabContent">' +
            '          <div class="tab-pane fade  krankenkasse-content mb-3" id="nav-home" role="tabpanel"' +
            '            aria-labelledby="nav-home-tab">' +
            '          </div>' +
            '          <div class="tab-pane fade auto-content" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">' +
            '          </div>' +
            '          <div class="tab-pane fade  sachen-content" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">' +
            '          </div>' +
            '          <div class="tab-pane fade  vorsorge-content" id="nav-fourth" role="tabpanel" aria-labelledby="nav-fourth-tab">' +
            '          </div>' +
            '          <div class="bg-white submit-form-end px-3" role="tabpanel">' +
            '            <div class="fs-3 fw-bold py-3">' +
            '              Eingabe uberprufen!' +
            '            </div>' +
            '            <div class="row g-0">' +
            '              <div class="col-12 col-md-6">' +
            '                <div class="krankenkasse-content-submited  my-3">' +
            '                  <div class="fs-5 fw-bold">' +
            '                    Krankenkasse' +
            '                  </div>' +
            '                  <div class="kk-info">' +
            '                    <div class="d-flex">' +
            '                      <div class="col-6">' + GrundversicherungSpans[0].innerHTML + ': </div>' +
            '                      <div class="col-6">' + inputs[0].value + '</div>' +
            '                    </div>' +
            '                    <div class="d-flex">' +
            '                      <div class="col-6">' + GrundversicherungSpans[1].innerHTML + ': </div>' +
            '                      <div class="col-6">' + inputs[1].value + '</div>' +
            '                    </div>' +
            '                    <div class="d-flex">' +
            '                      <div class="col-6">' + GrundversicherungSpans[2].innerHTML + ': </div>' +
            '                      <div class="col-6">' + inputs[2].value + '</div>' +
            '                    </div>' +
            '                    <div class="d-flex">' +
            '                      <div class="col-6">' + GrundversicherungSpans[3].innerHTML + ': </div>' +
            '                      <div class="col-6">' + inputs[3].value + '</div>' +
            '                    </div>' +
            '                   <div class="d-flex">' +
            '                      <div class="col-6">' + GrundversicherungSpans[4].innerHTML + ': </div>' +
            '                      <div class="col-6">' + inputs[4].value + '</div>' +
            '                    </div>' +
            '                  </div>' +
            '                </div>' +
            '                <div class="auto-content-submited  my-3">' +
            '                  <div class="fs-5 fw-bold">' +
            '                    Auto' +
            '                  </div>' +
            '                  <div  class="fs-5 my-2" style="font-weight: 500">' +
            '                    Gegenofferte:' +
            '                  </div>' +
            '                  <div class="auto-content-submited">' +
            '                   <div id="gegenoferte">' +
            '                       <div class="d-flex">' +
            '                       <div class="col-6">' + GrundversicherungSpans[5].innerHTML + ' </div>' +
            '                       <div class="col-6">' + inputs[5].value + '</div>' +
            '                       </div>' +
            '                       <div class="d-flex">' +
            '                       <div class="col-6">' + GrundversicherungSpans[6].innerHTML + ' </div>' +
            '                       <div class="col-6">' + inputs[6].value + '</div>' +
            '                       </div>' +
            '                   </div>' +
            '                  <div class="fs-5 my-2" style="font-weight: 500">' +
            '                    Neues Fahrzeug:' +
            '                  </div>' +
            '                   <div id="autooferte">' +
            '                       <div class="d-flex">' +
            '                       <div class="col-6">' + GrundversicherungSpans[7].innerHTML + ': </div>' +
            '                       <div class="col-6">' + inputs[7].value + '</div>' +
            '                       </div>' +
            '                       <div class="d-flex">' +
            '                       <div class="col-6">' + GrundversicherungSpans[8].innerHTML + ' </div>' +
            '                       <div class="col-6">' + inputs[8].value + '</div>' +
            '                       </div>' +
            '                       <div class="d-flex">' +
            '                       <div class="col-6">' + GrundversicherungSpans[9].innerHTML + ' </div>' +
            '                       <div class="col-6">' + inputs[9].value + '</div>' +
            '                       </div>' +
            '                       <div class="d-flex">' +
            '                       <div class="col-6">' + GrundversicherungSpans[10].innerHTML + ' </div>' +
            '                       <div class="col-6">' + inputs[10].value + '</div>' +
            '                       </div>' +
            '                       <div class="d-flex">' +
            '                       <div class="col-6">' + GrundversicherungSpans[11].innerHTML + ' </div>' +
            '                       <div class="col-6">' + inputs[11].value + '</div>' +
            '                       </div>' +
            '                       <div class="d-flex">' +
            '                       <div class="col-6">' + GrundversicherungSpans[12].innerHTML + ' </div>' +
            '                       <div class="col-6">' + inputs[12].value + '</div>' +
            '                       </div>' +
            '                       <div class="d-flex">' +
            '                       <div class="col-6">' + GrundversicherungSpans[13].innerHTML + ' </div>' +
            '                       <div class="col-6">' + inputs[13].value + '</div>' +
            '                       </div>' +
            '                       <div class="d-flex">' +
            '                       <div class="col-6">' + GrundversicherungSpans[14].innerHTML + ' </div>' +
            '                       <div class="col-6">' + inputs[14].value + '</div>' +
            '                       </div>' +
            '                       <div class="d-flex">' +
            '                       <div class="col-6">' + GrundversicherungSpans[15].innerHTML + ' </div>' +
            '                       <div class="col-6">' + inputs[15].value + '</div>' +
            '                       </div>' +
            '                       <div class="d-flex">' +
            '                       <div class="col-6">' + GrundversicherungSpans[16].innerHTML + ' </div>' +
            '                       <div class="col-6">' + inputs[16].value + '</div>' +
            '                       </div>' +
            '                       <div class="d-flex">' +
            '                       <div class="col-6">' + GrundversicherungSpans[17].innerHTML + ' </div>' +
            '                       <div class="col-6">' + inputs[17].value + '</div>' +
            '                       </div>' +
            '                       <div class="d-flex">' +
            '                       <div class="col-6">' + GrundversicherungSpans[18].innerHTML + ' </div>' +
            '                       <div class="col-6">' + inputs[18].value + '</div>' +
            '                       </div>' +
            '                       <div class="d-flex">' +
            '                       <div class="col-6">' + GrundversicherungSpans[19].innerHTML + ' </div>' +
            '                       <div class="col-6">' + inputs[19].value + '</div>' +
            '                       </div>' +
            '                       <div class="d-flex">' +
            '                       <div class="col-6">' + GrundversicherungSpans[20].innerHTML + ' </div>' +
            '                       <div class="col-6">' + inputs[20].value + '</div>' +
            '                       </div>' +
            '                       <div class="d-flex">' +
            '                       <div class="col-6">' + GrundversicherungSpans[21].innerHTML + ' </div>' +
            '                       <div class="col-6">' + inputs[21].value + '</div>' +
            '                       </div>' +
            '                       <div class="d-flex">' +
            '                       <div class="col-6">' + GrundversicherungSpans[22].innerHTML + ' </div>' +
            '                       <div class="col-6">' + inputs[22].value + '</div>' +
            '                       </div>' +
            '                       <div class="d-flex">' +
            '                       <div class="col-6">' + GrundversicherungSpans[23].innerHTML + ' </div>' +
            '                       <div class="col-6">' + inputs[23].value + '</div>' +
            '                       </div>' +
            '                       <div class="d-flex">' +
            '                       <div class="col-6">' + GrundversicherungSpans[24].innerHTML + ' </div>' +
            '                       <div class="col-6">' + inputs[24].value + '</div>' +
            '                       </div>' +
            '                       <div class="d-flex">' +
            '                       <div class="col-6">' + GrundversicherungSpans[25].innerHTML + ' </div>' +
            '                       <div class="col-6">' + inputs[25].value + '</div>' +
            '                       </div>' +
            '                       <div class="d-flex">' +
            '                       <div class="col-6">' + GrundversicherungSpans[26].innerHTML + ' </div>' +
            '                       <div class="col-6">' + inputs[26].value + '</div>' +
            '                       </div>' +
            '                       <div class="d-flex">' +
            '                       <div class="col-6">' + GrundversicherungSpans[27].innerHTML + ' </div>' +
            '                       <div class="col-6">' + inputs[27].value + '</div>' +
            '                       </div>' +
            '                   </div>' +
            '                  </div>' +
            '                </div>' +
            '              </div>' +
            '              <div class="col-12 col-md-6">' +
            '                <div class="3a3banfragen-content-submited  my-3">' +
            '                  <div class="fs-5 fw-bold my-2">' +
            '                    Vorsorge ' +
            '                  </div>' +
            '                  <div class="fs-5 my-2" style="font-weight: 500">' +
            '                   3a/ 3b Anfragen' +
            '                  </div>' +
            '                  <div class="inputs-shown-33-info">' +
            '                    <div class="d-flex">' +
            '                      <div class="col-6">' + GrundversicherungSpans[28].innerHTML + ' </div>' +
            '                      <div class="col-6">' + inputs[28].value + '</div>' +
            '                    </div>' +
            '                    <div class="d-flex">' +
            '                      <div class="col-6">' + GrundversicherungSpans[29].innerHTML + ' </div>' +
            '                      <div class="col-6">' + inputs[29].value + '</div>' +
            '                    </div>' +
            '                    <div class="d-flex">' +
            '                      <div class="col-6">' + GrundversicherungSpans[30].innerHTML + ' </div>' +
            '                      <div class="col-6">' + inputs[30].value + '</div>' +
            '                    </div>' +
            '                    <div class="d-flex">' +
            '                      <div class="col-6">' + GrundversicherungSpans[31].innerHTML + ' </div>' +
            '                      <div class="col-6">' + inputs[31].value + '</div>' +
            '                    </div>' +
            '                    <div class="d-flex">' +
            '                      <div class="col-6">' + GrundversicherungSpans[32].innerHTML + ' </div>' +
            '                      <div class="col-6">' + inputs[32].value + '</div>' +
            '                    </div>' +
            '                    <div class="d-flex">' +
            '                      <div class="col-6">' + GrundversicherungSpans[33].innerHTML + ' </div>' +
            '                      <div class="col-6">' + inputs[33].value + '</div>' +
            '                    </div>' +
            '                    <div class="d-flex">' +
            '                     <div class="col-6">' + GrundversicherungSpans[34].innerHTML + ' </div>' +
            '                      <div class="col-6">' + inputs[34].value + '</div>' +
            '                    </div>' +
            '                    <div class="d-flex">' +
            '                      <div class="col-6">' + GrundversicherungSpans[35].innerHTML + ' </div>' +
            '                      <div class="col-6">' + inputs[35].value + '</div>' +
            '                    </div>' +
            '                    <div class="d-flex">' +
            '                      <div class="col-6">' + GrundversicherungSpans[36].innerHTML + ' </div>' +
            '                      <div class="col-6">' + inputs[36].value + '</div>' +
            '                    </div>' +
            '                    <div class="d-flex">' +
            '                      <div class="col-6">' + GrundversicherungSpans[37].innerHTML + ' </div>' +
            '                      <div class="col-6">' + inputs[37].value + '</div>' +
            '                    </div>' +
            '                    <div class="d-flex">' +
            '                      <div class="col-6">' + GrundversicherungSpans[38].innerHTML + ' </div>' +
            '                      <div class="col-6">' + inputs[38].value + '</div>' +
            '                    </div>' +
            '                    <div class="d-flex">' +
            '                      <div class="col-6">' + GrundversicherungSpans[39].innerHTML + ' </div>' +
            '                      <div class="col-6">' + inputs[39].value + '</div>' +
            '                    </div>' +
            '                    <div class="d-flex">' +
            '                      <div class="col-6">' + GrundversicherungSpans[40].innerHTML + ' </div>' +
            '                      <div class="col-6">' + inputs[40].value + '</div>' +
            '                    </div>' +
            '                    <div class="d-flex">' +
            '                      <div class="col-6">' + GrundversicherungSpans[41].innerHTML + ' </div>' +
            '                      <div class="col-6">' + inputs[41].value + '</div>' +
            '                    </div>' +
            '                    <div class="d-flex">' +
            '                      <div class="col-6">' + GrundversicherungSpans[42].innerHTML + ' </div>' +
            '                      <div class="col-6">' + inputs[42].value + '</div>' +
            '                    </div>' +
            '                    <div class="d-flex">' +
            '                      <div class="col-6">' + GrundversicherungSpans[43].innerHTML + ' </div>' +
            '                      <div class="col-6">' + inputs[43].value + '</div>' +
            '                    </div>' +
            '                  </div>' +
            '                </div>' +
            '                <div class="sachen-content-submited my-3">' +
            '                  <div class="fs-5 fw-bold my-2">' +
            '                    Sachen' +
            '                  </div>' +
            '                  <div class="fs-5 my-2" style="font-weight: 500">' +
            '                    Hausrat- & Privathaftpflicht' +
            '                  </div>' +
            '                  <div class="d-flex">' +
            '                      <div class="col-6">' + GrundversicherungSpans[44].innerHTML + ' </div>' +
            '                      <div class="col-6">' + inputs[44].value + '</div>' +
            '                  </div>' +
            '                  <div class="d-flex">' +
            '                      <div class="col-6">' + GrundversicherungSpans[45].innerHTML + ' </div>' +
            '                      <div class="col-6">' + inputs[45].value + '</div>' +
            '                  </div>' +
            '                  <div class="d-flex">' +
            '                      <div class="col-6">' + GrundversicherungSpans[46].innerHTML + ': </div>' +
            '                      <div class="col-6">' + inputs[46].value + '</div>' +
            '                  </div>' +
            '                  <div class="d-flex">' +
            '                      <div class="col-6">' + GrundversicherungSpans[47].innerHTML + ': </div>' +
            '                      <div class="col-6">' + inputs[47].value + '</div>' +
            '                  </div>' +
            '                  <div class="d-flex">' +
            '                      <div class="col-6">' + GrundversicherungSpans[48].innerHTML + ': </div>' +
            '                      <div class="col-6">' + inputs[48].value + '</div>' +
            '                  </div>' +
            '                  <div class="d-flex">' +
            '                      <div class="col-6">' + GrundversicherungSpans[49].innerHTML + ' </div>' +
            '                      <div class="col-6">' + inputs[49].value + '</div>' +
            '                  </div>' +
            '                  <div class="d-flex">' +
            '                      <div class="col-6">' + GrundversicherungSpans[50].innerHTML + ': </div>' +
            '                      <div class="col-6">' + inputs[50].value + '</div>' +
            '                  </div>' +
            '                  <div class="fs-5 my-2" style="font-weight: 500">' +
            '                    Rechtsschutzversicherung' +
            '                  </div>' +
            '                  <div class="d-flex">' +
            '                      <div class="col-6">' + GrundversicherungSpans[51].innerHTML + ': </div>' +
            '                      <div class="col-6">' + inputs[51].value + '</div>' +
            '                  </div>' +
            '                  <div class="d-flex">' +
            '                      <div class="col-6">' + GrundversicherungSpans[52].innerHTML + ': </div>' +
            '                      <div class="col-6">' + inputs[52].value + '</div>' +
            '                  </div>' +
            '                </div>' +
            '              </div>' +
            '            </div>' +
            '            <div class="d-flex justify-content-center py-2">' +
            '               <div>' +
            '              <button type="button" onclick="qoe()" class="py-2 px-5 submit-btnnnn">' +
            '                Bestätigen' +
            '              </button>' +
            '               </div>' +
            '            </div>' +
            '          </div>' +
            '        </div>' +
            '      </div>' +
            '    </div>' +
            '  </div>';
        var auto = document.getElementsByClassName('autopdf');
        var autoName = document.getElementsByClassName('autoName');


        issmodulo = 1;
        for (let i = auto.length - 1; i >= 0; i--) {
            document.getElementById("autooferte").insertAdjacentHTML("afterend",
                '<div class="d-flex " style=""> <div class="col-6 "> ' + autoName[i].innerHTML + ' </div><div class="col-6">' + auto[i].value + '</div></div>');
            if (i == 0) {
                $("#autooferte").append(
                    '<hr>');
            }
        }

        var gegen = document.getElementsByClassName('gegenpdf');
        var gegenName = document.getElementsByClassName('gegenName');

        ismodulo = 1;
        for (let i = gegen.length - 1; i >= 0; i--) {
            if (ismodulo % 2 == 1) {
                document.getElementById("gegenoferte").insertAdjacentHTML("afterend",
                    '<div class="d-flex " style="border-right: 1px solid black; border-left: 1px solid black; border-bottom: 1px solid black;"> <div class="col-6 "> ' + gegenName[i].innerHTML + ' </div><div class="col-6">' + gegen[i].value + '</div></div>');
            } else {
                document.getElementById("gegenoferte").insertAdjacentHTML("afterend",
                    '<div class="d-flex " style="border-right: 1px solid black; border-left: 1px solid black; border-top: 1px solid black"> <div class="col-6 "> ' + gegenName[i].innerHTML + ' </div><div class="col-6">' + gegen[i].value + '</div></div>');
            }
            ismodulo++;
        }


    }


    function qoe() {
        document.getElementById('formaa').submit();
    }

    function showel(x) {
        var val = parseInt(x.getAttribute('for').charAt(x.getAttribute('for').length - 1));
        var val2 = x.getAttribute('for').substring(0, x.getAttribute('for').length - 1);
        var valc = val + 1;
        if (val == 1) {
            var fulldoc = val2 + valc;
            $('#' + x.getAttribute('for')).addClass('autopdf');
            $('#' + fulldoc).removeClass('autopdf');

        } else {
            var fulldoc = val2 + "1";
            $('#' + x.getAttribute('for')).addClass('autopdf');
            $('#' + fulldoc).removeClass('autopdf');
        }

    }

    function krankenSkipp() {
        document.getElementById('krankenSkip').checked = true;
        document.getElementById('nav-home-tab').disabled = true;
        $('#nav-home-tab').addClass('gray-btn-kk');
    }

    function autoSkipp() {
        document.getElementById('autoSkip').checked = true;
        document.getElementById('nav-profile-tab').disabled = true;
        $('#nav-profile-tab').addClass('gray-btn-kk');
    }

    function vorsorgeSkipp() {
        document.getElementById('vorsorgenSkip').checked = true;
        document.getElementById('nav-contact-tab').disabled = true;
        $('#nav-contact-tab').addClass('gray-btn-kk');
    }

    function sachenSkipp() {
        document.getElementById('sachenSkip').checked = true;
    }

    @php
        $krank =\App\Models\LeadDataKK::where('person_id', $lead->id)-> first();
    @endphp
    @if($krank)
    @if($krank-> krank_id != null)
    document.getElementById('nav-home').style.display = 'none';
    document.getElementById('kranken1').innerHTML = '<a href="' + '{{URL::route('
        leadfamilyperson ',[\Illuminate\Support\Facades\Crypt::encrypt($krank->krank_id* 1244), "accept" => false, "admin_id" => \Illuminate\Support\Facades\Crypt::encrypt((int) \App\Models\Pendency::where('
        family_id ',$krank->krank_id)->first()->admin_id * 1244),"vorsorge" => false,'
        pend_id ' => \App\Models\Pendency::where('
        family_id ',$krank->krank_id)->first()->id])}}' + '"><h4>Kranken</h4></a>';
    @endif
    @endif


    function changecntss(x) {
        cntts = x;
    }

    var cntts = 0;

    function nextstep() {
        if (cntts < 3 && cntts > -1) {
            if (cntts == 0) {
                $('#nav-two').addClass('active show');
                $('#nav-one').removeClass('active show');
                $('#nav-two-tab').addClass('active');
                $('#nav-one-tab').removeClass('active');
            }
            if (cntts == 1) {
                $('#nav-three').addClass('active show');
                $('#nav-two').removeClass('active show');
                $('#nav-three-tab').addClass('active');
                $('#nav-two-tab').removeClass('active');
            }
            if (cntts == 2) {
                $('#nav-profile').addClass('active show');
                $('#nav-home').removeClass('active show');
                $('#nav-profile-tab').addClass('active');
                $('#nav-home-tab').removeClass('active');
                document.getElementById("submitt").setAttribute('data-bs-toggle', 'modal');
                document.getElementById("submitt").setAttribute('data-bs-target', '#exampleModal');
            }
            if (cntt == 3) {
                document.getElementById("submitt").setAttribute('data-bs-toggle', 'modal');
                document.getElementById("submitt").setAttribute('data-bs-target', '#exampleModal');
            }
            cntts++;
        }
    }
</script>


</body>

</html>
<style>
    /*Per Notification */
    .coloriii a {
        color: black !important;
    }

    .submit-form-end {
        border-radius: 15px;
        word-break: break-word;
    }

    .submit-btnnnn {
        background-color: #0C71C3;
        border-radius: 10px;
        border: none;
        color: #fff;
        font-weight: bold;
    }

    .back-btnnnn {
        background-color: #fa3737;
        border-radius: 10px;
        border: none;
        color: #fff;
        font-weight: bold;
    }

    .rolle-style {
        border-radius: 0 !important;
        border-bottom: 1.5px solid white;
    }

    .fw-600 {
        font-weight: 600;
    }

    .form-check-input[type=checkbox] {
        border-radius: .25em;
        height: 29px;
        width: 29px;
    }

    .steps-c .nav-link {
        background-color: #efefef !important;
        color: #45454560 !important;
        /*border: none !important;*/
    }

    .steps-c .nav-link.active {
        background-color: #fff !important;
        color: #000 !important;
    }

    .steps-c .nav-link:hover {
        color: #000 !important;
    }

    .steps-content {

        border-radius: 17px;
    }

    .step-one {
        background-color: #fff;
        border-bottom-left-radius: 17px !important;
        border-bottom-right-radius: 17px !important;
        border-top-right-radius: 17px !important;


    }

    .step-one-btn {
        border-top-right-radius: 10px !important;
        border-top-left-radius: 10px !important;
        border-bottom-right-radius: 0px !important;
        border-bottom-left-radius: 0px !important;

    }

    .step-two {
        background-color: #fff;
        border-bottom-left-radius: 17px !important;
        border-bottom-right-radius: 17px !important;
        border-top-right-radius: 17px !important;
        border-top-left-radius: 17px !important;


    }

    .step-two-btn {
        border-top-right-radius: 10px !important;
        border-top-left-radius: 10px !important;
        border-bottom-right-radius: 0px !important;
        border-bottom-left-radius: 0px !important;


    }

    .step-three {
        background-color: #fff;
        border-bottom-left-radius: 17px !important;
        border-bottom-right-radius: 17px !important;
        border-top-left-radius: 17px !important;


    }

    .step-three-btn {
        border-top-right-radius: 10px !important;
        border-top-left-radius: 10px !important;
        border-bottom-right-radius: 0px !important;
        border-bottom-left-radius: 0px !important;


    }

    .step-two-btn {
        border-top-right-radius: 10px !important;
        border-top-left-radius: 10px !important;
        border-bottom-right-radius: 0px !important;
        border-bottom-left-radius: 0px !important;


    }

    .angaben-content {
        background-color: #EFEFEF;
        border-radius: 10px;
    }
</style>

<style>
    @import url('https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;1,100;1,200;1,300;1,400;1,500;1,600;1,700&family=Poppins:wght@200;800;900&display=swap');

    body {
        font-family: 'Montserrat', sans-serif;
    }
</style>

<script>
    function yesBtnKundingurungClicked() {
        $("#yesBtnKundingurungForm1").slideUp();
        $("#yesBtnKundingurungForm").slideDown();
        document.getElementById("yesBtnKundingurung").style = "background: #60CB9D";
        document.getElementById("noBtnKundingurung").style = "background: #F3F1F1";
    }

    function noBtnKundingurungClicked() {
        $("#yesBtnKundingurungForm").slideUp();
        document.getElementById("yesBtnKundingurung").style = "background: #F3F1F1";
        document.getElementById("noBtnKundingurung").style = "background: #60CB9D";

    }

    function yesBtnMandatiertClicked() {
        $("#yesBtnMandatiertForm").slideDown();
        document.getElementById("yesBtnMandatiert").style = "background: #60CB9D";
        document.getElementById("noBtnMandatiert").style = "background: #F3F1F1";
    }

    function noBtnMandatiertClicked() {
        $("#yesBtnMandatiertForm").slideUp();
        document.getElementById("yesBtnMandatiert").style = "background: #F3F1F1";
        document.getElementById("noBtnMandatiert").style = "background: #EF7C6D";

    }

    function yesBtnLeasingClickedd() {

        document.getElementById("yesBtnLeasing").style = "background: #60CB9D";
        document.getElementById("noBtnLeasing").style = "background: rgba(231, 236, 249, 0.32);";
    }

    function noBtnLeasingClickedd() {
        document.getElementById("yesBtnLeasing").style = "background: rgba(231, 236, 249, 0.32);";
        document.getElementById("noBtnLeasing").style = "background: #EF7C6D";

    }

    function yesBtnGarageClickedd() {
        document.getElementById("yesBtnGarage").style = "background: #60CB9D ";
        document.getElementById("noBtnGarage").style = "background: rgba(231, 236, 249, 0.32)";
    }

    function noBtnGarageClickedd() {
        document.getElementById("yesBtnGarage").style = "background: rgba(231, 236, 249, 0.32)";
        document.getElementById("noBtnGarage").style = "background: #60CB9D ";
    }

    function yesBtnVerkehrsrechtsschutzClickedd() {
        document.getElementById("yesBtnVerkehrsrechtsschutz").style = "background: #60CB9D ";
        document.getElementById("noBtnVerkehrsrechtsschutz").style = "background: rgba(231, 236, 249, 0.32)";
    }

    function noBtnVerkehrsrechtsschutzClickedd() {

        document.getElementById("yesBtnVerkehrsrechtsschutz").style = "background: rgba(231, 236, 249, 0.32)";
        document.getElementById("noBtnVerkehrsrechtsschutz").style = "background: rgb(239, 124, 109); ";
    }


    function yesBtnUnfalldeckungClickedd() {
        document.getElementById("yesBtnUnfalldeckung").style = "background: #60CB9D ";
        document.getElementById("noBtnUnfalldeckung").style = "background: rgba(231, 236, 249, 0.32)";
    }

    function noBtnUnfalldeckungClickedd() {

        document.getElementById("yesBtnUnfalldeckung").style = "background: rgba(231, 236, 249, 0.32)";
        document.getElementById("noBtnUnfalldeckung").style = "background: rgb(239, 124, 109); ";
    }

    function yesBtnGlasschutzClickedd() {
        document.getElementById("yesBtnGlasschutz").style = "background: #60CB9D ";
        document.getElementById("noBtnGlasschutz").style = "background: rgba(231, 236, 249, 0.32)";
    }

    function noBtnGlasschutzClickedd() {

        document.getElementById("yesBtnGlasschutz").style = "background: rgba(231, 236, 249, 0.32)";
        document.getElementById("noBtnGlasschutz").style = "background: rgb(239, 124, 109); ";
    }

    function yesBtnGrobfahrlässigkeitschutzClickedd() {
        document.getElementById("yesBtnGrobfahrlässigkeitschutz").style = "background: #60CB9D ";
        document.getElementById("noBtnGrobfahrlässigkeitschutz").style = "background: rgba(231, 236, 249, 0.32)";
    }

    function noBtnGrobfahrlässigkeitschutzClickedd() {

        document.getElementById("yesBtnGrobfahrlässigkeitschutz").style = "background: rgba(231, 236, 249, 0.32)";
        document.getElementById("noBtnGrobfahrlässigkeitschutz").style = "background: rgb(239, 124, 109); ";
    }

    function yesBtnParkschadenClickedd() {
        document.getElementById("yesBtnParkschaden").style = "background: #60CB9D ";
        document.getElementById("noBtnParkschaden").style = "background: rgba(231, 236, 249, 0.32)";
    }
    function noBtnParkschadenClickedd() {

        document.getElementById("yesBtnParkschaden").style = "background: rgba(231, 236, 249, 0.32)";
        document.getElementById("noBtnParkschaden").style = "background: rgb(239, 124, 109); ";
    }
    function noBtnPannenhilfeClickedd() {

        document.getElementById("yesBtnPannenhilfe").style = "background: rgba(231, 236, 249, 0.32)";
        document.getElementById("noBtnPannenhilfe").style = "background: rgb(239, 124, 109); ";
    }
    function yesBtnPannenhilfeClickedd() {
        document.getElementById("yesBtnPannenhilfe").style = "background: #60CB9D ";
        document.getElementById("noBtnPannenhilfe").style = "background: rgba(231, 236, 249, 0.32)";
    }
    function yesBtnRaucherClicked() {
        document.getElementById("yesBtnRaucher").style = "background: #60CB9D";
        document.getElementById("noBtnRaucher").style = "background: rgba(231, 236, 249, 0.32)";
    }

    function noBtnRaucherClicked() {
        document.getElementById("yesBtnRaucher").style = "background: rgba(231, 236, 249, 0.32)";
        document.getElementById("noBtnRaucher").style = "background: rgb(239, 124, 109)";
    }
    function yesBtnTodesfalkapitalClicked() {
        document.getElementById("yesBtnTodesfalkapital").style = "background: #60CB9D";
        document.getElementById("noBtnTodesfalkapital").style = "background: rgba(231, 236, 249, 0.32)";
    }

    function noBtnTodesfalkapitalClicked() {
        document.getElementById("yesBtnTodesfalkapital").style = "background: rgba(231, 236, 249, 0.32)";
        document.getElementById("noBtnTodesfalkapital").style = "background: rgb(239, 124, 109)";
    }

    function yesBtnRenteClicked() {
        document.getElementById("yesBtnRente").style = "background: #60CB9D";
        document.getElementById("noBtnRente").style = "background: rgba(231, 236, 249, 0.32)";
    }

    function noBtnRenteClicked() {
        document.getElementById("yesBtnRente").style = "background: rgba(231, 236, 249, 0.32)";
        document.getElementById("noBtnRente").style = "background: rgb(239, 124, 109)";
    }
    function yesBtnPramienbefreiungClicked() {
        document.getElementById("yesBtnPramienbefreiung").style = "background: #60CB9D";
        document.getElementById("noBtnPramienbefreiung").style = "background: rgba(231, 236, 249, 0.32)";
    }

    function noBtnPramienbefreiungClicked() {
        document.getElementById("yesBtnPramienbefreiung").style = "background: rgba(231, 236, 249, 0.32)";
        document.getElementById("noBtnPramienbefreiung").style = "background: rgb(239, 124, 109)";
    }
    function toNextModal(){
        document.getElementById("autoModal").style.display = "none";
        document.getElementById("vorsorgeModal").style.display = "block";
    }
    function toNextModal2(){
        document.getElementById("vorsorgeModal").style.display = "none";
        document.getElementById("sachenModal").style.display = "block";
    }


    function openSachenModal() {
        $("#sachenModal").css("display", "block");
        var x = document.getElementsByTagName("BODY")[0];
        document.getElementById("krankenkaseDiv").style.display = "none";
        document.getElementById("autoDiv").style.display = "none";
        document.getElementById("VorsorgeDiv").style.display = "none";
        document.getElementById("SachenDiv").style.display = "none";
        document.getElementById("produkteTitleDiv").style.display = "none";


    }

    function openVorsorgeModal() {
        $("#vorsorgeModal").css("display", "block");
        var x = document.getElementsByTagName("BODY")[0];
        document.getElementById("krankenkaseDiv").style.display = "none";
        document.getElementById("autoDiv").style.display = "none";
        document.getElementById("VorsorgeDiv").style.display = "none";
        document.getElementById("SachenDiv").style.display = "none";
        document.getElementById("produkteTitleDiv").style.display = "none";

    }

    function openAutoModal() {
        $("#autoModal").show().css("display", "block");
        document.getElementById("krankenkaseDiv").style.display = "none";
        document.getElementById("autoDiv").style.display = "none";
        document.getElementById("VorsorgeDiv").style.display = "none";
        document.getElementById("SachenDiv").style.display = "none";
        document.getElementById("produkteTitleDiv").style.display = "none";

    }

    function openKrankenkasseModal() {
        $("#krankenkasseModal").css("display", "block");
        document.getElementById("krankenkaseDiv").style.display = "none";
        document.getElementById("autoDiv").style.display = "none";
        document.getElementById("VorsorgeDiv").style.display = "none";
        document.getElementById("SachenDiv").style.display = "none";
        document.getElementById("produkteTitleDiv").style.display = "none";

    }

    let mandatiertFile = document.getElementById("mandatiertFile");
    mandatiertFile.addEventListener("input", function(event) {
        document.getElementById("beforeUploadTextM").style.display = "none";
        document.getElementById("aferUploadTextM").style.display = "block";
        document.getElementById("inputFileBG2").style = "background: linear-gradient(180deg, rgba(54, 112, 189, 0.17) 0%, rgba(236, 240, 254, 0.24) 100%);"
    });
    let kundingurungDurchFile = document.getElementById("kundingurungDurchFile");
    kundingurungDurchFile.addEventListener("input", function(event) {
        document.getElementById("beforeUploadTextK").style.display = "none";
        document.getElementById("aferUploadTextK").style.display = "block";
        document.getElementById("inputFileBG1").style = "background: linear-gradient(180deg, rgba(54, 112, 189, 0.17) 0%, rgba(236, 240, 254, 0.24) 100%);"

    });
    let krankenkasseUploadFile = document.getElementById("krankenkasseUploadFile");
    krankenkasseUploadFile.addEventListener("input", function(event) {
        document.getElementById("beforeUploadTextKranken").style.display = "none";
        document.getElementById("aferUploadTextKranken").style.display = "block";
        document.getElementById("inputFileBG3").style = "background: linear-gradient(180deg, rgba(54, 112, 189, 0.17) 0%, rgba(236, 240, 254, 0.24) 100%);"

    });

    $('#IDCheckBox').click(function() {
        $('#IDCheckBoxLabel').toggleClass('labelWhenChecked');
    });
    $('#MandatetiertCheckBox').click(function() {
        $('#MandatetiertCheckBoxLabel').toggleClass('labelWhenChecked');
    });
    $('#KundingungCheckBox').click(function() {
        $('#KundingungCheckBoxLabel').toggleClass('labelWhenChecked');
    });
    $('#VorversichererCheckBox').click(function() {
        $('#VorversichererCheckBoxLabel').toggleClass('labelWhenChecked');
    });
    $('#vollmachtCheckBox').click(function() {
        $('#vollmachtCheckBoxLabel').toggleClass('labelWhenChecked');
    });

    function openKrankenDropdown() {
        $("#openKrankenDropdown").slideToggle();
    }

    function cancelBtnClickKranken() {
        $("#krankenkasseModal").css("display", "none");
        document.getElementById("krankenkaseDiv").style.display = "block";
        document.getElementById("autoDiv").style.display = "block";
        document.getElementById("VorsorgeDiv").style.display = "block";
        document.getElementById("SachenDiv").style.display = "block";
        document.getElementById("produkteTitleDiv").style.display = "block";
    }

    function backBtnKranken() {
        document.getElementById("step1Kranken").style.display = "block";
        $("#step2Krankenkasse").addClass("passiveStepTitle");
        $("#step2Krankenkasse").removeClass("activeStepTitle");
        $("#step2LineKranken").removeClass("blueLine");
        $("#step2LineKranken").addClass("greyLine");
        document.getElementById("step2Kranken").style.display = "none";
    }

    function continueToStep2() {
        document.getElementById("step1Kranken").style.display = "none";
        $("#step2Krankenkasse").addClass("activeStepTitle");
        $("#step2Krankenkasse").removeClass("passiveStepTitle");
        $("#step2LineKranken").removeClass("greyLine");
        $("#step2LineKranken").addClass("blueLine");
        document.getElementById("step2Kranken").style.display = "block";
    }
    //Auto
    function cancelBtnClickAuto() {
        $("#autoModal").css("display", "none");
        document.getElementById("krankenkaseDiv").style.display = "block";
        document.getElementById("autoDiv").style.display = "block";
        document.getElementById("VorsorgeDiv").style.display = "block";
        document.getElementById("SachenDiv").style.display = "block";
        document.getElementById("produkteTitleDiv").style.display = "block";
    }

    function backBtnAuto() {
        document.getElementById("step1Auto").style.display = "block";
        $("#step2Auto").addClass("passiveStepTitle");
        $("#step2Auto").removeClass("activeStepTitle");
        $("#step2LineAuto").removeClass("blueLine");
        $("#step2LineAuto").addClass("greyLine");
        document.getElementById("step2Auto").style.display = "none";
    }

    function continueToStep2Auto() {
        document.getElementById("step1Auto").style.display = "none";
        $("#step2Autoo").addClass("activeStepTitle");
        $("#step2Autoo").removeClass("passiveStepTitle");
        $("#step2LineAuto").removeClass("greyLine");
        $("#step2LineAuto").addClass("blueLine");
        document.getElementById("step2Auto").style.display = "block";
    }
    //vorsorge
    function cancelBtnClickVorsorge() {
        $("#vorsorgeModal").css("display", "none");
        document.getElementById("krankenkaseDiv").style.display = "block";
        document.getElementById("autoDiv").style.display = "block";
        document.getElementById("VorsorgeDiv").style.display = "block";
        document.getElementById("SachenDiv").style.display = "block";
        document.getElementById("produkteTitleDiv").style.display = "block";
    }

    function backBtnVorsorge() {
        document.getElementById("step1Vorsorge").style.display = "block";
        $("#step2Vorsorge").addClass("passiveStepTitle");
        $("#step2Vorsorge").removeClass("activeStepTitle");
        $("#step2LineVorsorge").removeClass("blueLine");
        $("#step2LineVorsorge").addClass("greyLine");
        document.getElementById("step2Vorsorge").style.display = "none";
    }

    function continueToStep2Vorsorge() {
        document.getElementById("step1Vorsorge").style.display = "none";
        $("#step2Vorsorgee").addClass("activeStepTitle");
        $("#step2Vorsorgee").removeClass("passiveStepTitle");
        $("#step2LineVorsorge").removeClass("greyLine");
        $("#step2LineVorsorge").addClass("blueLine");
        document.getElementById("step2Vorsorge").style.display = "block";
    }
    //vorsorge
    function cancelBtnClickSachen() {
        $("#sachenModal").css("display", "none");
        document.getElementById("krankenkaseDiv").style.display = "block";
        document.getElementById("autoDiv").style.display = "block";
        document.getElementById("VorsorgeDiv").style.display = "block";
        document.getElementById("SachenDiv").style.display = "block";
        document.getElementById("produkteTitleDiv").style.display = "block";
    }

    function backBtnSachen() {
        document.getElementById("step1Sachen").style.display = "block";
        $("#step2Sachen").addClass("passiveStepTitle");
        $("#step2Sachen").removeClass("activeStepTitle");
        $("#step2LineSachen").removeClass("blueLine");
        $("#step2LineSachen").addClass("greyLine");
        document.getElementById("step2Sachen").style.display = "none";
    }

    function continueToStep2Sachen() {
        document.getElementById("step1Sachen").style.display = "none";
        $("#step2Sachenn").addClass("activeStepTitle");
        $("#step2Sachenn").removeClass("passiveStepTitle");
        $("#step2LineSachen").removeClass("greyLine");
        $("#step2LineSachen").addClass("blueLine");
        document.getElementById("step2Sachen").style.display = "block";
    }



    function openKrankenDropdownStep2() {
        $("#Grundversicherung").slideToggle();
    }

    function openKrankenDropdownStep22() {
        $("#Zusatzversicherung").slideToggle();
    }
    //auto
    function openAutoDropdownStep2() {
        $("#Gegenofferte").slideToggle();
    }

    function openAutoDropdownStep22() {
        $("#NeuesFahrzeug").slideToggle();
    }

    function openAutoDropdownStep222() {
        $("#Autoversicherung").slideToggle();
    }
    //vorsorge
    function openVorsorgeDropdownStep2() {
        $("#Vorsorge").slideToggle();
    }
    //sachen
    function openSachenDropdownStep2() {
        $("#Gegenofertensachen").slideToggle();
    }

    function openSachenDropdownStep22() {
        $("#NeuesSachen").slideToggle();
    }

    function openSachenDropdownStep222() {
        $("#GesellschaftSachen").slideToggle();
    }

    function openSachenDropdownStep2222() {
        $("#Rechtsschutz").slideToggle();
    }

    function openSachenDropdownStep22222() {
        $("#Hausrat").slideToggle();
    }

    function toNextModal1() {
        document.getElementById("krankenkasseModal").style.display = "none";
        document.getElementById("autoModal").style.display = "block";

    }
</script>
<style>
    html,
    body {
        width: 100%;
    }


    body,
    p,
    span {
        font-family: 'Montserrat';
    }

    .documentFormTitle {
        font-weight: 600;
    }

    .documentFormGreyBGDiv {
        background: rgba(225, 231, 245, 0.28);
        border-radius: 5px;
    }

    .documentFormLeftSpan {
        font-family: 'Montserrat';
        font-style: normal;
        font-weight: 500;
        font-size: 15px;
        color: #A7AAA9;
    }

    .documentFormRightSpan {
        font-weight: 400;
        font-size: 14px;
    }

    .documentFormGreyBGTitle {
        font-weight: 600;
        font-size: 15px;
    }

    .kundingurungDurch {
        font-weight: 500;
        font-size: 17px;
        text-align: center;
        color: #1D2346;
    }

    .documentFormBtn {
        background: #F3F1F1;
        border-radius: 10px;
        border: none;
        outline: none;
        font-weight: 500;
        font-size: 17px;
        text-align: center;
        color: #1D2346;
        padding-top: 12px;
        padding-bottom: 12px;
        width: 80px;
        transition: all 0.3s ease-in-out;
    }

    .documentFormGreyBGDiv2 {
        background: #EBEEFB;
        border-radius: 5px;
        cursor: pointer;
    }

    .underSvgSpan {
        text-align: center;
        font-weight: 600;
        font-size: 25px;
        color: #727AA9;
    }

    input#file {
        display: none;
    }

    input#file+label {

        padding: 8px;
        color: black;

        border-radius: 9px;
    }

    input#file+label:hover {
        cursor: pointer;
    }

    input#file-m {
        display: none;
    }

    input#file-m+label {

        padding: 8px;
        color: black;

        border-radius: 9px;
    }

    input#file-m+label:hover {
        cursor: pointer;
    }

    .fileInputFirstTitle {
        font-weight: 400;
        text-align: center;
        color: #99999A;
    }

    .fileInputSecondTitle {
        font-weight: 500;
        font-size: 15px;
        text-align: center;
        text-decoration-line: underline;
        color: #658BEB;
    }

    .inputFileBG {
        background: #F7F8FC;
        border: 2px dashed #708CD4;
        box-sizing: border-box;
        border-radius: 9px;
        width: 85%;
    }

    .aferUploadText {
        display: none;
    }

    .documentsFormModals {

        bottom: 0;
        left: 1.5rem;
        display: none;
        height: auto;
        width: 100%;
        background: #fff;
        border-radius: 22px;
        z-index: 11;
        box-shadow: 0px 4px 39px rgba(83, 80, 80, 0.09);
    }

    .blurBody {
        overflow: hidden;
        background: rgba(29, 32, 34, 0.4);
        z-index: 100;
        transition: all 0.5s ease-in-out;
    }

    .onTopDiv {
        height: 100%;
        width: 100%;
        position: fixed;
        top: 0;
        left: 0;
        display: none;
        z-index: 10;
        transition: all 0.5s ease-in-out;
    }

    .activeStepTitle {
        font-weight: 500;
        font-size: 30px;
        letter-spacing: -0.04em;
        color: #3F4852;
    }

    .blueLine {
        width: 95%;
        height: 5px;
        background-color: #2F60DC;
        border-radius: 5px;
    }

    .passiveStepTitle {
        font-weight: 500;
        font-size: 30px;
        color: #B4B9BC;
    }

    .greyLine {
        width: 95%;
        height: 5px;
        background-color: #B4B9BC;
        border-radius: 5px;

    }

    .uncheckedCheckbox {
        font-weight: 500;
        font-size: 25px;
        color: #B4B9BC;
        line-height: 0.8;
    }

    option:checked {
        box-shadow: 0 0 0 3px lime;
        color: red;
    }

    .modalTitle {
        font-weight: 600;
        font-size: 30px;
        color: #000000;
        display: none;
    }

    .list-choice-title {
        font-weight: 400;
        font-size: 16px;
        color: #1D2346;
        border: 1px solid #2F60DC;
        border-radius: 11px;
    }

    .list-choice-objects {
        font-weight: 400;
        font-size: 16px;
        color: #1D2346;
        display: none;
        border: 1px solid #2F60DC;
        border-radius: 11px;
        margin-top: 2px;
    }

    .container1 {
        display: block;
        position: relative;
        padding-left: 35px;
        margin-bottom: 12px;
        cursor: pointer;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
    }

    .container1 input {
        position: absolute;
        opacity: 0;
        cursor: pointer;
    }

    .checkmark1 {
        position: absolute;
        top: 0px;
        left: 0;
        height: 25px;
        width: 25px;
        background: #eee;
        border-radius: 50%;
        border: 2px solid #2F60DC;
    }

    .container1:hover input~.checkmark1 {
        background: #eee;
    }

    .container1 input:checked~.checkmark1 {
        background: #eee;
    }

    .checkmark1:after {
        content: "";
        position: absolute;
        display: none;
    }

    .container1 input:checked~.checkmark1:after {
        display: block;
    }

    .container1 .checkmark1:after {
        top: 2px;
        left: 1.5px;
        width: 17.5px;
        height: 17.5px;
        border-radius: 50%;
        background: #2F60DC;
    }

    .container2 {
        display: block;
        position: relative;
        padding-left: 35px;
        margin-bottom: 12px;
        cursor: pointer;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
    }

    .container2 input {
        position: absolute;
        opacity: 0;
        cursor: pointer;
        height: 0;
        width: 0;
    }

    .checkmark2 {
        position: absolute;
        top: 0;
        left: 0;
        height: 25px;
        width: 25px;
        background: rgba(181, 185, 188, 0.62);
        border-radius: 5px;
    }

    .container2:hover input~.checkmark2 {
        background: rgba(181, 185, 188, 0.62);

    }

    .container2 input:checked~.checkmark2 {
        background-color: #2F60DC;
        border-radius: 7px;
    }

    .checkmark2:after {
        content: "";
        position: absolute;
        display: none;
    }

    .container2 input:checked~.checkmark2:after {
        display: block;
    }

    .container2 .checkmark2:after {
        left: 9px;
        top: 4.5px;
        width: 7px;
        height: 12px;
        border: solid white;
        border-width: 0 2px 2px 0;
        -webkit-transform: rotate(45deg);
        -ms-transform: rotate(45deg);
        transform: rotate(45deg);
    }

    .hoverLabelClass:hover {
        background: rgba(47, 96, 220, 0.08);
        border-radius: 11px;
    }

    .labelWhenChecked {
        color: #000000;
    }

    .cancelBtnKranken {
        font-weight: 500;
        font-size: 16px;
        color: #658BEB;
        border: 1px solid rgba(101, 139, 235, 0.4);
        box-sizing: border-box;
        border-radius: 6px;
        background: #fff;
        width: 100%;
    }

    .doneBtnKranken {
        background: #658BEB;
        border: 1px solid rgba(101, 139, 235, 0.4);
        border-radius: 6px;
        font-weight: 500;
        font-size: 14px;
        color: #fff;
        width: 100%;

    }

    .continueBtn {
        background: #2F60DC;
        border-radius: 7px;
        font-size: 16px;
        color: #FFFFFF;
        border: 1px solid #2F60DC;
        width: 100%;
    }

    .list-choice-title-step2 {
        font-weight: 700;
        color: #1D2346
    }

    .Grundversicherung,
    .Zusatzversicherung {
        background: rgba(231, 236, 249, 0.32);
        border: 1px solid #D6D9E1;
        box-sizing: border-box;
        border-radius: 11px;
        display: none;
    }

    .GrundversicherungSpans {
        font-weight: 500;
        color: rgba(29, 35, 70, 0.72);
    }

    .GrundversicherungInput {
        border: 1px solid rgba(45, 156, 219, 0.52);
        box-sizing: border-box;
        border-radius: 7px;
        background: rgba(231, 236, 249, 0.32);
    }

    .ZusatzversicherungTitle {
        font-weight: 700;
        font-size: 18px;
        color: #1D2346;
    }

    .documentFormTitle {
        font-size: 35px;
    }

    .documentFormRightSpan {
        font-size: 20px;
    }

    .documentFormLeftSpan {
        font-size: 20px;

    }

    .documentFormGreyBGTitle {
        font-size: 20px;
    }

    .kundingurungDurch {
        font-size: 24px;
    }

    .documentFormBtn {
        font-size: 20px;
        font-weight: 600;
    }

    .fileInputFirstTitle {
        font-size: 24px;
    }

    .fileInputSecondTitle {
        font-size: 28px;
    }

    .uploadSvgStyle {
        width: 37px;
        height: 37px;
    }

    .afterUploadSvg {
        width: 123px;
        height: 123px;
    }

    .documentFormGreyBGDiv2 {
        border-radius: 28px;
    }

    .ProduktsSvgClass {
        width: 110px;
        height: 150px;
    }

    .pageBackgroundColor {
        background: rgba(247, 245, 245, 0.55);
        border: 1px solid #F1F1F1;
        box-sizing: border-box;
        border-radius: 22px;
    }

    .continueBtnDiv {
        float: right;
    }

    .sichMit {
        font-size: 22px;
    }

    .cornerSvg {
        width: 200px;
        height: 150px;
    }

    .cornerSvgDiv {
        position: absolute;
        top: -1.5rem;
        left: -4.1rem;
    }

    .changeBtnAlign {
        justify-content: end;
    }

    .inFormYesNoBtn {
        background: rgba(231, 236, 249, 0.32);
        padding-top: 7px;
        padding-bottom: 7px;
        cursor: pointer;
        font-size: 17px;
    }

    @media (max-width: 1199.98px) {
        .documentFormRightSpan {
            font-size: 20px;
        }

        .documentFormLeftSpan {
            font-size: 20px;

        }

        .documentFormGreyBGTitle {
            font-size: 20px;
        }

        .kundingurungDurch {
            font-size: 24px;
        }

        .documentFormGreyBGDiv2 {
            border-radius: 24px;
        }
    }

    @media (max-width: 991.98px) {
        .documentFormTitle {
            font-size: 30px;
        }

        .documentFormRightSpan {
            font-size: 20px;
        }

        .documentFormLeftSpan {
            font-size: 20px;

        }

        .documentFormGreyBGTitle {
            font-size: 20px;
        }

        .kundingurungDurch {
            font-size: 22px;
        }

        .fileInputFirstTitle {
            font-size: 20px;
        }

        .fileInputSecondTitle {
            font-size: 21px;
        }

        .documentFormGreyBGDiv2 {
            border-radius: 15px;
        }

        .underSvgSpan {
            font-size: 21px;

        }

        .ProduktsSvgClass {
            width: 100px;
            height: 120px;
        }

        .activeStepTitle {
            font-weight: 500;
            font-size: 25px;

        }

        .passiveStepTitle {
            font-weight: 500;
            font-size: 25px;
        }

        .modalTitle {
            font-size: 25px;
        }

        .uncheckedCheckbox {
            font-size: 22px;
            line-height: 1;
        }

        .sichMit {
            font-size: 20px;
        }

        .documentFormBtn {
            width: 70px;
        }
    }

    @media (max-width: 767.98px) {
        .documentFormTitle {
            font-size: 22px;
        }

        .documentFormRightSpan {
            font-size: 16px;
        }

        .documentFormLeftSpan {
            font-size: 16px;

        }

        .documentFormGreyBGTitle {
            font-size: 17px;
        }

        .kundingurungDurch {
            font-size: 18px;
        }

        .fileInputFirstTitle {
            font-size: 18px;
        }

        .fileInputSecondTitle {
            font-size: 19px;
        }

        .uploadSvgStyle {
            width: 32px;
            height: 32px;
        }

        .documentFormGreyBGDiv2 {
            border-radius: 10px;
        }

        .underSvgSpan {
            font-size: 19px;

        }

        .activeStepTitle {
            font-weight: 500;
            font-size: 20px;

        }

        .passiveStepTitle {
            font-weight: 500;
            font-size: 20px;
        }

        .continueBtnDiv {
            float: none;
        }

        .modalTitle {
            font-size: 20px;
        }

        .uncheckedCheckbox {
            font-size: 20px;
            line-height: 1.3;
        }

        .sichMit {
            font-size: 18px;
        }

        .cornerSvgDiv {
            position: absolute;
            top: -1.3rem;
            left: -2.6rem;
        }

        .cornerSvg {
            width: 110px;
            height: 110px;
        }

        .documentFormBtn {
            width: 85px;
        }
    }

    @media (max-width: 575.98px) {
        .documentFormTitle {
            font-size: 16px;
        }

        .documentFormRightSpan {
            font-size: 14px;
        }

        .documentFormLeftSpan {
            font-size: 14px;

        }

        .documentFormGreyBGTitle {
            font-size: 15px;
        }

        .kundingurungDurch {
            font-size: 17px;
        }

        .documentFormBtn {
            font-size: 17px;
            font-weight: 500;

        }

        .documentFormBtn {
            width: 60px;
        }

        .fileInputFirstTitle {
            font-size: 16px;
        }

        .fileInputSecondTitle {
            font-size: 15px;
        }

        .uploadSvgStyle {
            width: 30px;
            height: 30px;
        }

        .afterUploadSvg {
            width: 90px;
            height: 90px;
        }

        .documentFormGreyBGDiv2 {
            border-radius: 5px;
        }

        .underSvgSpan {
            font-size: 17px;

        }

        .ProduktsSvgClass {
            width: 50px;
            height: 80px;
        }

        .activeStepTitle {
            font-weight: 400;
            font-size: 16px;

        }

        .passiveStepTitle {
            font-weight: 500;
            font-size: 16px;
        }

        .documentsFormModals {
            background-color: #F7F8FC;
            box-shadow: none;

        }

        .pageBackgroundColor {
            background: #fff;
            border-radius: 0;
        }

        .continueBtnDiv {
            float: none;
        }

        .modalTitle {
            font-size: 18px;
            display: block;
        }

        .uncheckedCheckbox {
            font-size: 16px;
            line-height: 1.5;
        }

        .sichMit {
            font-size: 16px;
        }

        .cornerSvgDiv {
            position: absolute;
            top: -1.2rem;
            left: -2.45rem;
        }

        .cornerSvg {
            width: 100px;
            height: 100px;
        }

        .changeBtnAlign {
            justify-content: center;
        }
    }
    .activeClassNavMob__,
    .activeClassNavMob__ svg path {
        background-color: transparent;
        color: #2f60dc !important;
        fill: #2f60dc !important;
        stroke: #2f60dc !important;
    }
    .activeClassNavMob__ span circle {
        background-color: transparent;
        fill: #2f60dc !important;
    }
</style>
