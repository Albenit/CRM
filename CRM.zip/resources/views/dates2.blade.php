{{--<div>--}}
    <h1>{{count($count)}}</h1>
    @foreach($count as $dat)
        <span>{{$dat->first_name}}</span>
        <br>
    @endforeach



{{--</div>--}}




{{-- Leads--}}
{{--<div>--}}
{{--    @foreach($leads as $lead)--}}
{{--        <p>{{$lead->first_name}}</p>--}}
{{--    @endforeach--}}
{{--</div>--}}

{{--Appointment--}}
{{--contractperdate--}}
{{--<p>{{$datas}}</p>--}}
