<template>

    <div class="secondGreyBorderDash p-3 p-md-4 h-100">
        <div class=" h-100" style="position: relative;">
            <div class="row g-0">
        <div class="col-auto cornerSvgToDoList">
           <svg width="151" height="146" viewBox="0 0 151 146" fill="none" xmlns="http://www.w3.org/2000/svg">
                <g filter="url(#filter0_d_28_428)">
                <path d="M37.0423 77.3271C39.8362 81.9774 47.7843 86.5471 52.0268 89.8453C56.2692 93.1435 50.752 102.5 55.797 103.944C60.8421 105.388 76.3506 98.8915 81.4301 98.2616C86.5097 97.6317 91.3583 95.9651 95.6991 93.3571C100.04 90.7491 103.788 87.2506 106.729 83.0615C109.67 78.8725 111.747 74.0747 112.841 68.9424C113.934 63.81 114.024 58.4434 113.104 53.1491C112.184 47.8547 111.334 38.8294 110.492 33.8527L80.9468 34.3263L63.3665 34.608C58.8425 34.6805 54.4031 35.8453 50.4263 38.0032L47.8194 39.4178C43.6759 41.6661 40.4617 45.3082 38.746 49.6991C37.881 51.9128 37.4183 54.2631 37.3795 56.6394L37.0423 77.3271Z" fill="#DCE4F9"/>
                </g>
                <path d="M83.5879 59.3778L83.4299 60.0237C82.9559 60.2108 82.5773 60.3532 82.2953 60.4511C82.0131 60.5493 81.6851 60.5981 81.3114 60.5981C80.7376 60.5981 80.2913 60.4576 79.973 60.1784C79.6546 59.898 79.4954 59.5428 79.4954 59.1119C79.4954 58.9451 79.507 58.7735 79.531 58.5987C79.5552 58.4237 79.5937 58.2266 79.6464 58.0062L80.2388 55.9096C80.2915 55.7088 80.3363 55.5186 80.3722 55.3387C80.4086 55.1599 80.4261 54.9954 80.4261 54.8474C80.4261 54.5796 80.3706 54.3923 80.2603 54.287C80.1499 54.182 79.9393 54.1287 79.6267 54.1287C79.4735 54.1287 79.3161 54.1533 79.1557 54.2007C78.9946 54.2483 78.8568 54.2943 78.7412 54.3371L78.8996 53.6907C79.2877 53.5327 79.6586 53.3974 80.0134 53.2851C80.3682 53.1725 80.7035 53.1162 81.0206 53.1162C81.5904 53.1162 82.0302 53.2539 82.339 53.5294C82.6478 53.805 82.8021 54.1624 82.8021 54.6027C82.8021 54.6938 82.792 54.8544 82.7702 55.0838C82.7489 55.3138 82.7093 55.5245 82.6515 55.7161L82.0617 57.8043C82.0134 57.9721 81.9699 58.1638 81.9321 58.3796C81.8931 58.5939 81.8744 58.7577 81.8744 58.8676C81.8744 59.1448 81.9362 59.3342 82.0602 59.4348C82.185 59.5354 82.4001 59.5855 82.7056 59.5855C82.849 59.5855 83.0121 59.5601 83.1934 59.5101C83.3742 59.4601 83.5061 59.4163 83.5879 59.3778ZM83.7375 50.6108C83.7375 50.9747 83.6003 51.2854 83.3248 51.5409C83.0499 51.7973 82.7187 51.9256 82.3313 51.9256C81.9426 51.9256 81.6106 51.7973 81.3326 51.5409C81.0551 51.2853 80.9161 50.9747 80.9161 50.6108C80.9161 50.2477 81.0551 49.9365 81.3326 49.6777C81.6101 49.4194 81.9427 49.2903 82.3313 49.2903C82.7186 49.2903 83.0499 49.4197 83.3248 49.6777C83.6005 49.9365 83.7375 50.2478 83.7375 50.6108Z" fill="black"/>
                <path d="M82.0322 46C75.9846 46 71.0645 50.2374 71.0645 55.4458C71.0645 58.515 72.7608 61.3472 75.6308 63.1202C75.2326 65.0776 74.3402 66.4512 74.3305 66.466L73.3549 67.9355L75.047 67.7074C75.2419 67.6811 79.7815 67.0484 83.017 64.8537C85.6741 64.6503 88.142 63.6253 89.9858 61.9553C91.9295 60.1946 92.9999 57.8828 92.9999 55.4459C92.9999 50.2374 88.0798 46 82.0322 46ZM82.7253 63.2815L82.5189 63.2939L82.3473 63.4152C80.4657 64.7443 77.9468 65.4816 76.3622 65.8422C76.6946 65.0608 77.044 64.022 77.2183 62.8228L77.2998 62.2623L76.8223 61.999C74.1631 60.5337 72.5754 58.0841 72.5754 55.4458C72.5754 51.1135 76.8177 47.5888 82.0322 47.5888C87.2467 47.5888 91.489 51.1134 91.489 55.4458C91.489 59.5431 87.6395 62.9848 82.7253 63.2815Z" fill="black"/>
                <g clip-path="url(#clip0_28_428)">
                <path d="M64.2232 59.8391C62.6821 59.9728 60.5864 61.8485 60.1233 63.0179C59.4613 64.6892 59.6481 65.307 60.3235 66.9528C61.2185 69.1336 63.617 72.9288 66.7054 75.4329C71.1086 79.0032 75.0371 80.3562 76.7669 80.7707C78.4967 81.1852 80.2694 80.4668 81.293 79.2488C82.3165 78.0308 83.3401 76.8127 81.9333 75.2409C80.9365 74.1271 79.5154 72.8628 77.8589 72.2068C76.3527 71.6102 75.5152 71.9476 75.1056 73.0103C74.8791 73.5977 74.8872 74.6846 74.7396 75.3005C74.5535 76.0774 73.5274 75.9703 72.358 75.5071C71.2384 75.0637 68.3322 73.0333 65.7989 69.8654C64.2293 67.9027 66.4481 67.6966 67.7974 66.869C68.8695 66.2113 69.1051 64.8923 68.066 63.458C66.1417 60.8019 65.4841 59.7297 64.2232 59.8391Z" stroke="black" stroke-width="1.5"/>
                </g>
                <defs>
                <filter id="filter0_d_28_428" x="0.0419922" y="0.852783" width="150.691" height="144.3" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                <feFlood flood-opacity="0" result="BackgroundImageFix"/>
                <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
                <feOffset dy="4"/>
                <feGaussianBlur stdDeviation="18.5"/>
                <feComposite in2="hardAlpha" operator="out"/>
                <feColorMatrix type="matrix" values="0 0 0 0 0.875 0 0 0 0 0.875 0 0 0 0 0.875 0 0 0 0.25 0"/>
                <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_28_428"/>
                <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_28_428" result="shape"/>
                </filter>
                <clipPath id="clip0_28_428">
                <rect width="27" height="27" fill="white" transform="translate(56.8838 58.2174) rotate(-4.9587)"/>
                </clipPath>
                </defs>
            </svg>





        </div>
        <div class="col titleMarginAuto">
            <div class="pb-3">
                <span class="fs-4 secondGreyBorderDashSpan">Telefonverzeichnis</span>
            </div>
        </div>
    </div>

            <div class="overFlowDivDashboard mb-5 mb-md-0" style="margin-top: -1rem">
                <div v-if="numbers == 0">
                        <div class="text-center fs-6 fw-400 d-flex h-100 justify-content-center align-items-center" style="color: #9F9F9F">
                            Keine Telefonnummern
                        </div>
                    </div>
                <div v-else class="thirdBorderDivDash mb-2 p-2 bg-white d-flex justify-content-between" v-for="numberi in numbers">
                        <div class="col-auto px-2 my-auto">
                            <svg width="51" height="51" viewBox="0 0 51 51" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M25.5 0C11.4182 0 0 11.416 0 25.4989C0 39.5818 11.4171 50.9978 25.5 50.9978C39.584 50.9978 51 39.5818 51 25.4989C51 11.416 39.584 0 25.5 0ZM25.5 7.62446C30.1596 7.62446 33.9354 11.4014 33.9354 16.0587C33.9354 20.7172 30.1596 24.493 25.5 24.493C20.8427 24.493 17.0668 20.7172 17.0668 16.0587C17.0668 11.4014 20.8427 7.62446 25.5 7.62446ZM25.4944 44.331C20.8471 44.331 16.5908 42.6385 13.3078 39.8372C12.5081 39.155 12.0466 38.1548 12.0466 37.1053C12.0466 32.3818 15.8695 28.6015 20.594 28.6015H30.4082C35.1339 28.6015 38.9422 32.3818 38.9422 37.1053C38.9422 38.1559 38.483 39.1539 37.6821 39.8361C34.4002 42.6385 30.1428 44.331 25.4944 44.331Z" fill="#DDDDDD"/>
                            </svg>
                        </div>
                        <div class="ps-2 col">
                            <div class="" style="font-weight: 600;">{{ numberi.costumer }} ({{ numberi.number }})</div>
                            <div class="" style="font-weight: 400;">{{numberi.comment}}</div>
                            <div class="" style="font-weight: 400;">{{ numberi.text }}</div>
                        </div>
                        <div class="col-auto my-auto">
                            <div class=" ">
                                <div class="btn " @click="deletenumber(numberi.id)">
                                    <svg width="15" height="15" viewBox="0 0 8 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M7 1L1 7" stroke="#8a8181" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M1 1L7 7" stroke="#8a8181" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>

                                </div>
                            </div>
                        </div>
                </div>
            </div>
            <div class="w-100" style="position: absolute;bottom: 0rem;">
                <div class="row g-0 justify-content-center">
                    <div class="text-center col-12 col-md-8 col-lg-8 col-xl-7 col-xxl-6">
                        <button data-bs-toggle="modal" data-bs-target="#numberModal" class="kontaktBtnDash w-100 py-1 fs-6">Kontakt hinzufügen</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="numberModal" data-bs-backdrop="static"
             data-bs-keyboard="false" tabindex="-1"
             aria-labelledby="staticBackdropLabel"
             aria-hidden="true">
            <div class="modal-dialog modaldialogg">
                <div class="modal-content" style="border-radius: 24px !important;">
                    <div class="modal-header mx-4 pt-4"
                         style="border-bottom: none !important;">
                            <span style="font-weight: 700;color:#434343" class="modal-title fs-5">Abgelehnt Lead</span>

                        <button type="button"
                                 data-bs-dismiss="modal"
                                aria-label="Close"
                                style="opacity: 1 !important;border: none;background-color: transparent;"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#434343" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
                    </div>
                    <div class="modal-body mx-5">
                        <input type="hidden" name="leadsid">
                        
                        <div class="row py-1 ">
                            <div class="col-12 pb-2">
                                <label for="name" class="col-form-label fs-6 pb-0" style="font-weight: 600;color:#434343">Vorname: </label>
                                <input style="box-shadow: 0px 4px 4px rgba(238, 238, 238, 0.25);" type="text" name="name" id="name" class="form-control inputStyleDash grundBesInputStyle">
                            </div>
                            <div class="col-12 pb-2">
                                <label for="position" class="col-form-label fs-6 pb-0" style="font-weight: 600;color:#434343">Funktion / Notiz :</label>
                                <input style="box-shadow: 0px 4px 4px rgba(238, 238, 238, 0.25);" type="text" name="position" id="position" class="form-control inputStyleDash grundBesInputStyle" >
                            </div>
                            <div class="col-12 pb-2">
                                <label for="company_name" class="col-form-label fs-6 pb-0" style="font-weight: 600;color:#434343">Name der Firma: </label>
                                <input style="box-shadow: 0px 4px 4px rgba(238, 238, 238, 0.25);" type="text" name="position" id="company_name" class="form-control inputStyleDash grundBesInputStyle" >
                            </div>
                            <div class="col-12">
                                <label for="number" class="col-form-label fs-6 pb-0" style="font-weight: 600;color:#434343">Telefonnummer : </label>
                                <input style="box-shadow: 0px 4px 4px rgba(238, 238, 238, 0.25);" type="tel" name="todo" id="number" class="form-control inputStyleDash grundBesInputStyle" v-on:keyup.enter="addnumber">
                            </div>
                            <div class="modal-footer m-0"
                                 style="border-top: none !important; display: block;margin:0 !important;">
                                <button @click="addnumber"  type="submit" class="btn w-100 m-0 my-3"
                                        style="border-radius: 9px !important; background-color: #0C71C3; color: #fff !important;font-weight: 600 !important;">
                                    Hinzufügen</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>





</template>

<script>
export default {
    mounted() {
        this.fetchnumbers();
        this.fetchtasks();
;
    },
    data() {
        return {
            todos: null,
            numbers: null,
            admin: null,
            costumer: null,
            readed: false,
            cnt:0
        }
    },
    methods: {
        onChangeSelect(event) {
            this.admin = parseInt(event.target.value);
        },
        onChangeCostumer(event) {
            this.costumer = parseInt(event.target.value);
        },

        addnumber: function () {
            var valName = document.getElementById('name')
            var valPosition = document.getElementById('position')
            var valNumber = document.getElementById('number')
            var valCompanyName = document.getElementById('company_name')

            if (valName.value.trim() != '') {
                axios.get('addnumber?number=' + valNumber.value + '&name=' + valName.value + '&position=' + valPosition.value + '&company_name=' + valCompanyName.value).then(location.reload());
            }
            valNumber.value = "";
            valName.value = "";
            valPosition.value = "";
        },

        assignpendency: function () {
            axios.get('assignpendency?admin=' + this.admin + '&id=' + this.costumer + '&desc=' + document.getElementById('desc').value);
            document.getElementById('alrt').innerHTML = "";
            document.getElementById('alrt').innerHTML += ' <div class="alert alert-success" role="alert"> Pendency was assigned successfully</div>';
        },
        fetchnumbers() {
            axios.get('numbers').then((response) => {
                this.numbers = response.data;
                this.cnt = response.data.length;
            });
        },
        deletenumber: function (val) {
            axios.get('deletenumber?id=' + val).then(
                this.fetchnumbers
            );
        },
        fetchtasks: function () {
            axios.get('todos').then((response) => {
                this.todos = response.data,
                    this.admin = response.data.admins[0].id,
                    this.costumer = response.data.costumers[0].id
            });
        }
    },

}

</script>
