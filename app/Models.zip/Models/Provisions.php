<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Provisions extends Model
{
    use HasFactory,SoftDeletes;


    public function members(){
        return $this->hasManyThrough(Admins::class,Group::class,'provision_id','group_id');
    }

protected $guarded = [];

}
